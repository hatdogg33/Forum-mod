import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import HomePage from "@/pages/home-page";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import CategoriesPage from "@/pages/categories-page";
import CategoryPage from "@/pages/category-page";
import ThreadsPage from "@/pages/threads-page";
import ThreadPage from "@/pages/thread-page";
import NewThreadPage from "@/pages/new-thread-page";
import ModsPage from "@/pages/mods-page";
import ProfilePage from "@/pages/profile-page";
import TestAchievementsPage from "@/pages/test-achievements-page";
import MembershipPage from "@/pages/membership-page";
import CheckoutPage from "@/pages/checkout-page";
import TermsPage from "@/pages/terms-page";
import PrivacyPage from "@/pages/privacy-page";
import ContactPage from "@/pages/contact-page";
import AdminDashboardPage from "@/pages/admin/dashboard-page";
import AdminCategoriesPage from "@/pages/admin/categories-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";
import { AchievementNotifications } from "@/components/achievements";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/categories" component={CategoriesPage} />
      <Route path="/categories/:slug" component={CategoryPage} />
      <Route path="/threads" component={ThreadsPage} />
      <Route path="/threads/:id" component={ThreadPage} />
      <Route path="/categories/:categoryId/new-thread" component={NewThreadPage} />
      <Route path="/mods" component={ModsPage} />
      <ProtectedRoute path="/mods/new" component={ModsPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <Route path="/profile/:userId" component={ProfilePage} />
      <Route path="/profile/:userId/achievements" component={ProfilePage} />
      <ProtectedRoute path="/membership" component={MembershipPage} />
      <ProtectedRoute path="/checkout" component={CheckoutPage} />
      <ProtectedRoute path="/settings" component={ProfilePage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/contact" component={ContactPage} />
      <ProtectedRoute path="/admin" component={AdminDashboardPage} />
      <ProtectedRoute path="/admin/dashboard" component={AdminDashboardPage} />
      <ProtectedRoute path="/admin/categories" component={AdminCategoriesPage} />
      <Route path="/test-achievements" component={TestAchievementsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <AuthProvider>
          <Router />
          <AchievementNotifications />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
