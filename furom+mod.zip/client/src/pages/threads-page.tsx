import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { ThreadSkeletonList } from "@/components/ui/skeletons/thread-skeleton";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { 
  MessageSquare, 
  Users, 
  Eye, 
  Calendar, 
  TrendingUp, 
  Filter,
  Clock
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Define the types for our data
interface Thread {
  id: number;
  title: string;
  content: string;
  userId: number;
  categoryId: number;
  viewCount: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: string;
  lastActivityAt: string;
}

interface Category {
  id: number;
  name: string;
  slug: string;
}

export default function ThreadsPage() {
  const { user } = useAuth();
  const [sortBy, setSortBy] = useState("recent");
  
  const { data: recentThreads, isLoading: isThreadsLoading } = useQuery<Thread[]>({
    queryKey: ["/api/threads/recent"],
    queryFn: async () => {
      const response = await fetch("/api/threads/recent?limit=20");
      if (!response.ok) throw new Error("Failed to fetch threads");
      return response.json();
    }
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    }
  });

  // Get category names map
  const categoryMap = categories?.reduce((acc, category) => {
    acc[category.id] = category;
    return acc;
  }, {} as Record<number, Category>) || {};

  // Sort threads based on the selected option
  const sortedThreads = [...(recentThreads || [])].sort((a, b) => {
    if (sortBy === "recent") {
      return new Date(b.lastActivityAt).getTime() - new Date(a.lastActivityAt).getTime();
    } else if (sortBy === "popular") {
      return b.viewCount - a.viewCount;
    } else if (sortBy === "newest") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    return 0;
  });

  if (isThreadsLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <PageLoadingSkeleton />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Discussions</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Browse all threads in the forum
          </p>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <Tabs defaultValue="all" className="w-full md:w-auto">
            <TabsList>
              <TabsTrigger value="all" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>All Threads</span>
              </TabsTrigger>
              <TabsTrigger value="trending" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span>Trending</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-2 text-gray-500" />
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Recently Active</SelectItem>
                  <SelectItem value="popular">Most Viewed</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {sortedThreads.length > 0 ? (
          <div className="grid gap-4">
            {sortedThreads.map((thread) => (
              <Link key={thread.id} href={`/threads/${thread.id}`}>
                <Card className={`cursor-pointer hover:shadow-md transition-shadow ${thread.isPinned ? 'border-primary' : ''}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2 mb-1">
                      {thread.isPinned && (
                        <Badge variant="outline" className="text-primary border-primary">Pinned</Badge>
                      )}
                      {thread.isLocked && (
                        <Badge variant="outline" className="text-orange-500 border-orange-500">Locked</Badge>
                      )}
                      {categoryMap[thread.categoryId] && (
                        <Badge variant="secondary">
                          {categoryMap[thread.categoryId].name}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className={`text-xl ${thread.isPinned ? 'text-primary' : ''}`}>
                      {thread.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-gray-600 dark:text-gray-400 line-clamp-2">
                      {thread.content.replace(/<[^>]*>?/gm, '')}
                    </p>
                  </CardContent>
                  <CardFooter className="text-sm text-gray-500 flex flex-wrap gap-4">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      <span>{thread.viewCount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>
                        Created {formatDate(thread.createdAt)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>Last activity {formatDate(thread.lastActivityAt)}</span>
                    </div>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border rounded-lg">
            <MessageSquare className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-xl font-medium mb-2">No Threads Found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              There are no discussions matching your criteria.
            </p>
            <Button asChild>
              <Link href="/">Go Home</Link>
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}