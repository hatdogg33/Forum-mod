import { Layout } from "@/components/layout";
import { TestAchievementNotification } from "@/components/achievements/test-achievement-notification";

export default function TestAchievementsPage() {
  return (
    <Layout>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">
          Achievement Animation Testing
        </h1>
        
        <div className="bg-card rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">About This Test</h2>
          <p className="text-muted-foreground mb-4">
            This page allows you to test the animated achievement celebration system.
            Click the button below to trigger a test achievement unlock animation.
          </p>
          <p className="text-muted-foreground">
            The animation includes confetti effects, badge animations, and sound effects.
            Note that sound will only play after user interaction due to browser policies.
          </p>
        </div>
        
        <div className="bg-card rounded-lg shadow-md p-6">
          <TestAchievementNotification />
        </div>
      </div>
    </Layout>
  );
}