import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Download, CheckCircle, AlertCircle, Smartphone, Search, ArrowRight } from "lucide-react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Redirect, useLocation } from "wouter";

const appImportSchema = z.object({
  appId: z.string().min(3, { message: "App ID must be at least 3 characters long" }),
});

type AppImportFormValues = z.infer<typeof appImportSchema>;

interface AppPreview {
  id: string;
  name: string;
  developer: string;
  icon: string;
  description: string;
  category: string;
  rating: number;
  installs: string;
  lastUpdated: string;
  size: string;
  version: string;
}

export default function PlaystoreImportPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [appPreview, setAppPreview] = useState<AppPreview | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [importSuccess, setImportSuccess] = useState(false);

  // Redirect if not admin
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }

  const form = useForm<AppImportFormValues>({
    resolver: zodResolver(appImportSchema),
    defaultValues: {
      appId: "",
    },
  });

  // Fetch app info mutation
  const fetchAppMutation = useMutation({
    mutationFn: async (data: AppImportFormValues) => {
      setIsLoading(true);
      try {
        // In a real implementation, this would call the backend API
        // For demo purposes, we'll simulate a response
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Simulate app preview data
        const appData: AppPreview = {
          id: data.appId,
          name: "Game Mod Toolkit",
          developer: "ModStudio Inc.",
          icon: "https://play-lh.googleusercontent.com/sample-icon-url",
          description: "A comprehensive tool for game modding enthusiasts. Create, edit, and share game modifications with ease. Features include texture editing, 3D model manipulation, sound replacement, and much more.",
          category: "Tools",
          rating: 4.7,
          installs: "1,000,000+",
          lastUpdated: "April 10, 2025",
          size: "45 MB",
          version: "2.3.1",
        };
        
        setAppPreview(appData);
        return appData;
      } catch (error) {
        throw new Error("Failed to fetch app information");
      } finally {
        setIsLoading(false);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Import app mutation
  const importAppMutation = useMutation({
    mutationFn: async (app: AppPreview) => {
      setIsImporting(true);
      setImportProgress(0);
      
      try {
        // This would be a real API call in production
        // For demo purposes, we'll simulate the import process with progress updates
        
        // Step 1: Fetch app details
        await new Promise(resolve => setTimeout(resolve, 1000));
        setImportProgress(20);
        
        // Step 2: Process images and assets
        await new Promise(resolve => setTimeout(resolve, 1000));
        setImportProgress(40);
        
        // Step 3: Extract features and mods
        await new Promise(resolve => setTimeout(resolve, 1000));
        setImportProgress(60);
        
        // Step 4: Map to database schema
        await new Promise(resolve => setTimeout(resolve, 1000));
        setImportProgress(80);
        
        // Step 5: Save to database
        await new Promise(resolve => setTimeout(resolve, 1000));
        setImportProgress(100);
        
        // Final success
        setImportSuccess(true);
        await new Promise(resolve => setTimeout(resolve, 500));
        
        return app;
      } catch (error) {
        throw new Error("Failed to import app");
      } finally {
        setIsImporting(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mods"] });
      toast({
        title: "Success",
        description: "App successfully imported as mods",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSearch = (data: AppImportFormValues) => {
    fetchAppMutation.mutate(data);
  };

  const handleImport = () => {
    if (!appPreview) return;
    setIsConfirmDialogOpen(false);
    importAppMutation.mutate(appPreview);
  };

  const handleViewMods = () => {
    navigate("/mods");
  };

  return (
    <>
      <Helmet>
        <title>Import from PlayStore | Admin Dashboard</title>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Import from PlayStore</h1>
            <p className="text-muted-foreground">
              Import mods from PlayStore apps automatically
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Search App</CardTitle>
              <CardDescription>
                Enter a PlayStore app ID to import its mods.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSearch)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="appId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>PlayStore App ID</FormLabel>
                        <FormControl>
                          <div className="flex w-full items-center space-x-2">
                            <Input placeholder="com.example.modapp" {...field} />
                            <Button type="submit" disabled={isLoading}>
                              {isLoading ? (
                                <div className="animate-spin h-4 w-4 border-2 border-t-transparent rounded-full" />
                              ) : (
                                <Search className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        </FormControl>
                        <FormDescription>
                          Find this in the PlayStore URL after "id="
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="rounded-lg border p-4 text-sm">
                    <h3 className="font-medium flex items-center mb-2">
                      <Smartphone className="h-4 w-4 mr-2" />
                      How to find an app ID
                    </h3>
                    <ol className="space-y-2 ml-6 list-decimal">
                      <li>Go to the Google Play Store</li>
                      <li>Navigate to the app page</li>
                      <li>Look at the URL in your browser</li>
                      <li>The app ID appears after "id=" in the URL</li>
                      <li>Example: "com.example.modapp"</li>
                    </ol>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>App Preview</CardTitle>
              <CardDescription>
                Review app details before importing
              </CardDescription>
            </CardHeader>
            <CardContent>
              {appPreview ? (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-6">
                    <div className="w-24 h-24 rounded-xl bg-slate-100 dark:bg-slate-800 overflow-hidden shrink-0 mx-auto sm:mx-0">
                      {/* This would be the app icon in production */}
                      <div className="w-full h-full flex items-center justify-center text-primary">
                        <Smartphone className="h-12 w-12" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h2 className="text-xl font-bold">{appPreview.name}</h2>
                      <p className="text-muted-foreground">{appPreview.developer}</p>
                      <div className="flex items-center mt-2 text-sm">
                        <span className="font-medium mr-4">
                          {appPreview.rating.toFixed(1)} ★
                        </span>
                        <span className="mr-4">{appPreview.installs} installs</span>
                        <span>{appPreview.category}</span>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        <div className="text-xs bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded">
                          Version: {appPreview.version}
                        </div>
                        <div className="text-xs bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded">
                          Size: {appPreview.size}
                        </div>
                        <div className="text-xs bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded">
                          Updated: {appPreview.lastUpdated}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Description</h3>
                    <p className="text-sm text-muted-foreground">{appPreview.description}</p>
                  </div>

                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">Importable Content</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Mod resources</span>
                        <span className="font-medium">24 items</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Assets</span>
                        <span className="font-medium">86 files</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Game compatibility</span>
                        <span className="font-medium">12 games</span>
                      </div>
                    </div>
                  </div>

                  {importSuccess ? (
                    <div className="flex flex-col items-center justify-center py-4 text-center">
                      <CheckCircle className="h-12 w-12 text-green-500 mb-2" />
                      <h3 className="text-lg font-medium">Import Complete!</h3>
                      <p className="text-muted-foreground mb-4">
                        All mod content has been successfully imported from {appPreview.name}.
                      </p>
                      <Button onClick={handleViewMods}>
                        View Imported Mods
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  ) : isImporting ? (
                    <div className="space-y-4 py-4">
                      <h3 className="font-medium text-center">Importing App Content...</h3>
                      <Progress value={importProgress} className="h-2" />
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>Processing</span>
                        <span>{importProgress}%</span>
                      </div>
                    </div>
                  ) : (
                    <Button 
                      className="w-full mt-4" 
                      onClick={() => setIsConfirmDialogOpen(true)}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Import as Mods
                    </Button>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <Search className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No App Selected</h3>
                  <p className="text-muted-foreground">
                    Search for a PlayStore app to see preview information.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Confirmation Dialog */}
        <AlertDialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Import App Content</AlertDialogTitle>
              <AlertDialogDescription>
                This will import all mod content from "{appPreview?.name}" and create mod entries in your database.
                The process may take a few minutes depending on the amount of content.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleImport}
                className="bg-primary hover:bg-primary/90"
              >
                Import Now
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </>
  );
}