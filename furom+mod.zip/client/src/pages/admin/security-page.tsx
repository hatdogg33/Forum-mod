import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, AlertCircle, CheckCircle, XCircle, LogOut } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Input } from "@/components/ui/input";
import { AdminLayout } from "@/components/layouts/admin-layout";

interface SecurityLog {
  id: number;
  ipAddress: string;
  path: string;
  eventType: string;
  method: string;
  createdAt: string;
  userId: number | null;
  details: string | null;
}

export default function SecurityPage() {
  const [page, setPage] = useState(1);
  const [filterIP, setFilterIP] = useState("");
  const [filterEvent, setFilterEvent] = useState("");
  
  const { data, isLoading, error } = useQuery<SecurityLog[]>({
    queryKey: ['/api/admin/security-logs', page, filterIP, filterEvent],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.append('page', page.toString());
      if (filterIP) params.append('ip', filterIP);
      if (filterEvent) params.append('event', filterEvent);
      
      const res = await fetch(`/api/admin/security-logs?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch security logs');
      return res.json();
    }
  });
  
  const getEventIcon = (eventType: string) => {
    if (eventType.includes('successful')) return <CheckCircle className="h-4 w-4 text-green-500" />;
    if (eventType.includes('failed') || eventType.includes('error')) return <XCircle className="h-4 w-4 text-red-500" />;
    if (eventType.includes('logout')) return <LogOut className="h-4 w-4 text-blue-500" />;
    return <AlertCircle className="h-4 w-4 text-yellow-500" />;
  };
  
  const getEventBadgeColor = (eventType: string) => {
    if (eventType.includes('successful')) return "bg-green-100 text-green-800";
    if (eventType.includes('failed') || eventType.includes('error')) return "bg-red-100 text-red-800";
    if (eventType.includes('logout')) return "bg-blue-100 text-blue-800";
    return "bg-yellow-100 text-yellow-800";
  };
  
  return (
    <AdminLayout>
      <div className="container py-8">
        <Card>
          <CardHeader>
            <CardTitle>Security Logs</CardTitle>
            <CardDescription>
              Monitor login attempts and security events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <Input 
                    placeholder="Filter by IP address..." 
                    value={filterIP}
                    onChange={(e) => setFilterIP(e.target.value)}
                  />
                </div>
                <div className="flex-1">
                  <Input 
                    placeholder="Filter by event type..." 
                    value={filterEvent}
                    onChange={(e) => setFilterEvent(e.target.value)}
                  />
                </div>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : error ? (
                <div className="flex justify-center items-center py-8 text-red-500">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  <span>Error loading security logs</span>
                </div>
              ) : data && data.length > 0 ? (
                <>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Event</TableHead>
                          <TableHead>IP Address</TableHead>
                          <TableHead>Path</TableHead>
                          <TableHead>Method</TableHead>
                          <TableHead>User ID</TableHead>
                          <TableHead>Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                {getEventIcon(log.eventType)}
                                <Badge variant="outline" className={getEventBadgeColor(log.eventType)}>
                                  {log.eventType.replace(/_/g, ' ')}
                                </Badge>
                              </div>
                            </TableCell>
                            <TableCell>{log.ipAddress}</TableCell>
                            <TableCell>{log.path}</TableCell>
                            <TableCell>{log.method}</TableCell>
                            <TableCell>{log.userId || '-'}</TableCell>
                            <TableCell>
                              {format(new Date(log.createdAt), 'MMM d, yyyy HH:mm:ss')}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(p => Math.max(1, p - 1))}
                          disabled={page === 1}
                        />
                      </PaginationItem>
                      {[...Array(3)].map((_, i) => {
                        const pageNum = page - 1 + i;
                        if (pageNum < 1) return null;
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink
                              onClick={() => setPage(pageNum)}
                              isActive={pageNum === page}
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(p => p + 1)}
                          disabled={data.length < 10} // Assuming page size of 10
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </>
              ) : (
                <div className="flex justify-center items-center py-8 text-muted-foreground">
                  No security logs found
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}