import React from "react";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Redirect } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  ArrowUpRight,
  Users,
  MessageSquare,
  FileText,
  Activity,
  BarChart3,
  Flag,
  Settings,
  Shield,
  ShieldAlert,
  Server,
} from "lucide-react";
import { Link } from "wouter";

// Types for statistics
interface DashboardStats {
  userCount: number;
  newUsersToday: number;
  threadCount: number;
  newThreadsToday: number;
  postCount: number;
  newPostsToday: number;
  visitsToday: number;
  reportsCount: number;
}

interface SystemStatus {
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  uptime: number;
  databaseSize: string;
}

export default function AdminDashboardPage() {
  const { user } = useAuth();
  
  // Redirect if not admin
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }

  // Fetch dashboard statistics
  const { data: stats, isLoading: isStatsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/stats"],
    // If the API isn't implemented yet, mock data
    placeholderData: {
      userCount: 256,
      newUsersToday: 12,
      threadCount: 478,
      newThreadsToday: 18,
      postCount: 3862,
      newPostsToday: 154,
      visitsToday: 1254,
      reportsCount: 3,
    },
  });

  // Fetch system status
  const { data: systemStatus, isLoading: isSystemLoading } = useQuery<SystemStatus>({
    queryKey: ["/api/admin/system"],
    // If the API isn't implemented yet, mock data
    placeholderData: {
      cpuUsage: 24,
      memoryUsage: 46,
      diskUsage: 32,
      uptime: 684345, // seconds
      databaseSize: "256 MB",
    },
  });

  // Format uptime
  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / (24 * 3600));
    const hours = Math.floor((seconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    return `${days}d ${hours}h ${minutes}m`;
  };

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | ModForum</title>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage and monitor your forum.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline">
              <Link href="/admin/categories">
                <Settings className="mr-2 h-4 w-4" />
                Manage Categories
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/admin/users">
                <Users className="mr-2 h-4 w-4" />
                User Management
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/admin/security">
                <Shield className="mr-2 h-4 w-4" />
                Security
              </Link>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid grid-cols-3 md:w-[400px]">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isStatsLoading ? "-" : stats?.userCount}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    +{isStatsLoading ? "-" : stats?.newUsersToday} today
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Threads</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isStatsLoading ? "-" : stats?.threadCount}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    +{isStatsLoading ? "-" : stats?.newThreadsToday} today
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Posts</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isStatsLoading ? "-" : stats?.postCount}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    +{isStatsLoading ? "-" : stats?.newPostsToday} today
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Reports</CardTitle>
                  <Flag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isStatsLoading ? "-" : stats?.reportsCount}</div>
                  <div className="mt-1">
                    {stats?.reportsCount && stats.reportsCount > 0 ? (
                      <Button size="sm" variant="destructive" asChild className="text-xs h-7 mt-1">
                        <Link href="/admin/reports">
                          View Reports
                          <ArrowUpRight className="ml-1 h-3 w-3" />
                        </Link>
                      </Button>
                    ) : (
                      <p className="text-xs text-muted-foreground">No pending reports</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>User and content activity over the past week.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px] flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        Activity charts will appear here once implemented
                      </p>
                      <Button variant="link" asChild className="mt-2">
                        <Link href="/admin/analytics">
                          View Analytics
                          <ArrowUpRight className="ml-1 h-3 w-3" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Frequently used admin tools</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/admin/categories">
                      <Settings className="mr-2 h-4 w-4" />
                      Manage Categories
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/admin/users">
                      <Users className="mr-2 h-4 w-4" />
                      User Management
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/admin/security">
                      <Shield className="mr-2 h-4 w-4" />
                      Security Settings
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/admin/reports">
                      <Flag className="mr-2 h-4 w-4" />
                      Content Reports
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Daily Visits</CardTitle>
                  <CardDescription>Today's visitor statistics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isStatsLoading ? "-" : stats?.visitsToday}</div>
                  <div className="h-[150px] flex items-center justify-center mt-4">
                    <Activity className="h-16 w-16 text-muted-foreground/50" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Latest Registrations</CardTitle>
                  <CardDescription>Users who joined recently</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Placeholder for actual data */}
                    <div className="flex items-center gap-4">
                      <div className="bg-primary/10 rounded-full h-10 w-10 flex items-center justify-center">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">Real-time registration data</p>
                        <p className="text-xs text-muted-foreground">Will appear here when implemented</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isSystemLoading ? "-" : `${systemStatus?.cpuUsage}%`}</div>
                  <div className="mt-2 h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-2 bg-primary"
                      style={{ width: `${isSystemLoading ? 0 : systemStatus?.cpuUsage}%` }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isSystemLoading ? "-" : `${systemStatus?.memoryUsage}%`}</div>
                  <div className="mt-2 h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-2 bg-primary"
                      style={{ width: `${isSystemLoading ? 0 : systemStatus?.memoryUsage}%` }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Disk Usage</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isSystemLoading ? "-" : `${systemStatus?.diskUsage}%`}</div>
                  <div className="mt-2 h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-2 bg-primary"
                      style={{ width: `${isSystemLoading ? 0 : systemStatus?.diskUsage}%` }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Server Uptime</CardTitle>
                  <ShieldAlert className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{isSystemLoading ? "-" : formatUptime(systemStatus?.uptime || 0)}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Database size: {isSystemLoading ? "-" : systemStatus?.databaseSize}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Real-time Database Monitoring</CardTitle>
                <CardDescription>
                  Monitor database performance metrics and query execution in real-time.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center">
                  <div className="text-center">
                    <Activity className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Real-time database monitoring will be available soon
                    </p>
                    <Button variant="link" asChild className="mt-2">
                      <Link href="/admin/database">
                        View Database Details
                        <ArrowUpRight className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}