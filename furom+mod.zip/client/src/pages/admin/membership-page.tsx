import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Pencil, Trash, Eye, CreditCard } from "lucide-react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { BadgeAlert } from "lucide-react";
import { Redirect } from "wouter";

type MembershipPlan = "free" | "basic" | "premium" | "pro";

interface MembershipTier {
  id: number;
  name: string;
  plan: MembershipPlan;
  price: number;
  interval: string;
  description: string;
  features: string[];
  isActive: boolean;
  createdAt: string;
}

const membershipSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters long" }),
  plan: z.enum(["free", "basic", "premium", "pro"]),
  price: z.coerce.number().min(0, { message: "Price must be a positive number" }),
  interval: z.string().min(3, { message: "Interval must be at least 3 characters long" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters long" }),
  features: z.string().transform(str => str.split('\n').filter(f => f.trim().length > 0)),
  isActive: z.boolean().default(true),
});

type MembershipFormValues = z.infer<typeof membershipSchema>;

export default function AdminMembershipPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTier, setSelectedTier] = useState<MembershipTier | null>(null);

  // Redirect if not admin
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }

  // Fetch membership tiers
  const { data: tiers = [], isLoading } = useQuery<MembershipTier[]>({
    queryKey: ["/api/admin/membership-tiers"],
    // If the API isn't implemented yet, mock data
    placeholderData: [
      {
        id: 1,
        name: "Free",
        plan: "free",
        price: 0,
        interval: "month",
        description: "Basic access to the forum",
        features: ["Access to public forums", "Create and reply to threads", "Basic profile customization"],
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        name: "Basic",
        plan: "basic",
        price: 4.99,
        interval: "month",
        description: "Enhanced access with basic mod downloads",
        features: ["All Free features", "Access to basic mods", "Ad-free experience", "Enhanced profile features"],
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 3,
        name: "Premium",
        plan: "premium",
        price: 9.99,
        interval: "month",
        description: "Premium access with advanced mod downloads",
        features: ["All Basic features", "Access to premium mods", "Priority support", "Custom badges", "Early access to new features"],
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 4,
        name: "Pro",
        plan: "pro",
        price: 19.99,
        interval: "month",
        description: "Full access to all mods and exclusive features",
        features: ["All Premium features", "Unlimited mod downloads", "Exclusive pro-only mods", "Direct developer support", "Beta access to upcoming features"],
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ],
  });

  // Create membership form
  const createForm = useForm<MembershipFormValues>({
    resolver: zodResolver(membershipSchema),
    defaultValues: {
      name: "",
      plan: "basic",
      price: 0,
      interval: "month",
      description: "",
      features: "",
      isActive: true,
    },
  });

  // Edit membership form
  const editForm = useForm<MembershipFormValues>({
    resolver: zodResolver(membershipSchema),
    defaultValues: {
      name: "",
      plan: "basic",
      price: 0,
      interval: "month",
      description: "",
      features: "",
      isActive: true,
    },
  });

  // Create membership tier mutation
  const createMembershipMutation = useMutation({
    mutationFn: async (data: MembershipFormValues) => {
      const res = await apiRequest("POST", "/api/admin/membership-tiers", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create membership tier");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({
        title: "Success",
        description: "Membership tier created successfully",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update membership tier mutation
  const updateMembershipMutation = useMutation({
    mutationFn: async (data: MembershipFormValues & { id: number }) => {
      const { id, ...formData } = data;
      const res = await apiRequest("PATCH", `/api/admin/membership-tiers/${id}`, formData);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to update membership tier");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({
        title: "Success",
        description: "Membership tier updated successfully",
      });
      setIsEditDialogOpen(false);
      editForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete membership tier mutation
  const deleteMembershipMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/membership-tiers/${id}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to delete membership tier");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({
        title: "Success",
        description: "Membership tier deleted successfully",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreateMembership = (data: MembershipFormValues) => {
    createMembershipMutation.mutate(data);
  };

  const handleUpdateMembership = (data: MembershipFormValues) => {
    if (!selectedTier) return;
    updateMembershipMutation.mutate({ id: selectedTier.id, ...data });
  };

  const handleDeleteMembership = () => {
    if (!selectedTier) return;
    deleteMembershipMutation.mutate(selectedTier.id);
  };

  const openEditDialog = (tier: MembershipTier) => {
    setSelectedTier(tier);
    editForm.reset({
      name: tier.name,
      plan: tier.plan,
      price: tier.price,
      interval: tier.interval,
      description: tier.description,
      features: tier.features.join('\n'),
      isActive: tier.isActive,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (tier: MembershipTier) => {
    setSelectedTier(tier);
    setIsDeleteDialogOpen(true);
  };

  const formatPrice = (price: number) => {
    return price === 0 ? "Free" : `$${price.toFixed(2)}`;
  };

  return (
    <>
      <Helmet>
        <title>Manage Membership Tiers | Admin Dashboard</title>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Manage Membership Tiers</h1>
            <p className="text-muted-foreground">Create, edit, and manage membership pricing and features</p>
          </div>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Membership Tier
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Membership Tiers</CardTitle>
            <CardDescription>
              Configure membership levels, pricing, and features for your users.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center py-10">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : tiers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center">
                <BadgeAlert className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Membership Tiers Found</h3>
                <p className="text-muted-foreground mt-2 mb-4">
                  Get started by creating your first membership tier.
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Membership Tier
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Features</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tiers.map((tier) => (
                      <TableRow key={tier.id}>
                        <TableCell className="font-medium">{tier.name}</TableCell>
                        <TableCell className="capitalize">{tier.plan}</TableCell>
                        <TableCell>{formatPrice(tier.price)}{tier.price > 0 ? `/${tier.interval}` : ""}</TableCell>
                        <TableCell>
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              tier.isActive
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
                            }`}
                          >
                            {tier.isActive ? "Active" : "Inactive"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate">
                            {tier.features.length} features
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon" asChild>
                              <a href={`/membership`} target="_blank" rel="noopener noreferrer">
                                <Eye className="h-4 w-4" />
                                <span className="sr-only">View</span>
                              </a>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(tier)}
                            >
                              <Pencil className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openDeleteDialog(tier)}
                              disabled={tier.plan === "free"} // Cannot delete free tier
                            >
                              <Trash className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Create Membership Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Create New Membership Tier</DialogTitle>
              <DialogDescription>
                Create a new membership tier with custom pricing and features.
              </DialogDescription>
            </DialogHeader>

            <Form {...createForm}>
              <form onSubmit={createForm.handleSubmit(handleCreateMembership)} className="space-y-6">
                <FormField
                  control={createForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Premium Plus" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={createForm.control}
                    name="plan"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plan Type</FormLabel>
                        <FormControl>
                          <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...field}
                          >
                            <option value="free">Free</option>
                            <option value="basic">Basic</option>
                            <option value="premium">Premium</option>
                            <option value="pro">Pro</option>
                          </select>
                        </FormControl>
                        <FormDescription>
                          The tier level of this membership.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" min="0" placeholder="e.g. 9.99" {...field} />
                        </FormControl>
                        <FormDescription>
                          Set to 0 for free tier.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={createForm.control}
                  name="interval"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Billing Interval</FormLabel>
                      <FormControl>
                        <select
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          {...field}
                        >
                          <option value="month">Monthly</option>
                          <option value="year">Yearly</option>
                        </select>
                      </FormControl>
                      <FormDescription>
                        How often users are billed for this membership.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe what this membership tier offers..."
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createForm.control}
                  name="features"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Features</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="List features, one per line..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Add each feature on a new line.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Active Status</FormLabel>
                        <FormDescription>
                          Make this membership tier available to users
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMembershipMutation.isPending}
                  >
                    {createMembershipMutation.isPending ? (
                      <>
                        <div className="animate-spin mr-2 h-4 w-4 border-2 border-t-transparent rounded-full" />
                        Creating...
                      </>
                    ) : (
                      "Create Membership Tier"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Edit Membership Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Edit Membership Tier</DialogTitle>
              <DialogDescription>
                Update the details of this membership tier.
              </DialogDescription>
            </DialogHeader>

            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(handleUpdateMembership)} className="space-y-6">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Premium Plus" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={editForm.control}
                    name="plan"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plan Type</FormLabel>
                        <FormControl>
                          <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...field}
                            disabled={selectedTier?.plan === "free"} // Cannot change free tier type
                          >
                            <option value="free">Free</option>
                            <option value="basic">Basic</option>
                            <option value="premium">Premium</option>
                            <option value="pro">Pro</option>
                          </select>
                        </FormControl>
                        <FormDescription>
                          The tier level of this membership.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01" 
                            min="0" 
                            placeholder="e.g. 9.99" 
                            {...field}
                            disabled={selectedTier?.plan === "free"} // Cannot change free tier price
                          />
                        </FormControl>
                        <FormDescription>
                          Set to 0 for free tier.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={editForm.control}
                  name="interval"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Billing Interval</FormLabel>
                      <FormControl>
                        <select
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          {...field}
                          disabled={selectedTier?.plan === "free"} // Cannot change free tier interval
                        >
                          <option value="month">Monthly</option>
                          <option value="year">Yearly</option>
                        </select>
                      </FormControl>
                      <FormDescription>
                        How often users are billed for this membership.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe what this membership tier offers..."
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="features"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Features</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="List features, one per line..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Add each feature on a new line.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Active Status</FormLabel>
                        <FormDescription>
                          Make this membership tier available to users
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={selectedTier?.plan === "free"} // Cannot disable free tier
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={updateMembershipMutation.isPending}
                  >
                    {updateMembershipMutation.isPending ? (
                      <>
                        <div className="animate-spin mr-2 h-4 w-4 border-2 border-t-transparent rounded-full" />
                        Updating...
                      </>
                    ) : (
                      "Update Membership Tier"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Delete Membership Alert Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Membership Tier</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete the "{selectedTier?.name}" membership tier? This action cannot be undone
                and may affect users who currently have this membership level.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteMembership}
                className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
              >
                {deleteMembershipMutation.isPending ? (
                  <>
                    <div className="animate-spin mr-2 h-4 w-4 border-2 border-t-transparent rounded-full" />
                    Deleting...
                  </>
                ) : (
                  "Delete Membership Tier"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </>
  );
}