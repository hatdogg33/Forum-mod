import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, CreditCard, CheckCircle2 } from "lucide-react";

// PayPal initial options
const paypalOptions = {
  clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
  currency: "USD",
  intent: "capture"
};

function PayPalCheckout({ planId, amount }: { planId: string, amount: number }) {
  const [succeeded, setSucceeded] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const { user } = useAuth();

  // Function to handle successful payment
  const handleSuccess = async (details: any) => {
    try {
      // Call our API to confirm the payment and update user's membership
      const response = await apiRequest("POST", "/api/payment-success", {
        paymentId: details.id,
        planId,
        orderId: details.orderID,
        userId: user?.id
      });

      if (!response.ok) {
        throw new Error("Failed to verify payment");
      }

      setSucceeded(true);
      toast({
        title: "Payment Successful",
        description: "Your membership has been activated!",
      });
      
      // Wait a moment before redirecting
      setTimeout(() => {
        navigate("/");
      }, 2000);
    } catch (error: any) {
      setErrorMessage(error.message || "Payment verification failed");
      toast({
        title: "Payment Verification Failed",
        description: error.message || "There was an issue confirming your payment",
        variant: "destructive",
      });
    }
  };

  if (succeeded) {
    return (
      <div className="text-center py-12">
        <div className="mb-6 flex justify-center">
          <div className="rounded-full bg-green-100 p-3 dark:bg-green-900">
            <CheckCircle2 className="h-8 w-8 text-green-600 dark:text-green-300" />
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
        <p className="text-muted-foreground mb-6">
          Your membership has been successfully upgraded. Redirecting you to the home page...
        </p>
        <Button onClick={() => navigate("/")}>Return Home</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="text-lg font-medium mb-4">Payment Options</p>
        <div className="mb-4">
          <p className="text-sm text-muted-foreground mb-3">
            Choose your preferred payment method to complete your subscription:
          </p>
          
          {/* PayPal Payment Button */}
          <PayPalButtons
            createOrder={(data, actions) => {
              return actions.order.create({
                intent: "CAPTURE",
                purchase_units: [
                  {
                    amount: {
                      value: amount.toFixed(2),
                      currency_code: "USD"
                    },
                    description: `${planId.charAt(0).toUpperCase() + planId.slice(1)} Membership Plan`,
                    custom_id: `plan_${planId}_user_${user?.id}`
                  }
                ]
              });
            }}
            onApprove={async (data, actions) => {
              // Capture the payment
              if (actions.order) {
                const details = await actions.order.capture();
                handleSuccess(details);
              }
            }}
            onError={(err) => {
              setErrorMessage("PayPal payment failed. Please try again.");
              toast({
                title: "Payment Failed",
                description: "There was an issue processing your PayPal payment",
                variant: "destructive",
              });
              console.error(err);
            }}
            style={{ layout: "vertical", label: "subscribe" }}
          />
        </div>

        <div className="mt-6 pt-6 border-t">
          <p className="text-sm text-muted-foreground">
            By continuing, you agree to our Terms of Service and authorize us to charge you ${amount.toFixed(2)}/month until you cancel.
          </p>
        </div>
        
        {/* Binance Pay option */}
        <div className="mt-6 pt-6 border-t">
          <p className="text-sm text-muted-foreground mb-3">
            Or pay with Binance:
          </p>
          <div className="space-y-4">
            <div className="border rounded-md p-4">
              <label htmlFor="binanceUserId" className="block text-sm font-medium mb-2">
                Binance User ID
              </label>
              <input 
                id="binanceUserId" 
                type="text" 
                className="w-full p-2 border rounded-md"
                placeholder="Enter your Binance User ID"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Your Binance ID can be found in your Binance account settings
              </p>
            </div>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => {
                const binanceUserId = (document.getElementById('binanceUserId') as HTMLInputElement).value;
                
                if (!binanceUserId) {
                  toast({
                    title: "Missing Information",
                    description: "Please enter your Binance User ID",
                    variant: "destructive",
                  });
                  return;
                }
                
                // Process Binance payment
                apiRequest("POST", "/api/binance-payment", {
                  binanceUserId,
                  planId,
                  userId: user?.id
                })
                .then(response => {
                  if (!response.ok) {
                    throw new Error("Failed to process Binance payment");
                  }
                  return response.json();
                })
                .then(data => {
                  setSucceeded(true);
                  toast({
                    title: "Payment Successful",
                    description: "Your membership has been activated with Binance!",
                  });
                  
                  // Wait a moment before redirecting
                  setTimeout(() => {
                    navigate("/");
                  }, 2000);
                })
                .catch(error => {
                  toast({
                    title: "Payment Failed",
                    description: error.message || "There was an error processing your Binance payment",
                    variant: "destructive",
                  });
                });
              }}
            >
              Pay with Binance
            </Button>
          </div>
        </div>
      </div>

      {errorMessage && (
        <p className="text-red-500 text-sm mt-4">{errorMessage}</p>
      )}
    </div>
  );
}

export default function CheckoutPage() {
  const searchParams = new URLSearchParams(window.location.search);
  const planId = searchParams.get("plan") || "premium";
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const planDetails = {
    basic: { name: "Basic", amount: 4.99 },
    premium: { name: "Premium", amount: 9.99 },
    pro: { name: "Pro", amount: 19.99 },
  };

  // @ts-ignore - We're checking for invalid plan values below
  const plan = planDetails[planId] || planDetails.premium;

  useEffect(() => {
    // Redirect if not logged in
    if (!user) {
      navigate("/auth");
      return;
    }

    // Check if valid plan
    if (!planDetails[planId as keyof typeof planDetails]) {
      toast({
        title: "Invalid Plan",
        description: "The selected membership plan is not valid",
        variant: "destructive",
      });
      navigate("/membership");
      return;
    }
  }, [planId, user, navigate, toast]);

  return (
    <Layout>
      <div className="container max-w-3xl mx-auto py-12 px-4">
        <div className="mb-8">
          <Button variant="ghost" onClick={() => navigate("/membership")} className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Plans
          </Button>
          <h1 className="text-3xl font-bold">Complete Your Subscription</h1>
          <p className="text-muted-foreground">You're signing up for the {plan.name} membership plan</p>
        </div>

        <div className="grid gap-8 md:grid-cols-5">
          <div className="md:col-span-3">
            <Card>
              <CardContent className="p-6">
                <PayPalScriptProvider options={paypalOptions}>
                  <PayPalCheckout planId={planId} amount={plan.amount} />
                </PayPalScriptProvider>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Membership plan details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>{plan.name} Membership</span>
                    <span>${plan.amount.toFixed(2)}/month</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium">
                    <span>Total (monthly)</span>
                    <span>${plan.amount.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/50 text-sm">
                <p>
                  You can cancel your subscription anytime from your account settings.
                </p>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}