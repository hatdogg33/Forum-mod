import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import { CategorySkeletonList } from "@/components/ui/skeletons/category-skeleton";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { LayoutGrid, MessageSquare, Users, Shield, Book, Gamepad2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define the types for our data
interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  isActive: boolean;
  createdAt: string;
}

export default function CategoriesPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    }
  });

  // Group categories by type (for demonstration purposes)
  const gameCategories = categories?.filter(cat => 
    cat.name.toLowerCase().includes("game") || 
    cat.description.toLowerCase().includes("game")
  ) || [];
  
  const supportCategories = categories?.filter(cat => 
    cat.name.toLowerCase().includes("support") || 
    cat.description.toLowerCase().includes("help") ||
    cat.description.toLowerCase().includes("support")
  ) || [];
  
  const communityCategories = categories?.filter(cat => 
    !gameCategories.includes(cat) && !supportCategories.includes(cat)
  ) || [];

  if (isCategoriesLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <PageLoadingSkeleton />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Forum Categories</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Browse all modding discussions by category
          </p>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-4 md:w-auto">
            <TabsTrigger value="all" className="flex items-center gap-2">
              <LayoutGrid className="h-4 w-4" />
              <span className="hidden md:inline">All Categories</span>
            </TabsTrigger>
            <TabsTrigger value="games" className="flex items-center gap-2">
              <Gamepad2 className="h-4 w-4" />
              <span className="hidden md:inline">Games</span>
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden md:inline">Support</span>
            </TabsTrigger>
            <TabsTrigger value="community" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden md:inline">Community</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {categories?.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="games" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {gameCategories.length > 0 ? (
                gameCategories.map((category) => (
                  <CategoryCard key={category.id} category={category} />
                ))
              ) : (
                <div className="col-span-full text-center py-8">
                  <Gamepad2 className="mx-auto h-12 w-12 text-gray-400 mb-2" />
                  <h3 className="text-xl font-medium mb-1">No Game Categories</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Game categories will appear here once created.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="support" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {supportCategories.length > 0 ? (
                supportCategories.map((category) => (
                  <CategoryCard key={category.id} category={category} />
                ))
              ) : (
                <div className="col-span-full text-center py-8">
                  <Shield className="mx-auto h-12 w-12 text-gray-400 mb-2" />
                  <h3 className="text-xl font-medium mb-1">No Support Categories</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Support categories will appear here once created.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="community" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {communityCategories.length > 0 ? (
                communityCategories.map((category) => (
                  <CategoryCard key={category.id} category={category} />
                ))
              ) : (
                <div className="col-span-full text-center py-8">
                  <Users className="mx-auto h-12 w-12 text-gray-400 mb-2" />
                  <h3 className="text-xl font-medium mb-1">No Community Categories</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Community categories will appear here once created.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

// Category Card Component
function CategoryCard({ category }: { category: Category }) {
  // Calculate a random number to show as thread count for demo purposes
  const threadCount = Math.floor(Math.random() * 50) + 1;
  
  return (
    <Link href={`/categories/${category.slug}`}>
      <Card className="h-full cursor-pointer hover:shadow-md transition-shadow">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>{category.name}</span>
            {!category.isActive && (
              <span className="text-xs bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 py-1 px-2 rounded">
                Inactive
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-400 mb-3">
            {category.description}
          </p>
          <div className="flex items-center text-sm text-gray-500 space-x-4">
            <div className="flex items-center">
              <MessageSquare className="w-4 h-4 mr-1" />
              <span>{threadCount} threads</span>
            </div>
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-1" />
              <span>{Math.floor(threadCount * 1.5)} posts</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="pt-0 text-xs text-gray-500">
          <span>Created {formatDate(category.createdAt)}</span>
        </CardFooter>
      </Card>
    </Link>
  );
}