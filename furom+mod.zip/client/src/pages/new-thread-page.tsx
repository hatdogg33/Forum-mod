import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  isActive: boolean;
}

export default function NewThreadPage() {
  const { categoryId } = useParams();
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  // Redirect if not logged in
  if (!user) {
    navigate("/auth");
    return <div>Redirecting to login...</div>;
  }

  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/${categoryId}`],
    queryFn: async () => {
      const response = await fetch(`/api/categories/${categoryId}`);
      if (!response.ok) throw new Error("Failed to fetch category");
      return response.json();
    }
  });

  const threadMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/threads", {
        title,
        content,
        categoryId: parseInt(categoryId as string)
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create thread");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Thread created",
        description: "Your new thread has been created successfully",
      });
      navigate(`/threads/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create thread",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your thread",
        variant: "destructive",
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please enter content for your thread",
        variant: "destructive",
      });
      return;
    }

    threadMutation.mutate();
  };

  if (isCategoryLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <div className="flex justify-center items-center min-h-[40vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!category) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">Category Not Found</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              The category you're trying to post in doesn't exist or may have been moved.
            </p>
            <Button asChild>
              <a href="/">Go Home</a>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <Button
            variant="ghost"
            size="sm"
            className="gap-1 mb-4"
            onClick={() => navigate(`/categories/${category.slug}`)}
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to {category.name}</span>
          </Button>
          
          <h1 className="text-3xl font-bold">Create New Thread</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            in {category.name}
          </p>
        </div>

        <Card>
          <form onSubmit={handleSubmit}>
            <CardHeader>
              <CardTitle>Thread Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input 
                  id="title"
                  placeholder="Enter a descriptive title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  disabled={threadMutation.isPending}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">Content</Label>
                <Textarea 
                  id="content"
                  placeholder="Write your post content here..."
                  className="min-h-[200px]"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  disabled={threadMutation.isPending}
                />
                <p className="text-sm text-gray-500">
                  Markdown formatting is supported
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                type="button" 
                onClick={() => navigate(`/categories/${category.slug}`)}
                disabled={threadMutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={threadMutation.isPending}>
                {threadMutation.isPending ? "Creating Thread..." : "Create Thread"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </Layout>
  );
}