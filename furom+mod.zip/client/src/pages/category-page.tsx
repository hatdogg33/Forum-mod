import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { ThreadSkeletonList } from "@/components/ui/skeletons/thread-skeleton";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { MessageSquare, Users, Eye, Calendar, Plus, ArrowLeft } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

// Define the types for our data
interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  isActive: boolean;
  createdAt: string;
}

interface Thread {
  id: number;
  title: string;
  content: string;
  userId: number;
  categoryId: number;
  viewCount: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: string;
  lastActivityAt: string;
}

interface User {
  id: number;
  username: string;
  role: string;
  avatar: string | null;
}

export default function CategoryPage() {
  const { slug } = useParams();
  const { user } = useAuth();
  
  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/slug/${slug}`],
    queryFn: async () => {
      const response = await fetch(`/api/categories/slug/${slug}`);
      if (!response.ok) throw new Error("Failed to fetch category");
      return response.json();
    }
  });

  const { data: threads, isLoading: isThreadsLoading } = useQuery<Thread[]>({
    queryKey: [`/api/categories/${category?.id}/threads`],
    queryFn: async () => {
      if (!category) return [];
      const response = await fetch(`/api/categories/${category.id}/threads`);
      if (!response.ok) throw new Error("Failed to fetch threads");
      return response.json();
    },
    enabled: !!category
  });

  if (isCategoryLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <PageLoadingSkeleton />
        </div>
      </Layout>
    );
  }

  if (!category) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">Category Not Found</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              The category you're looking for doesn't exist or may have been moved.
            </p>
            <Button asChild>
              <Link href="/">Go Home</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-1">
            <Button variant="ghost" size="sm" className="gap-1" asChild>
              <Link href="/">
                <ArrowLeft className="h-4 w-4" />
                <span>Back</span>
              </Link>
            </Button>
          </div>
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">{category.name}</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                {category.description}
              </p>
            </div>
            {user && (
              <Button asChild>
                <Link href={`/categories/${category.id}/new-thread`}>
                  <Plus className="mr-2 h-4 w-4" />
                  <span>New Thread</span>
                </Link>
              </Button>
            )}
          </div>
        </div>

        {isThreadsLoading ? (
          <ThreadSkeletonList count={5} />
        ) : threads && threads.length > 0 ? (
          <div className="grid gap-4">
            {threads.map((thread) => (
              <Link key={thread.id} href={`/threads/${thread.id}`}>
                <Card className={`cursor-pointer hover:shadow-md transition-shadow ${thread.isPinned ? 'border-primary' : ''}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2">
                      {thread.isPinned && (
                        <Badge variant="outline" className="text-primary border-primary">Pinned</Badge>
                      )}
                      {thread.isLocked && (
                        <Badge variant="outline" className="text-orange-500 border-orange-500">Locked</Badge>
                      )}
                    </div>
                    <CardTitle className={`text-xl ${thread.isPinned ? 'text-primary' : ''}`}>
                      {thread.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-gray-600 dark:text-gray-400 line-clamp-2">
                      {thread.content.replace(/<[^>]*>?/gm, '')}
                    </p>
                  </CardContent>
                  <CardFooter className="text-sm text-gray-500 flex gap-4">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      <span>{thread.viewCount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {formatDate(thread.createdAt)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>Last activity {formatDate(thread.lastActivityAt)}</span>
                    </div>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border rounded-lg">
            <MessageSquare className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-xl font-medium mb-2">No Threads Yet</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Be the first to start a discussion in this category!
            </p>
            {user ? (
              <Button asChild>
                <Link href={`/categories/${category.id}/new-thread`}>
                  <Plus className="mr-2 h-4 w-4" />
                  <span>Create Thread</span>
                </Link>
              </Button>
            ) : (
              <Button asChild>
                <Link href="/auth">Sign In to Post</Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}