import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { ModSkeletonGrid } from "@/components/ui/skeletons/mod-skeleton";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { Plus, Download, Search, Filter } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Mod {
  id: number;
  name: string;
  description: string;
  userId: number;
  game: string;
  version: string;
  downloadUrl: string | null;
  imageUrl: string | null;
  downloadCount: number;
  createdAt: string;
  updatedAt: string;
}

interface User {
  id: number;
  username: string;
}

export default function ModsPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [gameFilter, setGameFilter] = useState<string>("all");

  const { data: mods, isLoading } = useQuery<Mod[]>({
    queryKey: ["/api/mods"],
    queryFn: async () => {
      const response = await fetch("/api/mods");
      if (!response.ok) throw new Error("Failed to fetch mods");
      return response.json();
    }
  });

  const { data: games } = useQuery<string[]>({
    queryKey: ["/api/mods/games"],
    queryFn: async () => {
      if (!mods) return [];
      // Extract unique game names from mods
      const gameSet = new Set<string>();
      mods.forEach(mod => gameSet.add(mod.game));
      return Array.from(gameSet);
    },
    enabled: !!mods
  });

  // Filter mods based on search query and game filter
  const filteredMods = mods?.filter(mod => {
    const matchesSearch = 
      mod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mod.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesGame = gameFilter === "all" || mod.game === gameFilter;
    
    return matchesSearch && matchesGame;
  });

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Game Mods</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Browse and download mods for your favorite games
            </p>
          </div>
          {user && (
            <Button asChild>
              <Link href="/mods/new">
                <Plus className="mr-2 h-4 w-4" />
                <span>Share a Mod</span>
              </Link>
            </Button>
          )}
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
            <Input
              placeholder="Search mods..." 
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="w-full md:w-64">
            <Select value={gameFilter} onValueChange={setGameFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by game" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Games</SelectItem>
                {games?.map(game => (
                  <SelectItem key={game} value={game}>{game}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <ModSkeletonGrid count={6} />
        ) : filteredMods && filteredMods.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMods.map((mod) => (
              <Link key={mod.id} href={`/mods/${mod.id}`}>
                <Card className="cursor-pointer hover:shadow-md transition-shadow h-full flex flex-col">
                  {mod.imageUrl ? (
                    <img 
                      src={mod.imageUrl} 
                      alt={mod.name}
                      className="h-48 object-cover w-full rounded-t-lg"
                    />
                  ) : (
                    <div className="h-48 bg-gray-200 dark:bg-gray-800 flex items-center justify-center rounded-t-lg">
                      <span className="text-gray-500">{mod.game}</span>
                    </div>
                  )}
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{mod.name}</CardTitle>
                      <Badge className="ml-2">{mod.version}</Badge>
                    </div>
                    <div className="text-sm text-gray-500">
                      {mod.game}
                    </div>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-gray-600 dark:text-gray-400 line-clamp-3">
                      {mod.description}
                    </p>
                  </CardContent>
                  <CardFooter className="text-sm text-gray-500 flex justify-between pt-0">
                    <span>{formatDate(mod.updatedAt)}</span>
                    <div className="flex items-center gap-1">
                      <Download className="h-4 w-4" />
                      <span>{mod.downloadCount}</span>
                    </div>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border rounded-lg">
            <h3 className="text-xl font-medium mb-2">No Mods Found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {searchQuery || gameFilter !== "all" ? 
                "Try adjusting your search or filters" : 
                "Be the first to share a mod!"}
            </p>
            {user && (
              <Button asChild>
                <Link href="/mods/new">
                  <Plus className="mr-2 h-4 w-4" />
                  <span>Share a Mod</span>
                </Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}