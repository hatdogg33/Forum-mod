import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { formatDate } from "@/lib/utils";
import { Layout } from "@/components/layout";
import { CategorySkeletonList } from "@/components/ui/skeletons/category-skeleton";
import { ThreadSkeletonList } from "@/components/ui/skeletons/thread-skeleton";
import { 
  MessageSquare, Users, Eye, Calendar, 
  Gamepad2, ShieldCheck, Upload, TrendingUp, 
  Sparkles, Trophy, UserPlus, Crown,
  Star, Download
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// Define the types for our data
interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  isActive: boolean;
  createdAt: string;
}

interface Thread {
  id: number;
  title: string;
  content: string;
  userId: number;
  categoryId: number;
  viewCount: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: string;
  lastActivityAt: string;
}

export default function HomePage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("popular");
  
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    }
  });

  const { data: recentThreads, isLoading: isThreadsLoading } = useQuery<Thread[]>({
    queryKey: ["/api/threads/recent"],
    queryFn: async () => {
      const response = await fetch("/api/threads/recent?limit=5");
      if (!response.ok) throw new Error("Failed to fetch threads");
      return response.json();
    }
  });

  // Stats for the forum (for demo purposes)
  const stats = {
    totalThreads: 1254,
    totalPosts: 8765,
    totalMembers: 543,
    onlineMembers: 32
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="mb-14 pt-8 pb-12 px-4 sm:px-6 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-br from-primary to-primary/70 bg-clip-text text-transparent">Welcome to ModForum</h1>
              <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-400 mb-8">
                The ultimate community for game modding enthusiasts
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                {!user && (
                  <Button size="lg" className="gap-2" asChild>
                    <Link href="/auth?signup=true">
                      <UserPlus className="h-5 w-5" />
                      Join the Community
                    </Link>
                  </Button>
                )}
                <Button variant="outline" size="lg" className="gap-2" asChild>
                  <Link href="/categories">
                    <Gamepad2 className="h-5 w-5" />
                    Browse Game Mods
                  </Link>
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mt-10">
              <Card className="text-center">
                <CardContent className="p-4">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-2xl font-bold">{stats.totalThreads.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Discussions</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-2xl font-bold">{stats.totalPosts.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Posts</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-2xl font-bold">{stats.totalMembers.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Members</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-4">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-2xl font-bold">{stats.onlineMembers}</div>
                  <div className="text-sm text-muted-foreground">Online Now</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="col-span-2">
            <section className="mb-10">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <Gamepad2 className="h-6 w-6 text-primary" />
                  Popular Categories
                </h2>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/categories">View All Categories</Link>
                </Button>
              </div>

              {isCategoriesLoading ? (
                <CategorySkeletonList count={4} />
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {categories?.slice(0, 6).map((category: Category) => (
                    <Link key={category.id} href={`/categories/${category.slug}`}>
                      <Card className="cursor-pointer hover:shadow-md transition-shadow h-full border-l-4 border-l-primary">
                        <CardHeader className="pb-2">
                          <CardTitle>{category.name}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 dark:text-gray-400 line-clamp-2">
                            {category.description}
                          </p>
                        </CardContent>
                        <CardFooter className="flex justify-between text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <MessageSquare className="w-4 h-4" />
                            <span>{Math.floor(Math.random() * 50) + 5} threads</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            <span>{Math.floor(Math.random() * 100) + 10} members</span>
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </section>

            <section className="mb-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h2 className="text-2xl font-bold flex items-center gap-2 mb-2 sm:mb-0">
                  <TrendingUp className="h-6 w-6 text-primary" />
                  Latest Discussions
                </h2>
                
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="popular" className="flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      <span className="hidden sm:inline">Popular</span>
                    </TabsTrigger>
                    <TabsTrigger value="recent" className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span className="hidden sm:inline">Recent</span>
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              {isThreadsLoading ? (
                <ThreadSkeletonList count={5} />
              ) : (
                <div className="grid gap-4">
                  {recentThreads?.map((thread: Thread) => (
                    <Link key={thread.id} href={`/threads/${thread.id}`}>
                      <Card className={`cursor-pointer hover:shadow-md transition-shadow ${thread.isPinned ? 'border-primary' : ''}`}>
                        <CardHeader className="py-3 pb-2">
                          <div className="flex gap-2 mb-1">
                            {thread.isPinned && (
                              <Badge variant="outline" className="text-primary border-primary">Pinned</Badge>
                            )}
                            {thread.isLocked && (
                              <Badge variant="outline" className="text-orange-500 border-orange-500">Locked</Badge>
                            )}
                          </div>
                          <CardTitle className="text-lg">
                            {thread.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-2">
                          <p className="text-gray-600 dark:text-gray-400 line-clamp-1">
                            {thread.content.replace(/<[^>]*>?/gm, '')}
                          </p>
                        </CardContent>
                        <CardFooter className="pt-0 pb-3 text-xs text-gray-500 flex flex-wrap gap-4">
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            <span>{thread.viewCount} views</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>Posted {formatDate(thread.createdAt)}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="w-3 h-3" />
                            <span>Last activity {formatDate(thread.lastActivityAt)}</span>
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                  <div className="flex justify-center mt-2">
                    <Button variant="outline" asChild>
                      <Link href="/threads">View All Discussions</Link>
                    </Button>
                  </div>
                </div>
              )}
            </section>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {!user && (
              <section className="mb-6">
                <Card className="border-primary">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xl flex items-center gap-2">
                      <UserPlus className="h-5 w-5 text-primary" />
                      Join Our Community
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-6 text-gray-600 dark:text-gray-400">
                      Create an account to participate in discussions, share your mods, and connect with other gamers.
                    </p>
                    <div className="space-y-3">
                      <Button className="w-full" asChild>
                        <Link href="/auth">
                          Sign In
                        </Link>
                      </Button>
                      <Button variant="outline" className="w-full" asChild>
                        <Link href="/auth?signup=true">
                          Create Account
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </section>
            )}

            <section className="mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-500" />
                    Premium Benefits
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-start gap-2">
                      <ShieldCheck className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                      <span>Access to exclusive premium mods</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Sparkles className="h-5 w-5 text-blue-500 mt-0.5 shrink-0" />
                      <span>No ads or download restrictions</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Trophy className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
                      <span>Special forum badge and recognition</span>
                    </li>
                  </ul>
                  <Button className="w-full" asChild>
                    <Link href="/membership">View Membership Options</Link>
                  </Button>
                </CardContent>
              </Card>
            </section>

            <section>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Popular Mods
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Sample mods */}
                    <div className="border-b pb-3">
                      <h3 className="font-medium mb-1">Skyrim Enhanced Graphics</h3>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" /> 1.2k views
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="h-3 w-3 text-yellow-500" /> 4.8/5
                        </span>
                      </div>
                    </div>
                    <div className="border-b pb-3">
                      <h3 className="font-medium mb-1">Minecraft Auto Farm</h3>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" /> 842 views
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="h-3 w-3 text-yellow-500" /> 4.6/5
                        </span>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">GTA V Realistic Physics</h3>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" /> 634 views
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="h-3 w-3 text-yellow-500" /> 4.9/5
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 pt-2">
                    <Button variant="outline" className="w-full" asChild>
                      <Link href="/mods">Browse All Mods</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </section>
          </div>
        </div>
      </div>
    </Layout>
  );
}