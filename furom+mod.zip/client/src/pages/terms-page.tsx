import React from "react";
import { Helmet } from "react-helmet";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";

export default function TermsPage() {
  return (
    <Layout>
      <Helmet>
        <title>Terms of Service | ModForum</title>
      </Helmet>
      
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
        
        <div className="prose prose-slate dark:prose-invert max-w-none">
          <p className="lead">
            Welcome to ModForum. These Terms of Service govern your use of our website, services, and community platform. By accessing or using ModForum, you agree to be bound by these terms.
          </p>
          
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using our service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the service.
          </p>
          
          <h2>2. Description of Service</h2>
          <p>
            ModForum provides a platform for users to discuss, share, and download game modifications. We reserve the right to modify, suspend or discontinue any part of the service without notice.
          </p>
          
          <h2>3. User Accounts</h2>
          <p>
            When you create an account with us, you must provide accurate and complete information. You are responsible for safeguarding the password and for all activities that occur under your account.
          </p>
          
          <h2>4. User Content</h2>
          <p>
            Our service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material. You are responsible for the content you post and its legality.
          </p>
          
          <h2>5. Intellectual Property</h2>
          <p>
            The service and its original content (excluding user-submitted content) features and functionality are and will remain the exclusive property of ModForum and its licensors.
          </p>
          
          <h2>6. Mods and Downloads</h2>
          <p>
            Game modifications shared on our platform are subject to their own licenses as specified by their creators. We do not claim ownership of user-submitted mods.
          </p>
          
          <h2>7. Membership</h2>
          <p>
            ModForum offers different membership tiers that provide varying levels of access to mod downloads and features. Payments for membership are processed through our payment partners and are subject to their respective terms of service.
          </p>
          
          <h2>8. Prohibited Uses</h2>
          <p>
            You may not use our service for any illegal purposes or to conduct any unlawful activity, including, but not limited to:
          </p>
          <ul>
            <li>Sharing pirated games or copyright-infringing content</li>
            <li>Distributing malware, viruses, or other harmful software</li>
            <li>Harassing, abusing, or threatening other users</li>
            <li>Impersonating others or providing false information</li>
          </ul>
          
          <h2>9. Limitation of Liability</h2>
          <p>
            In no event shall ModForum, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.
          </p>
          
          <h2>10. Termination</h2>
          <p>
            We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
          </p>
          
          <h2>11. Changes</h2>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. By continuing to access or use our service after those revisions become effective, you agree to be bound by the revised terms.
          </p>
          
          <h2>12. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us:
          </p>
          
          <div className="flex mt-8">
            <Button asChild variant="outline">
              <a href="/contact">Contact Support</a>
            </Button>
          </div>
        </div>
        
        <div className="text-sm text-muted-foreground mt-10 text-center">
          Last updated: April 25, 2025
        </div>
      </div>
    </Layout>
  );
}