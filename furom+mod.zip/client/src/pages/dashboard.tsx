import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { PerformanceChart } from "@/components/ui/line-chart";
import { RecentCampaigns } from "@/components/dashboard/recent-campaigns";
import { ServiceCard } from "@/components/dashboard/service-card";
import { CampaignTable } from "@/components/dashboard/campaign-table";
import { CreateCampaignModal } from "@/components/modals/create-campaign-modal";
import { generateRandomTrend } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();

  // Fetch user metrics
  const { data: metrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ['/api/metrics'],
  });

  // Fetch campaigns
  const { data: campaigns, isLoading: isLoadingCampaigns } = useQuery({
    queryKey: ['/api/campaigns'],
  });

  // Fetch services
  const { data: services, isLoading: isLoadingServices } = useQuery({
    queryKey: ['/api/services'],
  });

  // Update campaign status
  const updateCampaignStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      return apiRequest("PATCH", `/api/campaigns/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
  });

  // Generate sample chart data
  const chartData = React.useMemo(() => {
    if (!metrics) return [];
    
    // In a real app, this would come from the API
    return [
      { name: "Jan", subscribers: 570, likes: 4200, watchHours: 620 },
      { name: "Feb", subscribers: 750, likes: 6500, watchHours: 890 },
      { name: "Mar", subscribers: 960, likes: 8900, watchHours: 1240 },
      { name: "Apr", subscribers: 1320, likes: 10400, watchHours: 1600 },
      { name: "May", subscribers: 1670, likes: 12500, watchHours: 1950 },
      { name: "Jun", subscribers: 1980, likes: 15800, watchHours: 2340 },
      { name: "Jul", subscribers: 2100, likes: 16900, watchHours: 2600 },
      { name: "Aug", subscribers: 2320, likes: 17800, watchHours: 2870 },
      { name: "Sep", subscribers: metrics.subscribers, likes: metrics.likes, watchHours: metrics.watchHours },
    ];
  }, [metrics]);

  const handleCreateCampaign = () => {
    setIsCreateModalOpen(true);
  };

  const handleServiceSelect = (serviceType: string) => {
    toast({
      title: "Package Selected",
      description: `You've selected the ${serviceType} package. You can now create a campaign.`,
      duration: 3000,
    });
    setTimeout(() => {
      setIsCreateModalOpen(true);
    }, 500);
  };

  if (isLoadingMetrics || isLoadingCampaigns || isLoadingServices) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const sortedCampaigns = [...(campaigns || [])].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  const recentCampaigns = sortedCampaigns.slice(0, 3);

  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden">
      {/* Sidebar for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-64 bg-[#282828] z-10">
            <Sidebar isMobile onClose={() => setSidebarOpen(false)} />
          </div>
        </div>
      )}

      {/* Sidebar for desktop */}
      <div className="hidden md:block h-full">
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Dashboard" 
          onMenuClick={() => setSidebarOpen(true)} 
        />

        {/* Dashboard Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#F9F9F9]">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MetricsCard
              title="Total Watch Hours"
              value={metrics?.watchHours || 0}
              icon="clock"
              trend={generateRandomTrend()}
            />
            <MetricsCard
              title="Total Subscribers"
              value={metrics?.subscribers || 0}
              icon="users"
              trend={generateRandomTrend()}
            />
            <MetricsCard
              title="Total Likes"
              value={metrics?.likes || 0}
              icon="thumbs-up"
              trend={generateRandomTrend()}
            />
            <MetricsCard
              title="Active Campaigns"
              value={metrics?.activeCampaigns || 0}
              icon="bullhorn"
              trend={-3.1}
            />
          </div>

          {/* Main Content Sections */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Campaign Performance */}
            <PerformanceChart data={chartData} className="lg:col-span-2" />

            {/* Recent Campaigns */}
            <RecentCampaigns
              campaigns={recentCampaigns}
              onCreateCampaign={handleCreateCampaign}
              onViewAllCampaigns={() => setLocation("/campaigns")}
            />
          </div>

          {/* Available Services Section */}
          <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold text-lg">Available Services</h2>
              <button 
                className="text-primary text-sm hover:underline"
                onClick={() => setLocation("/services")}
              >
                View All Services
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {services?.map((service) => (
                <ServiceCard
                  key={service.id}
                  name={service.name}
                  type={service.type}
                  features={service.features}
                  basePrice={service.basePrice}
                  onSelect={() => handleServiceSelect(service.type)}
                />
              ))}
            </div>
          </div>

          {/* Campaign Management Section */}
          <div className="mt-6">
            <CampaignTable
              campaigns={sortedCampaigns}
              onStatusChange={(id, status) => updateCampaignStatus.mutate({ id, status })}
            />
          </div>
        </main>
      </div>

      {/* Create Campaign Modal */}
      <CreateCampaignModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </div>
  );
}
