import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatBytes } from "@/lib/utils";
import { membershipRankSufficient } from "@shared/utils";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Calendar, 
  Download, 
  User, 
  Tag, 
  Shield, 
  Info, 
  FileText, 
  Settings, 
  Clock 
} from "lucide-react";

import type { MembershipPlan } from "@shared/schema";

// Interface matching our enhanced mod schema
interface Mod {
  id: number;
  name: string;
  game: string;
  description: string;
  version: string;
  userId: number;
  downloadUrl: string | null;
  imageUrl: string | null;
  downloadCount: number;
  fileSize: number | null;
  requirements: string | null;
  installationInstructions: string | null;
  tags: string[] | null;
  isPremium: boolean;
  requiredMembershipPlan: MembershipPlan | null;
  createdAt: string;
  updatedAt: string;
  user?: {
    id: number;
    username: string;
  };
}

export default function ModDetailPage() {
  const { id } = useParams<{ id: string }>();
  const modId = parseInt(id);
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  
  // Fetch the mod details
  const { data: mod, isLoading } = useQuery<Mod>({
    queryKey: ["/api/mods", modId],
    queryFn: async () => {
      const response = await fetch(`/api/mods/${modId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch mod details");
      }
      return response.json();
    }
  });
  
  // Handle the download - this will increment the download count
  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/mods/${modId}/download`);
      if (!response.ok) {
        throw new Error("Failed to record download");
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate the mod cache to update download count
      queryClient.invalidateQueries({ queryKey: ["/api/mods", modId] });
      
      // Redirect to the download URL if it exists
      if (mod?.downloadUrl) {
        window.open(mod.downloadUrl, "_blank");
      }
    },
    onError: (error) => {
      toast({
        title: "Download Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDownload = () => {
    if (!user) {
      // Redirect to auth page if not logged in
      navigate("/auth");
      return;
    }
    
    if (mod?.isPremium && mod.requiredMembershipPlan) {
      // Check if user has required membership plan
      const userPlan = user.plan;
      const requiredPlan = mod.requiredMembershipPlan;
      
      if (!membershipRankSufficient(userPlan, requiredPlan)) {
        // User doesn't have the required plan
        setShowUpgradeDialog(true);
        return;
      }
    }
    
    // User is authorized to download
    downloadMutation.mutate();
  };
  
  if (isLoading) {
    return <PageLoadingSkeleton />;
  }
  
  if (!mod) {
    return (
      <Layout>
        <div className="container mx-auto py-8 text-center">
          <h1 className="text-3xl font-bold mb-4">Mod Not Found</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            The mod you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <a href="/mods">Back to Mods</a>
          </Button>
        </div>
      </Layout>
    );
  }
  
  // Add upgrade dialog for premium mods
  const upgradeDialog = (
    <AlertDialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Membership Required</AlertDialogTitle>
          <AlertDialogDescription>
            This mod requires a {mod?.requiredMembershipPlan} membership or higher.
            Would you like to upgrade your membership to access this mod?
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction asChild>
            <a href="/membership">Upgrade Membership</a>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );

  return (
    <Layout>
      {upgradeDialog}
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Mod Image */}
            <div className="w-full md:w-2/5">
              {mod.imageUrl ? (
                <img 
                  src={mod.imageUrl} 
                  alt={mod.name}
                  className="rounded-lg w-full h-72 object-cover"
                />
              ) : (
                <div className="rounded-lg w-full h-72 bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
                  <span className="text-gray-500">{mod.game}</span>
                </div>
              )}
              
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-medium mb-3 flex items-center">
                      <Info className="w-4 h-4 mr-2" /> Mod Details
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-center text-sm">
                        <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                        Updated {formatDate(mod.updatedAt)}
                      </li>
                      <li className="flex items-center text-sm">
                        <Clock className="w-4 h-4 mr-2 text-gray-500" />
                        Created {formatDate(mod.createdAt)}
                      </li>
                      <li className="flex items-center text-sm">
                        <Download className="w-4 h-4 mr-2 text-gray-500" />
                        {mod.downloadCount} downloads
                      </li>
                      <li className="flex items-center text-sm">
                        <User className="w-4 h-4 mr-2 text-gray-500" />
                        By {mod.user?.username || "Unknown"}
                      </li>
                      {mod.fileSize && (
                        <li className="flex items-center text-sm">
                          <FileText className="w-4 h-4 mr-2 text-gray-500" />
                          Size: {formatBytes(mod.fileSize)}
                        </li>
                      )}
                      {mod.isPremium && (
                        <li className="flex items-center text-sm">
                          <Shield className="w-4 h-4 mr-2 text-amber-500" />
                          <span className="text-amber-500 font-medium">
                            Premium Mod ({mod.requiredMembershipPlan} plan required)
                          </span>
                        </li>
                      )}
                    </ul>
                  </CardContent>
                </Card>
                
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">{mod.game}</Badge>
                  <Badge variant="outline">{mod.version}</Badge>
                  {mod.tags && mod.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      <Tag className="w-3 h-3 mr-1" /> {tag}
                    </Badge>
                  ))}
                </div>
                
                <Button 
                  className="w-full"
                  size="lg"
                  onClick={handleDownload}
                  disabled={downloadMutation.isPending || !mod.downloadUrl}
                  variant={
                    !user ? "default" :
                    mod.isPremium && mod.requiredMembershipPlan && 
                    !membershipRankSufficient(user.plan, mod.requiredMembershipPlan) ? 
                    "outline" : "default"
                  }
                >
                  {downloadMutation.isPending ? (
                    <span className="flex items-center">
                      <div className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
                      Processing...
                    </span>
                  ) : !user ? (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      Log in to Download
                    </>
                  ) : mod.isPremium && mod.requiredMembershipPlan && 
                      !membershipRankSufficient(user.plan, mod.requiredMembershipPlan) ? (
                    <>
                      <Shield className="mr-2 h-4 w-4" />
                      Upgrade to Download
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      Download Mod
                    </>
                  )}
                </Button>
              </div>
            </div>
            
            {/* Mod Content */}
            <div className="w-full md:w-3/5">
              <div className="flex flex-col mb-4">
                <div className="flex justify-between items-start">
                  <h1 className="text-3xl font-bold">{mod.name}</h1>
                </div>
                
                {/* Membership indicator */}
                {mod.isPremium && mod.requiredMembershipPlan && (
                  <div className="mt-2">
                    <Badge 
                      variant="secondary" 
                      className={
                        user && user.plan && 
                        membershipRankSufficient(user.plan, mod.requiredMembershipPlan) 
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" 
                          : "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100"
                      }>
                      {mod.requiredMembershipPlan.charAt(0).toUpperCase() + mod.requiredMembershipPlan.slice(1)} Plan Required
                    </Badge>
                    
                    {user && user.plan && !membershipRankSufficient(user.plan, mod.requiredMembershipPlan) && (
                      <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">
                        Your current plan ({user.plan.charAt(0).toUpperCase() + user.plan.slice(1)}) 
                        does not meet the requirements to download this mod.
                      </p>
                    )}
                  </div>
                )}
              </div>
              
              <div className="mt-4">
                <Tabs defaultValue="description">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="description">Description</TabsTrigger>
                    <TabsTrigger value="installation">Installation</TabsTrigger>
                    <TabsTrigger value="requirements">Requirements</TabsTrigger>
                  </TabsList>
                  <TabsContent value="description" className="mt-4">
                    <div className="prose dark:prose-invert max-w-none">
                      {mod.description.split('\n').map((paragraph, index) => (
                        <p key={index}>{paragraph}</p>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="installation" className="mt-4">
                    {mod.installationInstructions ? (
                      <div className="prose dark:prose-invert max-w-none">
                        {mod.installationInstructions.split('\n').map((line, index) => (
                          <p key={index}>{line}</p>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 text-gray-500">
                        <Settings className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>No installation instructions provided</p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="requirements" className="mt-4">
                    {mod.requirements ? (
                      <div className="prose dark:prose-invert max-w-none">
                        {mod.requirements.split('\n').map((line, index) => (
                          <p key={index}>{line}</p>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 text-gray-500">
                        <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>No system requirements specified</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Membership upgrade dialog */}
      <AlertDialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Membership Required</AlertDialogTitle>
            <AlertDialogDescription>
              This mod requires a {mod.requiredMembershipPlan} membership plan or higher.
              Upgrade your membership to download this premium mod.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction asChild>
              <Button onClick={() => navigate("/membership")}>
                Upgrade Membership
              </Button>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}