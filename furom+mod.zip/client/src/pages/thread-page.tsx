import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";
import { PostSkeletonList } from "@/components/ui/skeletons/post-skeleton";
import { 
  MessageSquare, 
  Users, 
  Eye, 
  Calendar, 
  ThumbsUp, 
  ArrowLeft, 
  Send,
  MoreVertical,
} from "lucide-react";
import { ThreadActions } from "@/components/thread-actions";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";


// Define the types for our data
interface Thread {
  id: number;
  title: string;
  content: string;
  userId: number;
  categoryId: number;
  viewCount: number;
  isPinned: boolean;
  isLocked: boolean;
  createdAt: string;
  lastActivityAt: string;
}

interface Post {
  id: number;
  content: string;
  userId: number;
  threadId: number;
  isEdited: boolean;
  editedAt: string | null;
  createdAt: string;
}

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface User {
  id: number;
  username: string;
  role: string;
  avatar: string | null;
  postCount: number;
  createdAt: string;
}

interface Like {
  id: number;
  postId: number;
  userId: number;
  createdAt: string;
}

export default function ThreadPage() {
  const { id } = useParams();
  const threadId = parseInt(id as string);
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [newPostContent, setNewPostContent] = useState("");

  const { data: thread, isLoading: isThreadLoading } = useQuery<Thread>({
    queryKey: [`/api/threads/${threadId}`],
    queryFn: async () => {
      const response = await fetch(`/api/threads/${threadId}`);
      if (!response.ok) throw new Error("Failed to fetch thread");
      return response.json();
    }
  });

  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/${thread?.categoryId}`],
    queryFn: async () => {
      if (!thread) return null;
      const response = await fetch(`/api/categories/${thread.categoryId}`);
      if (!response.ok) throw new Error("Failed to fetch category");
      return response.json();
    },
    enabled: !!thread
  });

  const { data: posts, isLoading: isPostsLoading } = useQuery<Post[]>({
    queryKey: [`/api/threads/${threadId}/posts`],
    queryFn: async () => {
      const response = await fetch(`/api/threads/${threadId}/posts`);
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    }
  });

  const { data: users } = useQuery<Record<number, User>>({
    queryKey: ['/api/users', posts?.map(post => post.userId)],
    queryFn: async () => {
      if (!posts || posts.length === 0) return {};
      
      // Get unique user IDs from posts using a Map instead of Set
      const userIdMap = new Map<number, boolean>();
      posts.forEach(post => userIdMap.set(post.userId, true));
      const userIds = Array.from(userIdMap.keys());
      
      // Fetch user data for each user ID
      const userPromises = userIds.map(userId => 
        fetch(`/api/users/${userId}`).then(res => res.json())
      );
      
      const usersList = await Promise.all(userPromises);
      
      // Create a map of userId to user data
      return usersList.reduce((acc, user) => {
        acc[user.id] = user;
        return acc;
      }, {} as Record<number, User>);
    },
    enabled: !!posts && posts.length > 0
  });

  const postMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", `/api/threads/${threadId}/posts`, { content });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create post");
      }
      return await res.json();
    },
    onSuccess: () => {
      setNewPostContent("");
      toast({
        title: "Post created",
        description: "Your reply has been added to the thread",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/threads/${threadId}/posts`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    }
  });



  const handleSubmitPost = () => {
    if (!newPostContent.trim()) {
      toast({
        title: "Cannot post empty content",
        description: "Please write something before posting",
        variant: "destructive",
      });
      return;
    }

    postMutation.mutate(newPostContent);
  };

  if (isThreadLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <PageLoadingSkeleton />
        </div>
      </Layout>
    );
  }

  if (!thread) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">Thread Not Found</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              The thread you're looking for doesn't exist or may have been moved.
            </p>
            <Button asChild>
              <Link href="/">Go Home</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Button variant="ghost" size="sm" className="gap-1" asChild>
              <Link href={category ? `/categories/${category.slug}` : "/"}>
                <ArrowLeft className="h-4 w-4" />
                <span>{category ? category.name : "Back"}</span>
              </Link>
            </Button>
          </div>
          
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-1">
                {thread.isPinned && (
                  <Badge variant="outline" className="text-primary border-primary">Pinned</Badge>
                )}
                {thread.isLocked && (
                  <Badge variant="outline" className="text-orange-500 border-orange-500">Locked</Badge>
                )}
              </div>
              <h1 className="text-3xl font-bold">{thread.title}</h1>
              <div className="flex items-center text-sm text-gray-500 mt-2 gap-4">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{thread.viewCount} views</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>Posted {formatDate(thread.createdAt)}</span>
                </div>
              </div>
            </div>
            
            {/* Thread Actions Menu */}
            {thread && (
              <ThreadActions 
                threadId={thread.id} 
                threadOwnerId={thread.userId} 
                isPinned={thread.isPinned} 
                isLocked={thread.isLocked} 
              />
            )}
          </div>
        </div>

        <div className="space-y-6 mb-8">
          {isPostsLoading ? (
            <PostSkeletonList count={3} />
          ) : posts && posts.map((post, index) => {
            const postUser = users?.[post.userId];
            return (
              <Card key={post.id} id={`post-${post.id}`} className={index === 0 ? "border-primary" : ""}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar>
                        <AvatarImage src={postUser?.avatar || ""} alt={postUser?.username || "User"} />
                        <AvatarFallback>
                          {(postUser?.username || "U").substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{postUser?.username || "Unknown User"}</div>
                        <div className="text-xs text-gray-500 flex items-center gap-1">
                          {postUser?.role === "admin" && (
                            <Badge variant="outline" className="text-xs py-0 px-1">Admin</Badge>
                          )}
                          <span>{postUser?.postCount || 0} posts</span>
                          <span>•</span>
                          <span>Joined {postUser ? formatDate(postUser.createdAt) : ""}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {post.isEdited ? (
                        <span>Edited {formatDate(post.editedAt || post.createdAt)}</span>
                      ) : (
                        <span>{formatDate(post.createdAt)}</span>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: post.content }} />
                </CardContent>
              </Card>
            );
          })}
        </div>

        {!thread.isLocked ? (
          <div className="mt-8">
            {user ? (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Post Reply</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea 
                    placeholder="Write your response here..."
                    className="min-h-[120px]"
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    disabled={postMutation.isPending}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="text-sm text-gray-500">
                    Markdown formatting is supported
                  </div>
                  <Button onClick={handleSubmitPost} disabled={postMutation.isPending}>
                    {postMutation.isPending ? (
                      <>Posting...</>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Post Reply
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="mb-4">
                    You need to be logged in to reply to this thread.
                  </p>
                  <Button asChild>
                    <Link href="/auth">Sign In / Register</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <Card className="mt-8 border-orange-500">
            <CardContent className="pt-6 text-center">
              <p className="text-orange-500 font-medium">
                This thread is locked. No new replies can be posted.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}