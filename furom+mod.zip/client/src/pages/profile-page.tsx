import React from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AchievementsList } from "@/components/achievements";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PageLoadingSkeleton } from "@/components/ui/skeletons/page-loading";

// Import MembershipPlan type from schema
import type { MembershipPlan } from "@shared/schema";

// Define the User type
type User = {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: string;
  avatar: string | null;
  postsCount: number;
  createdAt: string;
  plan: MembershipPlan;
  planExpiresAt: string | null;
  paypalCustomerId?: string | null;
  paypalSubscriptionId?: string | null;
  binanceUserId?: string | null;
};

export default function ProfilePage() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams();
  const userId = params.userId ? parseInt(params.userId) : user?.id;
  
  // Redirect to auth page if not logged in
  React.useEffect(() => {
    if (!isAuthLoading && !user) {
      setLocation("/auth");
    }
  }, [user, isAuthLoading, setLocation]);
  
  // Fetch user data if viewing another user's profile
  const { data: profileUser, isLoading: isProfileLoading } = useQuery<User>({
    queryKey: ["/api/users", userId],
    // Only fetch if viewing another user's profile
    enabled: !!userId && userId !== user?.id,
  });
  
  // Use the authenticated user data if viewing own profile
  const profileData = userId === user?.id ? user as User : profileUser;
  const isLoading = isAuthLoading || (isProfileLoading && userId !== user?.id);
  
  if (isLoading) {
    return <PageLoadingSkeleton />;
  }
  
  if (!profileData) {
    return (
      <Layout>
        <div className="container max-w-6xl py-8">
          <Card>
            <CardHeader>
              <CardTitle>User Not Found</CardTitle>
              <CardDescription>The user you're looking for doesn't exist or has been removed.</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </Layout>
    );
  }
  
  // At this point profileData is definitely a User object
  const userProfile: User = profileData;
  const isOwnProfile = user?.id === userProfile.id;
  
  return (
    <Layout>
      <div className="container max-w-6xl py-8">
        <div className="grid grid-cols-1 gap-8">
          {/* User Profile Card */}
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage 
                  src={userProfile.avatar || undefined} 
                  alt={userProfile.username} 
                />
                <AvatarFallback className="text-xl">
                  {userProfile.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-2xl">{userProfile.fullName}</CardTitle>
                <CardDescription>@{userProfile.username}</CardDescription>
                <p className="mt-1 text-sm text-muted-foreground">
                  {userProfile.role === "admin" ? "Administrator" : "Member"} · 
                  Joined {new Date(userProfile.createdAt).toLocaleDateString()}
                </p>
              </div>
            </CardHeader>
          </Card>
          
          {/* Profile Content Tabs */}
          <Tabs defaultValue="achievements" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
              <TabsTrigger value="posts">Posts</TabsTrigger>
              <TabsTrigger value="mods">Mods</TabsTrigger>
            </TabsList>
            
            <TabsContent value="achievements">
              <AchievementsList />
            </TabsContent>
            
            <TabsContent value="posts">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Posts</CardTitle>
                  <CardDescription>View recent forum activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-muted-foreground">
                    {isOwnProfile 
                      ? "You haven't made any posts yet." 
                      : `${userProfile.username} hasn't made any posts yet.`}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="mods">
              <Card>
                <CardHeader>
                  <CardTitle>Published Mods</CardTitle>
                  <CardDescription>Game modifications created by this user</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-muted-foreground">
                    {isOwnProfile 
                      ? "You haven't published any mods yet." 
                      : `${userProfile.username} hasn't published any mods yet.`}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}