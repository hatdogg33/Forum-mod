import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { MembershipPlan } from "@shared/schema";

interface PlanFeature {
  title: string;
  included: boolean;
}

interface PlanDetails {
  name: string;
  description: string;
  price: number;
  features: PlanFeature[];
  highlighted?: boolean;
  planId: MembershipPlan;
}

export default function MembershipPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<MembershipPlan | null>(null);
  
  // Redirect to login if not authenticated
  if (!user) {
    navigate("/auth");
    return <div>Redirecting to login...</div>;
  }
  
  const currentPlan = user.plan || "free";
  
  const membershipPlans: PlanDetails[] = [
    {
      name: "Free",
      description: "Basic features for mod browsing",
      price: 0,
      planId: "free",
      features: [
        { title: "Browse all mods", included: true },
        { title: "Download non-premium mods", included: true },
        { title: "Create an account", included: true },
        { title: "Post in forum discussions", included: true },
        { title: "Access to premium mods", included: false },
        { title: "Upload your own mods", included: false },
        { title: "Early access to new features", included: false },
        { title: "Premium badge on profile", included: false },
      ]
    },
    {
      name: "Basic",
      description: "Essential features for mod enthusiasts",
      price: 4.99,
      planId: "basic",
      features: [
        { title: "Browse all mods", included: true },
        { title: "Download non-premium mods", included: true },
        { title: "Create an account", included: true },
        { title: "Post in forum discussions", included: true },
        { title: "Access to premium mods", included: false },
        { title: "Upload your own mods", included: true },
        { title: "Early access to new features", included: false },
        { title: "Premium badge on profile", included: false },
      ]
    },
    {
      name: "Premium",
      description: "Full access to all standard features",
      price: 9.99,
      planId: "premium",
      highlighted: true,
      features: [
        { title: "Browse all mods", included: true },
        { title: "Download non-premium mods", included: true },
        { title: "Create an account", included: true },
        { title: "Post in forum discussions", included: true },
        { title: "Access to premium mods", included: true },
        { title: "Upload your own mods", included: true },
        { title: "Early access to new features", included: false },
        { title: "Premium badge on profile", included: true },
      ]
    },
    {
      name: "Pro",
      description: "For serious modders and enthusiasts",
      price: 19.99,
      planId: "pro",
      features: [
        { title: "Browse all mods", included: true },
        { title: "Download non-premium mods", included: true },
        { title: "Create an account", included: true },
        { title: "Post in forum discussions", included: true },
        { title: "Access to premium mods", included: true },
        { title: "Upload your own mods", included: true },
        { title: "Early access to new features", included: true },
        { title: "Premium badge on profile", included: true },
      ]
    }
  ];
  
  const handleSelectPlan = (plan: MembershipPlan) => {
    if (plan === currentPlan) {
      toast({
        title: "Already Subscribed",
        description: `You are already subscribed to the ${plan} plan.`,
        variant: "default",
      });
      return;
    }
    
    // Free plan doesn't need payment processing
    if (plan === "free") {
      toast({
        title: "Downgrade to Free",
        description: "Your plan will be downgraded at the end of your current billing cycle.",
        variant: "default",
      });
      return;
    }
    
    setSelectedPlan(plan);
    navigate(`/checkout?plan=${plan}`);
  };
  
  return (
    <Layout>
      <div className="container py-12 mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-3">Membership Plans</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the membership plan that works for you. Upgrade anytime to access more features and premium mods.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {membershipPlans.map((plan) => (
            <Card 
              key={plan.planId}
              className={cn(
                "flex flex-col",
                plan.highlighted && "border-primary shadow-lg scale-105"
              )}
            >
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{plan.name}</CardTitle>
                  {currentPlan === plan.planId && (
                    <Badge variant="outline" className="bg-primary/10">
                      Current Plan
                    </Badge>
                  )}
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="mb-6">
                  <p className="text-3xl font-bold">
                    ${plan.price.toFixed(2)}
                    <span className="text-sm font-normal text-muted-foreground ml-1">
                      /month
                    </span>
                  </p>
                  {currentPlan === plan.planId && user.planExpiresAt && (
                    <div className="mt-2">
                      <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                        Active until {new Date(user.planExpiresAt).toLocaleDateString()}
                      </Badge>
                    </div>
                  )}
                </div>
                
                <ul className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      {feature.included ? (
                        <CheckCircle className="h-5 w-5 text-primary shrink-0 mr-2" />
                      ) : (
                        <AlertCircle className="h-5 w-5 text-muted-foreground shrink-0 mr-2" />
                      )}
                      <span className={cn(
                        "text-sm",
                        !feature.included && "text-muted-foreground"
                      )}>
                        {feature.title}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  variant={plan.highlighted ? "default" : "outline"}
                  className="w-full"
                  onClick={() => handleSelectPlan(plan.planId)}
                  disabled={currentPlan === plan.planId}
                >
                  {currentPlan === plan.planId ? "Current Plan" : "Select Plan"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-sm text-muted-foreground max-w-xl mx-auto">
            All plans are billed monthly and can be canceled anytime. 
            Premium features remain active until the end of the billing period.
          </p>
        </div>
      </div>
    </Layout>
  );
}