import React from "react";
import { Helmet } from "react-helmet";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";

export default function PrivacyPage() {
  return (
    <Layout>
      <Helmet>
        <title>Privacy Policy | ModForum</title>
      </Helmet>
      
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
        
        <div className="prose prose-slate dark:prose-invert max-w-none">
          <p className="lead">
            At ModForum, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
          </p>
          
          <h2>1. Information We Collect</h2>
          <p>
            We may collect information about you in various ways, including:
          </p>
          <ul>
            <li>
              <strong>Personal Data:</strong> Name, email address, username, password, profile information.
            </li>
            <li>
              <strong>Usage Data:</strong> IP address, browser type, pages visited, time spent on the site, and other diagnostic data.
            </li>
            <li>
              <strong>Payment Information:</strong> For users with paid memberships, we collect payment method information through our secure payment processors.
            </li>
          </ul>
          
          <h2>2. How We Use Your Information</h2>
          <p>
            We use the collected data for various purposes, including:
          </p>
          <ul>
            <li>To provide and maintain our service</li>
            <li>To notify you about changes to our service</li>
            <li>To provide customer support</li>
            <li>To process transactions and manage your account</li>
            <li>To monitor usage of our service</li>
            <li>To detect, prevent, and address technical issues</li>
          </ul>
          
          <h2>3. Data Security</h2>
          <p>
            The security of your data is important to us, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.
          </p>
          
          <h2>4. Cookies and Tracking</h2>
          <p>
            We use cookies and similar tracking technologies to track activity on our website and hold certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier.
          </p>
          <p>
            You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our service.
          </p>
          
          <h2>5. Third-Party Services</h2>
          <p>
            We may employ third-party companies and individuals to facilitate our service, provide the service on our behalf, perform service-related tasks, or assist us in analyzing how our service is used.
          </p>
          <p>
            These third parties may have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
          </p>
          
          <h2>6. Analytics</h2>
          <p>
            We may use third-party service providers to monitor and analyze the use of our service.
          </p>
          
          <h2>7. Payments</h2>
          <p>
            We provide paid products and services on our website. In that case, we use third-party services for payment processing (e.g. payment processors). We will not store or collect your payment card details. That information is provided directly to our third-party payment processors whose use of your personal information is governed by their Privacy Policy.
          </p>
          
          <h2>8. User Rights</h2>
          <p>
            You have certain rights regarding your personal information:
          </p>
          <ul>
            <li>The right to access, update or delete the information we have on you</li>
            <li>The right to have your information rectified if it is inaccurate or incomplete</li>
            <li>The right to object to our processing of your personal data</li>
            <li>The right to request that we restrict the processing of your personal information</li>
            <li>The right to data portability</li>
          </ul>
          
          <h2>9. Children's Privacy</h2>
          <p>
            Our service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and you are aware that your child has provided us with personal data, please contact us.
          </p>
          
          <h2>10. Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
          </p>
          <p>
            You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
          </p>
          
          <h2>11. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us:
          </p>
          
          <div className="flex mt-8">
            <Button asChild variant="outline">
              <a href="/contact">Contact Support</a>
            </Button>
          </div>
        </div>
        
        <div className="text-sm text-muted-foreground mt-10 text-center">
          Last updated: April 25, 2025
        </div>
      </div>
    </Layout>
  );
}