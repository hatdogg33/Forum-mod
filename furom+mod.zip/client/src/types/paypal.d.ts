declare module '@paypal/checkout-server-sdk';

// Additional declarations for client-side PayPal integration
declare module '@paypal/react-paypal-js' {
  export interface ReactPayPalScriptOptions {
    clientId: string;
    currency?: string;
    intent?: string;
    [key: string]: any;
  }
  
  export function PayPalScriptProvider(props: {
    options: ReactPayPalScriptOptions;
    children: React.ReactNode;
  }): JSX.Element;
  
  export function PayPalButtons(props: {
    createOrder?: (data: any, actions: any) => Promise<string>;
    onApprove?: (data: any, actions: any) => Promise<void>;
    onError?: (err: any) => void;
    style?: {
      layout?: 'vertical' | 'horizontal';
      color?: 'gold' | 'blue' | 'silver' | 'white' | 'black';
      shape?: 'rect' | 'pill';
      height?: number;
      label?: 'paypal' | 'checkout' | 'buynow' | 'pay' | 'installment' | 'subscribe';
      tagline?: boolean;
    };
    [key: string]: any;
  }): JSX.Element;
}