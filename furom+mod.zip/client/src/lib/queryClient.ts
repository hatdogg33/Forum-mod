import { QueryClient } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    let errorMsg = "Request failed";
    try {
      const data = await res.json();
      errorMsg = data.message || errorMsg;
    } catch (e) {
      // Ignore JSON parsing error
    }
    throw new Error(errorMsg);
  }
}

export async function apiRequest(
  method: string,
  path: string,
  body?: any,
  headers: HeadersInit = {}
): Promise<Response> {
  const options: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    credentials: "include", // Include cookies for authentication
  };

  if (body && method !== "GET") {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(path, options);
  return response;
}

type UnauthorizedBehavior = "returnNull" | "throw";

export const getQueryFn =
  <T>({ on401 }: { on401: UnauthorizedBehavior }) =>
  async ({ queryKey }: { queryKey: (string | number)[] }): Promise<T | null> => {
    const path = queryKey[0];
    if (typeof path !== "string") {
      throw new Error("Query key must be a string");
    }

    const res = await fetch(path, {
      credentials: "include", // Include cookies for authentication
    });

    if (res.status === 401) {
      if (on401 === "throw") {
        throw new Error("Unauthorized");
      }
      return null;
    }

    await throwIfResNotOk(res);
    return res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});