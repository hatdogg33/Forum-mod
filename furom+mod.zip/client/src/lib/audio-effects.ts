/**
 * A utility for playing audio effects during achievement celebrations
 */

// Audio context for browser-compatible sound generation
let audioContext: AudioContext | null = null;

/**
 * Initialize the audio context (must be called after user interaction due to browser policies)
 */
export function initAudio() {
  if (audioContext) return;
  
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioContext = new AudioContextClass();
    }
  } catch (e) {
    console.error("Web Audio API not supported in this browser", e);
  }
}

/**
 * Play a celebratory sound for achievement unlocks
 */
export function playAchievementSound() {
  if (!audioContext) {
    initAudio();
    if (!audioContext) return; // Still not available
  }
  
  // Create oscillators for a pleasing notification sound
  try {
    // Main melodic tone
    const mainOsc = audioContext.createOscillator();
    mainOsc.type = "sine";
    mainOsc.frequency.setValueAtTime(440, audioContext.currentTime); // A4
    mainOsc.frequency.linearRampToValueAtTime(880, audioContext.currentTime + 0.1); // A5
    
    // Secondary tone
    const secondOsc = audioContext.createOscillator();
    secondOsc.type = "triangle";
    secondOsc.frequency.setValueAtTime(554.37, audioContext.currentTime + 0.1); // C#5
    secondOsc.frequency.linearRampToValueAtTime(659.25, audioContext.currentTime + 0.2); // E5
    
    // Final tone
    const thirdOsc = audioContext.createOscillator();
    thirdOsc.type = "sine";
    thirdOsc.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.2); // E5
    thirdOsc.frequency.linearRampToValueAtTime(880, audioContext.currentTime + 0.3); // A5
    
    // Volume control
    const gainNode = audioContext.createGain();
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05);
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.2);
    gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.4);
    
    // Connect the graph
    mainOsc.connect(gainNode);
    secondOsc.connect(gainNode);
    thirdOsc.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Start and stop the oscillators
    mainOsc.start(audioContext.currentTime);
    secondOsc.start(audioContext.currentTime + 0.1);
    thirdOsc.start(audioContext.currentTime + 0.2);
    
    mainOsc.stop(audioContext.currentTime + 0.1);
    secondOsc.stop(audioContext.currentTime + 0.2);
    thirdOsc.stop(audioContext.currentTime + 0.4);
  } catch (e) {
    console.error("Error playing achievement sound", e);
  }
}

/**
 * Check if audio is supported in this browser
 */
export function isAudioSupported(): boolean {
  return window.AudioContext !== undefined || (window as any).webkitAudioContext !== undefined;
}