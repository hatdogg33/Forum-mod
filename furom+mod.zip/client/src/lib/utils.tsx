import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format large numbers with commas
export function formatNumber(num: number): string {
  return new Intl.NumberFormat().format(num);
}

// Calculate percentage
export function calculatePercentage(value: number, total: number): number {
  if (total === 0) return 0;
  return Math.min(Math.round((value / total) * 100), 100);
}

// Format date to readable format
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Get campaign type icon
export function getCampaignTypeIcon(type: string): string {
  switch (type) {
    case 'watch-hours':
      return 'clock';
    case 'subscribers':
      return 'users';
    case 'likes':
      return 'thumbs-up';
    default:
      return 'bullhorn';
  }
}

// Get status badge color
export function getStatusColor(status: string): { bg: string, text: string } {
  switch (status) {
    case 'active':
      return { bg: 'bg-success/10', text: 'text-success' };
    case 'paused':
      return { bg: 'bg-warning/10', text: 'text-warning' };
    case 'completed':
      return { bg: 'bg-neutral/10', text: 'text-neutral' };
    default:
      return { bg: 'bg-info/10', text: 'text-info' };
  }
}

// Calculate percentage change
export function calculatePercentageChange(current: number, previous: number): number {
  if (previous === 0) return current > 0 ? 100 : 0;
  return Math.round(((current - previous) / previous) * 100);
}

// Generate random trend for demo
export function generateRandomTrend(): number {
  return Math.floor(Math.random() * 20) - 5;
}

// Format currency
export function formatCurrency(amount: number): string {
  return `$${amount}`;
}

// Truncate text
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

// Extract YouTube channel name from URL
export function extractChannelName(url: string): string {
  try {
    const urlObj = new URL(url);
    const paths = urlObj.pathname.split('/').filter(Boolean);
    
    if (paths.length >= 2) {
      return paths[1];
    }
    
    return 'Your Channel';
  } catch (error) {
    return 'Your Channel';
  }
}
