import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type TimeRange = "week" | "month" | "year";

interface ChartData {
  name: string;
  subscribers: number;
  likes: number;
  watchHours: number;
}

interface PerformanceChartProps {
  data: ChartData[];
  className?: string;
}

export function PerformanceChart({ data, className }: PerformanceChartProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>("month");
  const [chartData, setChartData] = useState<ChartData[]>([]);

  useEffect(() => {
    // In a real app, this would fetch different data based on the timeRange
    // For this example, we'll just use the same data
    setChartData(data);
  }, [timeRange, data]);

  return (
    <Card className={cn("", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Campaign Performance</CardTitle>
        <div className="flex space-x-2">
          <Button
            variant={timeRange === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("week")}
            className={timeRange === "week" ? "bg-primary text-white" : "text-neutral"}
          >
            Week
          </Button>
          <Button
            variant={timeRange === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("month")}
            className={timeRange === "month" ? "bg-primary text-white" : "text-neutral"}
          >
            Month
          </Button>
          <Button
            variant={timeRange === "year" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeRange("year")}
            className={timeRange === "year" ? "bg-primary text-white" : "text-neutral"}
          >
            Year
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[250px] w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
                <XAxis 
                  dataKey="name" 
                  stroke="#717171" 
                  fontSize={12} 
                  tickLine={false}
                  axisLine={{ stroke: '#e5e5e5' }}
                />
                <YAxis 
                  stroke="#717171" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={{ stroke: '#e5e5e5' }}
                  tickFormatter={(value) => `${value}`}
                />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="subscribers"
                  stroke="hsl(var(--info))"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  activeDot={{ r: 5 }}
                />
                <Line
                  type="monotone"
                  dataKey="likes"
                  stroke="hsl(var(--success))"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  activeDot={{ r: 5 }}
                />
                <Line
                  type="monotone"
                  dataKey="watchHours"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full w-full bg-neutral-lightest rounded-lg overflow-hidden text-neutral flex-col">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mb-2"
              >
                <path d="M3 3v18h18" />
                <path d="m19 9-5 5-4-4-3 3" />
              </svg>
              <p>Performance metrics visualization</p>
              <p className="text-sm">Line chart showing growth trends</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
