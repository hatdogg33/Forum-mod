import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function ThreadSkeleton() {
  return (
    <Card className="animate-in fade-in-5 duration-300">
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-2/3 mb-1" />
      </CardHeader>
      <CardContent className="pb-2">
        <Skeleton className="h-4 w-5/6 mb-2" />
        <Skeleton className="h-4 w-4/6" />
      </CardContent>
      <CardFooter className="flex gap-3 pt-1">
        <Skeleton className="h-4 w-14" />
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-4 w-20" />
      </CardFooter>
    </Card>
  );
}

export function ThreadSkeletonList({ count = 3 }: { count?: number }) {
  return (
    <div className="grid gap-4">
      {Array.from({ length: count }).map((_, index) => (
        <ThreadSkeleton key={index} />
      ))}
    </div>
  );
}