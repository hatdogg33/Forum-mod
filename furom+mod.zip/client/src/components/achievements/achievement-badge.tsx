import React from "react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";

interface AchievementBadgeProps {
  name: string;
  description: string;
  badgeUrl: string;
  isEarned?: boolean;
  progress?: number;
  thresholdValue?: number;
  className?: string;
}

/**
 * AchievementBadge displays a static achievement badge
 * Used for achievement lists and user profiles
 */
export function AchievementBadge({
  name,
  description,
  badgeUrl,
  isEarned = false,
  progress = 0,
  thresholdValue = 1,
  className,
}: AchievementBadgeProps) {
  // Calculate progress percentage
  const progressPercentage = thresholdValue > 0 ? Math.min(100, (progress / thresholdValue) * 100) : 0;
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            className={cn(
              "relative flex items-center justify-center",
              !isEarned && "opacity-50 grayscale",
              className
            )}
          >
            <img
              src={badgeUrl}
              alt={name}
              width={64}
              height={64}
              className="transition-transform duration-300 hover:scale-110"
            />
            
            {!isEarned && thresholdValue > 0 && (
              <div className="absolute -bottom-2 left-0 right-0 px-1">
                <Progress value={progressPercentage} className="h-1.5 bg-muted/50" />
              </div>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-[200px]">
          <div className="text-center">
            <span className="font-bold block">{name}</span>
            <span className="text-xs text-muted-foreground">{description}</span>
            {!isEarned && (
              <span className="text-xs mt-1 block">
                Progress: {progress}/{thresholdValue}
              </span>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}