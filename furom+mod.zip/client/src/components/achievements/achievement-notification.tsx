import React, { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { AnimatedBadge } from "./animated-badge";
import { Confetti } from "./confetti";
import { queryClient } from "@/lib/queryClient";
import { Achievement, UserAchievement } from "@shared/schema";
import { playAchievementSound, initAudio, isAudioSupported } from "@/lib/audio-effects";

type UserAchievementWithDetails = UserAchievement & { achievement: Achievement };

export function AchievementNotifications() {
  const [showConfetti, setShowConfetti] = React.useState(false);
  const [currentAchievement, setCurrentAchievement] = React.useState<UserAchievementWithDetails | null>(null);
  const [queue, setQueue] = React.useState<UserAchievementWithDetails[]>([]);
  const [audioInitialized, setAudioInitialized] = React.useState(false);

  // Ensure audio is initialized only once after user interaction
  useEffect(() => {
    const handleUserInteraction = () => {
      if (!audioInitialized && isAudioSupported()) {
        initAudio();
        setAudioInitialized(true);
        window.removeEventListener('click', handleUserInteraction);
      }
    };

    window.addEventListener('click', handleUserInteraction);
    return () => window.removeEventListener('click', handleUserInteraction);
  }, [audioInitialized]);

  // Fetch user achievements to check for new ones
  const { data: userAchievements = [] } = useQuery<UserAchievementWithDetails[]>({
    queryKey: ["/api/user/achievements"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Process new achievements
  React.useEffect(() => {
    if (userAchievements) {
      const newAchievements = userAchievements
        .filter((ua: UserAchievementWithDetails) => ua.isNew)
        .sort((a: UserAchievementWithDetails, b: UserAchievementWithDetails) => {
          // Sort by time - newest first
          return new Date(b.unlockedAt).getTime() - new Date(a.unlockedAt).getTime();
        });

      if (newAchievements.length > 0 && queue.length === 0 && !currentAchievement) {
        setQueue(newAchievements);
      }
    }
  }, [userAchievements, queue, currentAchievement]);

  // Process queue
  React.useEffect(() => {
    if (queue.length > 0 && !currentAchievement) {
      // Get the first achievement from the queue
      const nextAchievement = queue[0];
      setCurrentAchievement(nextAchievement);
      setQueue(queue.slice(1));
      setShowConfetti(true);
      
      // Play audio notification when showing a new achievement 
      if (audioInitialized) {
        playAchievementSound();
      }
    }
  }, [queue, currentAchievement, audioInitialized]);

  // Mark achievement as seen
  const markAsSeen = async () => {
    if (!currentAchievement) return;

    try {
      await fetch(`/api/user/achievements/${currentAchievement.achievementId}/seen`, {
        method: "PATCH",
        credentials: "include",
      });
      // Invalidate user achievements query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/user/achievements"] });
    } catch (error) {
      console.error("Failed to mark achievement as seen:", error);
    } finally {
      setCurrentAchievement(null);
      setShowConfetti(false);
    }
  };

  if (!currentAchievement) return null;

  return (
    <>
      {showConfetti && <Confetti />}
      
      <AlertDialog open={!!currentAchievement} onOpenChange={() => markAsSeen()}>
        <AlertDialogContent className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-center text-xl text-amber-500 animate-pulse">
              Achievement Unlocked!
            </AlertDialogTitle>
            <AlertDialogDescription className="text-center">
              Congratulations! You've earned a new achievement.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="flex flex-col items-center justify-center py-4">
            <AnimatedBadge
              name={currentAchievement.achievement.name}
              description={currentAchievement.achievement.description}
              badgeUrl={currentAchievement.achievement.badgeUrl}
              thresholdValue={currentAchievement.achievement.thresholdValue}
              className="mb-6"
            />
          </div>
          
          <AlertDialogFooter className="animate-fadeIn">
            <AlertDialogCancel 
              onClick={markAsSeen} 
              className="w-full sm:w-auto bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white hover:text-white border-0"
            >
              Awesome!
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out forwards;
          animation-delay: 2s;
          opacity: 0;
        }
      `}} />
    </>
  );
}