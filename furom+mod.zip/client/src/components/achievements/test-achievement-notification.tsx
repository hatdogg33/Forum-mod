import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { AnimatedBadge } from "./animated-badge";
import { Confetti } from "./confetti";
import { playAchievementSound, initAudio } from "@/lib/audio-effects";

/**
 * Test component for demonstrating achievement animations
 */
export function TestAchievementNotification() {
  const [showAnimation, setShowAnimation] = useState(false);
  
  const triggerAchievement = () => {
    // Initialize audio (must be done after user interaction)
    initAudio();
    
    // Play the achievement sound
    playAchievementSound();
    
    // Show the animation
    setShowAnimation(true);
    
    // Reset after 6 seconds
    setTimeout(() => {
      setShowAnimation(false);
    }, 6000);
  };
  
  return (
    <div className="p-8 flex flex-col items-center gap-8">
      <h1 className="text-2xl font-bold text-center">Achievement Animation Test</h1>
      
      <Button 
        onClick={triggerAchievement} 
        className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
      >
        Unlock Achievement
      </Button>
      
      {showAnimation && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          {/* Confetti in background */}
          <Confetti />
          
          <div className="bg-background/95 backdrop-blur-sm p-8 rounded-lg shadow-xl border border-border max-w-md">
            <h2 className="text-center text-2xl font-bold text-amber-500 animate-pulse mb-4">
              Achievement Unlocked!
            </h2>
            <p className="text-center text-muted-foreground mb-8">
              Congratulations! You've earned a new achievement.
            </p>
            
            <div className="flex flex-col items-center justify-center py-6">
              <AnimatedBadge
                name="Test Achievement"
                description="Successfully tested the achievement animation system"
                badgeUrl="/badges/default.svg"
                thresholdValue={1}
                className="mb-6"
              />
            </div>
            
            <div className="animate-fadeIn mt-6 text-center">
              <Button 
                onClick={() => setShowAnimation(false)}
                className="bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white"
              >
                Awesome!
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}