import React from "react";
import { useQuery } from "@tanstack/react-query";
import { AchievementBadge } from "./achievement-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Achievement, UserAchievement } from "@shared/schema";

type UserAchievementWithDetails = UserAchievement & { achievement: Achievement };

interface AchievementsListProps {
  userId?: number;
  limit?: number;
}

/**
 * AchievementsList displays a grid of user achievements
 * Used on user profiles and achievement pages
 */
export function AchievementsList({ userId, limit }: AchievementsListProps) {
  const { data: userAchievements, isLoading } = useQuery<UserAchievementWithDetails[]>({
    queryKey: userId 
      ? ["/api/users", userId, "achievements"] 
      : ["/api/user/achievements"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  const { data: allAchievements, isLoading: isLoadingAll } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
    staleTime: 60 * 60 * 1000, // 1 hour
  });
  
  if (isLoading || isLoadingAll) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 py-4">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="flex flex-col items-center gap-2">
            <Skeleton className="h-16 w-16 rounded-full" />
            <Skeleton className="h-4 w-24" />
          </div>
        ))}
      </div>
    );
  }
  
  if (!userAchievements || !allAchievements) return null;
  
  // Filter and limit achievements if needed
  const displayedAchievements = limit
    ? allAchievements.slice(0, limit)
    : allAchievements;
  
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 py-4">
      {displayedAchievements.map((achievement) => {
        // Check if user has this achievement
        const userAchievement = userAchievements.find(
          (ua) => ua.achievementId === achievement.id
        );
        
        const isEarned = !!userAchievement;
        const progress = userAchievement?.progress || 0;
        
        return (
          <div key={achievement.id} className="flex flex-col items-center gap-2">
            <AchievementBadge
              name={achievement.name}
              description={achievement.description}
              badgeUrl={achievement.badgeUrl}
              isEarned={isEarned}
              progress={progress}
              thresholdValue={achievement.thresholdValue}
            />
            <span className="text-xs text-center font-medium">
              {achievement.name}
            </span>
          </div>
        );
      })}
    </div>
  );
}