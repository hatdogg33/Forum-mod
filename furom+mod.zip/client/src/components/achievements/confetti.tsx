import React, { useRef, useState, useEffect } from "react";

interface ConfettiPiece {
  x: number;
  y: number;
  rotation: number;
  shape: "rect" | "circle" | "star";
  size: number;
  color: string;
  speedX: number;
  speedY: number;
  rotationSpeed: number;
}

/**
 * Confetti animation component that creates a shower of colorful shapes
 * Used for achievement unlock celebrations
 */
export function Confetti() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pieces, setPieces] = useState<ConfettiPiece[]>([]);
  
  // Generate random confetti pieces on mount
  useEffect(() => {
    const colors = [
      "#EF4444", // red
      "#F59E0B", // amber
      "#10B981", // emerald
      "#3B82F6", // blue
      "#8B5CF6", // violet
      "#EC4899", // pink
    ];
    
    const shapes: Array<"rect" | "circle" | "star"> = ["rect", "circle", "star"];
    
    const newPieces: ConfettiPiece[] = [];
    
    // Create 100 random confetti pieces
    for (let i = 0; i < 100; i++) {
      newPieces.push({
        x: Math.random() * window.innerWidth,
        y: -20 - Math.random() * 100, // Start above the screen
        rotation: Math.random() * 360,
        shape: shapes[Math.floor(Math.random() * shapes.length)],
        size: 5 + Math.random() * 15,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: -1 + Math.random() * 2,
        speedY: 2 + Math.random() * 4,
        rotationSpeed: -3 + Math.random() * 6,
      });
    }
    
    setPieces(newPieces);
  }, []);
  
  // Animation loop
  useEffect(() => {
    if (!canvasRef.current || pieces.length === 0) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Set canvas size to match window
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    let animationFrameId: number;
    let lastTime = 0;
    
    const animate = (time: number) => {
      // Calculate delta time for smooth animation regardless of frame rate
      const deltaTime = (time - lastTime) / 16; // Normalize to ~60fps
      lastTime = time;
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Update and draw confetti
      setPieces(prevPieces => 
        prevPieces.map(piece => {
          // Update position
          const updatedPiece = {
            ...piece,
            y: piece.y + piece.speedY * deltaTime,
            x: piece.x + piece.speedX * deltaTime,
            rotation: (piece.rotation + piece.rotationSpeed * deltaTime) % 360,
          };
          
          // Draw the piece
          ctx.save();
          ctx.translate(updatedPiece.x, updatedPiece.y);
          ctx.rotate((updatedPiece.rotation * Math.PI) / 180);
          ctx.fillStyle = updatedPiece.color;
          
          // Draw different shapes
          if (updatedPiece.shape === "rect") {
            ctx.fillRect(
              -updatedPiece.size / 2,
              -updatedPiece.size / 4,
              updatedPiece.size,
              updatedPiece.size / 2
            );
          } else if (updatedPiece.shape === "circle") {
            ctx.beginPath();
            ctx.arc(0, 0, updatedPiece.size / 2, 0, Math.PI * 2);
            ctx.fill();
          } else if (updatedPiece.shape === "star") {
            drawStar(ctx, 0, 0, 5, updatedPiece.size/2, updatedPiece.size/4);
            ctx.fill();
          }
          
          ctx.restore();
          
          // Keep pieces that are still on screen
          return updatedPiece.y < canvas.height + 50 ? updatedPiece : {
            ...updatedPiece,
            // Reset pieces that go off screen for a continuous effect
            y: -20,
            x: Math.random() * canvas.width,
          };
        })
      );
      
      animationFrameId = requestAnimationFrame(animate);
    };
    
    animationFrameId = requestAnimationFrame(animate);
    
    // Clean up animation on unmount
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [pieces.length]);
  
  // Draw a star shape
  function drawStar(ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) {
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
  }
  
  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-50"
      style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", zIndex: 9999 }}
    />
  );
}