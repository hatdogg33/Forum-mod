import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface AnimatedBadgeProps {
  name: string;
  description: string;
  badgeUrl: string;
  thresholdValue?: number;
  className?: string;
}

/**
 * AnimatedBadge displays an achievement badge with animations
 * Used for the achievement unlock celebration
 */
export function AnimatedBadge({
  name,
  description,
  badgeUrl,
  thresholdValue,
  className,
}: AnimatedBadgeProps) {
  const [isAnimating, setIsAnimating] = useState(true);
  const [hasGlow, setHasGlow] = useState(false);
  const [hasShine, setHasShine] = useState(false);
  
  // Stagger the animations for a more dynamic effect
  useEffect(() => {
    // Start with the glow after a small delay
    const glowTimer = setTimeout(() => {
      setHasGlow(true);
    }, 300);
    
    // Add a shine effect later
    const shineTimer = setTimeout(() => {
      setHasShine(true);
    }, 1500);
    
    // Stop the initial animation after a while
    const animationTimer = setTimeout(() => {
      setIsAnimating(false);
    }, 2500);
    
    return () => {
      clearTimeout(glowTimer);
      clearTimeout(shineTimer);
      clearTimeout(animationTimer);
    };
  }, []);
  
  return (
    <div className={cn("flex flex-col items-center justify-center", className)}>
      <div className="relative mb-4">
        {/* Glow effect (appears behind the badge) */}
        {hasGlow && (
          <div className="absolute inset-0 rounded-full animate-badge-glow bg-amber-500/30"></div>
        )}
        
        {/* Badge with animations */}
        <div className="relative z-10">
          <img 
            src={badgeUrl} 
            alt={name}
            width={128}
            height={128}
            className={cn(
              "w-32 h-32 object-contain relative z-10",
              isAnimating ? "animate-badge-pulse" : "hover:animate-badge-pulse"
            )}
          />
          
          {/* Shine effect (animated diagonal highlight) */}
          {hasShine && (
            <div className="absolute inset-0 overflow-hidden rounded-full z-20 pointer-events-none">
              <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-white/30 skew-x-[45deg] animate-badge-shine"></div>
            </div>
          )}
        </div>
      </div>
      
      {/* Badge name and description */}
      <div className="text-center animate-fadeIn">
        <h3 className="text-xl font-bold">{name}</h3>
        <p className="text-muted-foreground text-sm mt-1">{description}</p>
      </div>

      {/* CSS Animations */}
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes badge-glow {
          0% { opacity: 0; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.5); }
          100% { opacity: 0.4; transform: scale(1.3); }
        }
        
        @keyframes badge-pulse {
          0% { transform: scale(1.0); }
          50% { transform: scale(1.1); }
          100% { transform: scale(1.0); }
        }
        
        @keyframes badge-shine {
          from { transform: translateX(-100%) rotate(45deg); }
          to { transform: translateX(100%) rotate(45deg); }
        }
        
        .animate-badge-glow {
          animation: badge-glow 1s ease-out forwards;
        }
        
        .animate-badge-glow-pulse {
          animation: badge-glow 1s ease-out forwards, badge-pulse 1s ease-in-out infinite;
        }
        
        .animate-badge-pulse {
          animation: badge-pulse 1s ease-in-out 3;
        }
        
        .animate-badge-shine {
          animation: badge-shine 1s ease-in-out;
        }
      `}} />
    </div>
  );
}