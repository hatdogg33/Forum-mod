import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const formSchema = z.object({
  name: z.string().min(3, { message: "Campaign name must be at least 3 characters long" }),
  type: z.enum(["watch-hours", "subscribers", "likes"], { 
    required_error: "Please select a campaign type" 
  }),
  channelUrl: z
    .string()
    .url({ message: "Please enter a valid YouTube URL" })
    .regex(/youtube\.com/, { message: "Please enter a valid YouTube channel URL" }),
  target: z
    .number({ invalid_type_error: "Please enter a number" })
    .int({ message: "Target must be a whole number" })
    .positive({ message: "Target must be positive" })
    .min(1, { message: "Target must be at least 1" }),
});

type FormValues = z.infer<typeof formSchema>;

interface CreateCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreateCampaignModal({ isOpen, onClose }: CreateCampaignModalProps) {
  const { toast } = useToast();
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      channelUrl: "",
      target: 1000,
    },
  });

  const onSubmit = async (data: FormValues) => {
    try {
      await apiRequest("POST", "/api/campaigns", data);
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Campaign created",
        description: "Your campaign has been created successfully",
      });
      form.reset();
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">Create New Campaign</DialogTitle>
          <DialogDescription>
            Create a new campaign to boost your YouTube metrics
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Campaign Name</Label>
              <Input
                id="name"
                placeholder="Enter campaign name"
                {...form.register("name")}
              />
              {form.formState.errors.name && (
                <p className="text-xs text-red-500">{form.formState.errors.name.message}</p>
              )}
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="type">Campaign Type</Label>
              <Select
                onValueChange={(value) => form.setValue("type", value as "watch-hours" | "subscribers" | "likes")}
                defaultValue={form.watch("type")}
              >
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="watch-hours">Watch Hours</SelectItem>
                  <SelectItem value="subscribers">Subscribers</SelectItem>
                  <SelectItem value="likes">Likes</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.type && (
                <p className="text-xs text-red-500">{form.formState.errors.type.message}</p>
              )}
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="channelUrl">YouTube Channel URL</Label>
              <Input
                id="channelUrl"
                placeholder="https://youtube.com/c/yourchannel"
                {...form.register("channelUrl")}
              />
              {form.formState.errors.channelUrl && (
                <p className="text-xs text-red-500">{form.formState.errors.channelUrl.message}</p>
              )}
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="target">Target Quantity</Label>
              <Input
                id="target"
                type="number"
                placeholder="Enter target number"
                {...form.register("target", { valueAsNumber: true })}
              />
              {form.formState.errors.target && (
                <p className="text-xs text-red-500">{form.formState.errors.target.message}</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-primary hover:bg-[#CC0000]"
              disabled={form.formState.isSubmitting}
            >
              {form.formState.isSubmitting ? (
                <>
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                    ></path>
                  </svg>
                  Creating...
                </>
              ) : (
                "Create Campaign"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
