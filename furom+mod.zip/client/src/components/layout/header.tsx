import React from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { BellIcon, Menu } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle?: string;
  onMenuClick: () => void;
}

export function Header({ title, subtitle, onMenuClick }: HeaderProps) {
  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    refetchOnWindowFocus: false,
  });

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase();
  };

  return (
    <>
      {/* Mobile header */}
      <div className="md:hidden bg-white border-b border-neutral-light w-full py-3 px-4 flex justify-between items-center">
        <Button
          variant="ghost"
          size="icon"
          className="text-neutral"
          onClick={onMenuClick}
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#FF0000"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-primary text-xl"
          >
            <circle cx="12" cy="12" r="10" />
            <polygon points="10 8 16 12 10 16 10 8" />
          </svg>
          <span className="font-bold text-lg">YTBoost</span>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-neutral relative">
            <BellIcon className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </Button>
          <Avatar className="h-8 w-8">
            <AvatarImage src="" alt={user?.fullName || "User"} />
            <AvatarFallback>{user?.fullName ? getInitials(user.fullName) : "U"}</AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Desktop header */}
      <header className="bg-white border-b border-neutral-light py-4 px-6 hidden md:flex justify-between items-center">
        <div>
          <h1 className="text-xl font-semibold">{title}</h1>
          <p className="text-sm text-neutral">{subtitle || `Welcome back, ${user?.fullName?.split(' ')[0] || 'User'}!`}</p>
        </div>
        <div className="flex items-center space-x-6">
          <Button variant="ghost" size="icon" className="text-neutral relative">
            <BellIcon className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </Button>
          <div className="flex items-center space-x-3">
            <Avatar className="h-9 w-9">
              <AvatarImage src="" alt={user?.fullName || "User"} />
              <AvatarFallback>{user?.fullName ? getInitials(user.fullName) : "U"}</AvatarFallback>
            </Avatar>
            <div className="hidden md:block">
              <p className="text-sm font-medium">{user?.fullName || "User"}</p>
              <p className="text-xs text-neutral">{user?.plan === "free" ? "Free Member" : "Premium Member"}</p>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
