import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface SidebarProps {
  isMobile?: boolean;
  onClose?: () => void;
}

export function Sidebar({ isMobile = false, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { toast } = useToast();
  
  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    refetchOnWindowFocus: false,
  });
  
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      window.location.href = "/login";
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const renderNavLink = (
    path: string,
    label: string,
    icon: JSX.Element
  ) => {
    const isActive = location === path;
    return (
      <Link href={path}>
        <a
          className={cn(
            "px-4 py-3 flex items-center space-x-3 rounded-lg mx-2 mt-1",
            isActive
              ? "text-white bg-[#404040]"
              : "text-neutral-light hover:text-white hover:bg-[#404040]"
          )}
          onClick={() => isMobile && onClose && onClose()}
        >
          {icon}
          <span>{label}</span>
        </a>
      </Link>
    );
  };

  return (
    <div className="bg-[#282828] text-white w-full md:w-64 flex flex-col h-full">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#FF0000"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-primary text-2xl"
          >
            <circle cx="12" cy="12" r="10" />
            <polygon points="10 8 16 12 10 16 10 8" />
          </svg>
          <span className="font-bold text-xl hidden md:inline">YTBoost</span>
        </div>
        {isMobile && onClose && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="md:hidden text-white"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M18 6 6 18" />
              <path d="m6 6 12 12" />
            </svg>
          </Button>
        )}
      </div>

      <div className="overflow-y-auto flex-grow scrollbar-hide">
        <div className="px-4 py-2 text-neutral-light text-xs font-semibold">MAIN MENU</div>
        {renderNavLink(
          "/",
          "Dashboard",
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect x="3" y="3" width="7" height="9" />
            <rect x="14" y="3" width="7" height="5" />
            <rect x="14" y="12" width="7" height="9" />
            <rect x="3" y="16" width="7" height="5" />
          </svg>
        )}
        {renderNavLink(
          "/campaigns",
          "Campaigns",
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m3 11 18-5v12L3 13" />
            <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
          </svg>
        )}
        {renderNavLink(
          "/services",
          "Services",
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
            <path d="M12 17h.01" />
          </svg>
        )}
        {renderNavLink(
          "/billing",
          "Billing",
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect width="20" height="14" x="2" y="5" rx="2" />
            <line x1="2" x2="22" y1="10" y2="10" />
          </svg>
        )}

        <div className="px-4 py-2 text-neutral-light text-xs font-semibold mt-6">ACCOUNT</div>
        {renderNavLink(
          "/profile",
          "Profile",
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="8" r="5" />
            <path d="M20 21a8 8 0 1 0-16 0" />
          </svg>
        )}
        <a
          className="px-4 py-3 flex items-center space-x-3 text-neutral-light hover:text-white hover:bg-[#404040] rounded-lg mx-2 mt-1 cursor-pointer"
          onClick={handleLogout}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" x2="9" y1="12" y2="12" />
          </svg>
          <span>Logout</span>
        </a>
      </div>

      <div className="p-4 hidden md:block">
        <div className="bg-[#404040] rounded-lg p-3">
          <p className="text-xs text-neutral-light mb-2">Your current plan</p>
          <div className="flex justify-between items-center">
            <span className="font-semibold">{user?.plan === "free" ? "Free Plan" : "Pro Plan"}</span>
            <Button className="text-xs bg-primary text-white h-auto py-1 px-2" size="sm">
              Upgrade
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
