import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { formatNumber } from "@/lib/utils";
import { cn } from "@/lib/utils";

type MetricIconType = "clock" | "users" | "thumbs-up" | "bullhorn";
type TrendDirection = "up" | "down" | "neutral";

interface MetricsCardProps {
  title: string;
  value: number;
  icon: MetricIconType;
  trend: number;
  className?: string;
}

export function MetricsCard({ title, value, icon, trend, className }: MetricsCardProps) {
  const iconColors: Record<MetricIconType, string> = {
    clock: "text-primary bg-primary/10",
    users: "text-info bg-info/10",
    "thumbs-up": "text-success bg-success/10",
    bullhorn: "text-warning bg-warning/10",
  };

  const trendDirection: TrendDirection = trend > 0 ? "up" : trend < 0 ? "down" : "neutral";
  
  const trendColors: Record<TrendDirection, string> = {
    up: "text-success",
    down: "text-danger",
    neutral: "text-neutral",
  };

  return (
    <Card className={cn("shadow-card", className)}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-neutral text-sm">{title}</p>
            <h3 className="text-2xl font-semibold mt-1">{formatNumber(value)}</h3>
          </div>
          <div className={cn("p-2 rounded-lg", iconColors[icon])}>
            {icon === "clock" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-clock"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
            )}
            {icon === "users" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-users"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            )}
            {icon === "thumbs-up" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-thumbs-up"
              >
                <path d="M7 10v12" />
                <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
              </svg>
            )}
            {icon === "bullhorn" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-megaphone"
              >
                <path d="m3 11 18-5v12L3 13" />
                <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
              </svg>
            )}
          </div>
        </div>
        <div className="flex items-center mt-2">
          <span className={cn("text-xs flex items-center", trendColors[trendDirection])}>
            {trendDirection === "up" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-arrow-up mr-1"
              >
                <path d="m5 12 7-7 7 7" />
                <path d="M12 19V5" />
              </svg>
            )}
            {trendDirection === "down" && (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-arrow-down mr-1"
              >
                <path d="M12 5v14" />
                <path d="m19 12-7 7-7-7" />
              </svg>
            )}
            {Math.abs(trend)}%
          </span>
          <span className="text-xs text-neutral ml-2">vs last month</span>
        </div>
      </CardContent>
    </Card>
  );
}
