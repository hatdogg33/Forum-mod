import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface ServiceCardProps {
  name: string;
  type: string;
  features: string[];
  basePrice: number;
  onSelect: () => void;
  className?: string;
}

export function ServiceCard({ name, type, features, basePrice, onSelect, className }: ServiceCardProps) {
  const getServiceIcon = (type: string) => {
    switch (type) {
      case "watch-hours":
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-clock"
          >
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
        );
      case "subscribers":
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-users"
          >
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
          </svg>
        );
      case "likes":
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-thumbs-up"
          >
            <path d="M7 10v12" />
            <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
          </svg>
        );
      default:
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-megaphone"
          >
            <path d="m3 11 18-5v12L3 13" />
            <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
          </svg>
        );
    }
  };

  const getServiceColor = (type: string) => {
    switch (type) {
      case "watch-hours":
        return {
          bg: "bg-primary/10",
          icon: "bg-primary text-white",
        };
      case "subscribers":
        return {
          bg: "bg-info/10",
          icon: "bg-info text-white",
        };
      case "likes":
        return {
          bg: "bg-success/10",
          icon: "bg-success text-white",
        };
      default:
        return {
          bg: "bg-warning/10",
          icon: "bg-warning text-white",
        };
    }
  };

  const colors = getServiceColor(type);

  return (
    <Card className={cn("overflow-hidden shadow-card", className)}>
      <div className={cn("p-4 flex justify-between items-center", colors.bg)}>
        <div className="flex items-center">
          <div className={cn("rounded-lg p-3", colors.icon)}>{getServiceIcon(type)}</div>
          <h3 className="ml-3 font-semibold">{name}</h3>
        </div>
        <span className="text-primary font-medium">From {formatCurrency(basePrice)}</span>
      </div>
      <CardContent className="p-4">
        <ul className="space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-4 w-4 text-success mt-1 mr-2" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
        <Button
          variant="outline"
          className="mt-4 w-full border-primary text-primary hover:bg-primary/10"
          onClick={onSelect}
        >
          Select Package
        </Button>
      </CardContent>
    </Card>
  );
}
