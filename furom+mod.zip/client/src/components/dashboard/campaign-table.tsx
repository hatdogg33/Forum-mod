import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pause, Play, MoreVertical, RotateCcw } from "lucide-react";
import { cn, formatDate, calculatePercentage, getStatusColor } from "@/lib/utils";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";

interface Campaign {
  id: number;
  name: string;
  type: string;
  target: number;
  progress: number;
  status: string;
  createdAt: string;
}

interface CampaignTableProps {
  campaigns: Campaign[];
  onStatusChange: (id: number, status: string) => void;
  className?: string;
}

export function CampaignTable({ campaigns, onStatusChange, className }: CampaignTableProps) {
  const [searchQuery, setSearchQuery] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [currentPage, setCurrentPage] = React.useState(1);
  const itemsPerPage = 4;
  const { toast } = useToast();

  const getCampaignTypeIcon = (type: string) => {
    switch (type) {
      case "watch-hours":
        return (
          <div className="bg-primary/20 p-2 rounded-md mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-primary"
            >
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
        );
      case "subscribers":
        return (
          <div className="bg-info/20 p-2 rounded-md mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-info"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
        );
      case "likes":
        return (
          <div className="bg-success/20 p-2 rounded-md mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-success"
            >
              <path d="M7 10v12" />
              <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="bg-primary/20 p-2 rounded-md mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-primary"
            >
              <path d="m3 11 18-5v12L3 13" />
              <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
            </svg>
          </div>
        );
    }
  };

  const filteredCampaigns = campaigns.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || campaign.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const paginatedCampaigns = filteredCampaigns.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredCampaigns.length / itemsPerPage);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleStatusToggle = (campaign: Campaign) => {
    let newStatus: string;
    let message: string;
    
    if (campaign.status === "active") {
      newStatus = "paused";
      message = "Campaign paused successfully";
    } else if (campaign.status === "paused") {
      newStatus = "active";
      message = "Campaign activated successfully";
    } else if (campaign.status === "completed") {
      newStatus = "active";
      message = "Campaign restarted successfully";
    } else {
      newStatus = "active";
      message = "Campaign status updated";
    }
    
    onStatusChange(campaign.id, newStatus);
    
    toast({
      title: "Status Updated",
      description: message,
      duration: 3000,
    });
  };

  const getTypeLabel = (type: string): string => {
    switch (type) {
      case "watch-hours":
        return "Watch Hours";
      case "subscribers":
        return "Subscribers";
      case "likes":
        return "Likes";
      default:
        return type;
    }
  };

  const getUnitLabel = (type: string): string => {
    switch (type) {
      case "watch-hours":
        return "hours";
      case "subscribers":
        return "subs";
      case "likes":
        return "likes";
      default:
        return "units";
    }
  };

  const getStatusToggleButton = (campaign: Campaign) => {
    if (campaign.status === "active") {
      return (
        <Button
          variant="ghost"
          size="icon"
          className="text-primary hover:text-primary-hover"
          onClick={() => handleStatusToggle(campaign)}
        >
          <Pause className="h-4 w-4" />
        </Button>
      );
    } else if (campaign.status === "paused") {
      return (
        <Button
          variant="ghost"
          size="icon"
          className="text-primary hover:text-primary-hover"
          onClick={() => handleStatusToggle(campaign)}
        >
          <Play className="h-4 w-4" />
        </Button>
      );
    } else if (campaign.status === "completed") {
      return (
        <Button
          variant="ghost"
          size="icon"
          className="text-primary hover:text-primary-hover"
          onClick={() => handleStatusToggle(campaign)}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      );
    }
    
    return null;
  };

  return (
    <Card className={cn("shadow-card", className)}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center flex-wrap gap-4">
          <CardTitle className="text-lg font-semibold">Active Campaigns</CardTitle>
          <div className="flex space-x-2 flex-wrap gap-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search campaigns..."
                className="pl-8 h-9 w-full sm:w-auto"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
            </div>
            <Select 
              value={statusFilter} 
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[140px] h-9">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="px-5">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-lightest">
              <TableRow className="border-b border-neutral-light">
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Campaign</TableHead>
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Type</TableHead>
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Target</TableHead>
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Progress</TableHead>
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Status</TableHead>
                <TableHead className="py-3 text-left text-xs font-medium text-neutral uppercase tracking-wider">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedCampaigns.length > 0 ? (
                paginatedCampaigns.map((campaign) => (
                  <TableRow 
                    key={campaign.id} 
                    className="border-b border-neutral-light hover:bg-neutral-lightest"
                  >
                    <TableCell className="py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        {getCampaignTypeIcon(campaign.type)}
                        <div>
                          <div className="font-medium text-sm">{campaign.name}</div>
                          <div className="text-xs text-neutral">
                            Created on {formatDate(campaign.createdAt)}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="py-3 whitespace-nowrap text-sm">
                      {getTypeLabel(campaign.type)}
                    </TableCell>
                    <TableCell className="py-3 whitespace-nowrap text-sm">
                      {campaign.target.toLocaleString()} {getUnitLabel(campaign.type)}
                    </TableCell>
                    <TableCell className="py-3 whitespace-nowrap">
                      <div className="w-full bg-neutral-light rounded-full h-2 max-w-[120px]">
                        <div 
                          className={cn(
                            "h-2 rounded-full", 
                            campaign.status === "completed" ? "bg-neutral" : 
                            campaign.status === "paused" ? "bg-warning" : "bg-success"
                          )} 
                          style={{ width: `${calculatePercentage(campaign.progress, campaign.target)}%` }}
                        ></div>
                      </div>
                      <div className="text-xs mt-1">
                        {campaign.progress.toLocaleString()} / {campaign.target.toLocaleString()} 
                        ({calculatePercentage(campaign.progress, campaign.target)}%)
                      </div>
                    </TableCell>
                    <TableCell className="py-3 whitespace-nowrap">
                      <span 
                        className={cn(
                          "text-xs px-2 py-1 rounded-full", 
                          getStatusColor(campaign.status).bg, 
                          getStatusColor(campaign.status).text
                        )}
                      >
                        {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="py-3 whitespace-nowrap text-sm">
                      <div className="flex items-center">
                        {getStatusToggleButton(campaign)}
                        <Button variant="ghost" size="icon" className="text-neutral hover:text-secondary">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6 text-neutral">
                    No campaigns found matching your criteria
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        
        {filteredCampaigns.length > 0 && (
          <div className="mt-4 flex justify-between items-center">
            <div className="text-sm text-neutral">
              Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredCampaigns.length)} of {filteredCampaigns.length} campaigns
            </div>
            <div className="flex space-x-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="text-sm text-neutral"
              >
                Previous
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={page === currentPage ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(page)}
                  className={cn(
                    "text-sm",
                    page === currentPage ? "bg-primary text-white" : "text-neutral"
                  )}
                >
                  {page}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="text-sm text-neutral"
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
