import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { formatDate, calculatePercentage, getStatusColor } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface Campaign {
  id: number;
  name: string;
  createdAt: string;
  status: string;
  progress: number;
  target: number;
}

interface RecentCampaignsProps {
  campaigns: Campaign[];
  onCreateCampaign: () => void;
  onViewAllCampaigns: () => void;
  className?: string;
}

export function RecentCampaigns({ 
  campaigns, 
  onCreateCampaign, 
  onViewAllCampaigns,
  className 
}: RecentCampaignsProps) {
  return (
    <Card className={cn("shadow-card", className)}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold">Recent Campaigns</CardTitle>
          <Button 
            variant="link" 
            className="text-primary text-sm p-0 h-auto" 
            onClick={onViewAllCampaigns}
          >
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="px-5">
        {campaigns.length > 0 ? (
          <div className="space-y-0">
            {campaigns.map((campaign) => (
              <div key={campaign.id} className="border-b border-neutral-light last:border-b-0 py-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-secondary">{campaign.name}</h4>
                    <p className="text-xs text-neutral mt-1">Started {formatDate(campaign.createdAt)}</p>
                  </div>
                  <span className={cn("text-xs px-2 py-1 rounded-full", getStatusColor(campaign.status).bg, getStatusColor(campaign.status).text)}>
                    {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                  </span>
                </div>
                <div className="mt-2">
                  <div className="flex justify-between text-xs text-neutral mb-1">
                    <span>Progress</span>
                    <span>{calculatePercentage(campaign.progress, campaign.target)}%</span>
                  </div>
                  <div className="w-full bg-neutral-light rounded-full h-2">
                    <div 
                      className={cn(
                        "h-2 rounded-full", 
                        campaign.status === "completed" ? "bg-neutral" : "bg-success"
                      )} 
                      style={{ width: `${calculatePercentage(campaign.progress, campaign.target)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-6 text-center text-neutral">
            <p>No campaigns yet</p>
            <p className="text-sm mt-1">Create a campaign to get started</p>
          </div>
        )}
        
        <div className="mt-4">
          <Button 
            className="w-full bg-primary hover:bg-[#CC0000] text-white"
            onClick={onCreateCampaign}
          >
            <Plus className="mr-2 h-4 w-4" /> Create New Campaign
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
