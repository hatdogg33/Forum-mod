import { ReactNode, useState } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ModeToggle } from "@/components/ui/mode-toggle";
import { useAuth } from "@/hooks/use-auth";
import { SearchBar } from "@/components/search-bar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuShortcut,
} from "@/components/ui/dropdown-menu";
import { 
  Home, 
  LayoutGrid, 
  MessageSquare, 
  Upload, 
  User, 
  LogOut,
  Menu,
  Bell,
  ShieldAlert,
  UserPlus,
  CircleUser,
  Clock,
  BookOpen,
  Crown,
  Settings,
  HelpCircle,
  ShieldCheck,
  X
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [showGuestInfo, setShowGuestInfo] = useState(false);
  const [cookieConsent, setCookieConsent] = useState(() => {
    // Check if user has already consented to cookies
    return localStorage.getItem('cookie-consent') === 'true';
  });

  const navigationItems = [
    {
      name: "Home",
      href: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      name: "Categories",
      href: "/categories",
      icon: <LayoutGrid className="h-5 w-5" />,
    },
    {
      name: "Recent Threads",
      href: "/threads",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      name: "Mods",
      href: "/mods",
      icon: <Upload className="h-5 w-5" />,
    },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const acceptCookies = () => {
    localStorage.setItem('cookie-consent', 'true');
    setCookieConsent(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto py-3 px-4 flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center cursor-pointer mr-4">
                <span className="font-bold text-lg md:text-xl text-primary">ModForum</span>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-1">
              {navigationItems.map((item) => (
                <Button
                  key={item.href}
                  variant={location === item.href ? "secondary" : "ghost"}
                  size="sm"
                  asChild
                >
                  <Link href={item.href}>
                    <span className="flex items-center gap-2">
                      {item.icon}
                      <span>{item.name}</span>
                    </span>
                  </Link>
                </Button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Bar */}
            <div className="hidden md:block mr-2">
              <SearchBar />
            </div>
            
            {/* Membership Badge if user has a plan */}
            {user && user.plan && user.plan !== 'free' && (
              <Badge variant="outline" className="hidden sm:flex items-center gap-1 border-yellow-400 text-yellow-600 dark:text-yellow-400">
                <Crown className="h-3 w-3" />
                <span className="capitalize">{user.plan}</span>
              </Badge>
            )}
            
            {/* Guest Info Button */}
            {!user && (
              <Dialog open={showGuestInfo} onOpenChange={setShowGuestInfo}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="hidden md:flex">
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Guest Info</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[475px]">
                  <DialogHeader>
                    <DialogTitle>Guest Visitor Information</DialogTitle>
                    <DialogDescription>
                      Welcome to ModForum! Here's what you can do as a guest.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="py-4 space-y-3">
                    <div className="flex items-start gap-3">
                      <BookOpen className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <h3 className="font-medium mb-0.5">Browse Content</h3>
                        <p className="text-sm text-muted-foreground">View all public categories, threads, and mods.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <X className="h-5 w-5 text-destructive mt-0.5" />
                      <div>
                        <h3 className="font-medium mb-0.5">Limited Access</h3>
                        <p className="text-sm text-muted-foreground">Cannot create threads, reply to posts, or download premium mods.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <UserPlus className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h3 className="font-medium mb-0.5">Register an Account</h3>
                        <p className="text-sm text-muted-foreground">Sign up to participate in discussions and access more features.</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Crown className="h-5 w-5 text-yellow-600 mt-0.5" />
                      <div>
                        <h3 className="font-medium mb-0.5">Membership Benefits</h3>
                        <p className="text-sm text-muted-foreground">Premium members get access to exclusive mods and features.</p>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button asChild>
                      <Link href="/auth">Create Account</Link>
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
            
            <ModeToggle />
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="relative flex items-center space-x-2 rounded-full"
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar || ""} alt={user.username} />
                      <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    {/* Notification indicator */}
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.username}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                      {user.role === 'admin' && (
                        <Badge variant="outline" className="self-start mt-1 bg-primary/10 text-primary">Admin</Badge>
                      )}
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem asChild>
                      <Link href="/profile">
                        <User className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/membership">
                        <Crown className="mr-2 h-4 w-4" />
                        <span>Membership</span>
                        {user.plan !== 'free' && (
                          <DropdownMenuShortcut>
                            <Badge variant="outline" className="capitalize">{user.plan}</Badge>
                          </DropdownMenuShortcut>
                        )}
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href={`/profile/${user.id}/achievements`}>
                        <ShieldCheck className="mr-2 h-4 w-4" />
                        <span>Achievements</span>
                      </Link>
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} disabled={logoutMutation.isPending}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" asChild className="hidden sm:flex">
                  <Link href="/auth?signup=true">
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Register</span>
                  </Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href="/auth">
                    <CircleUser className="mr-2 h-4 w-4" />
                    <span>Login</span>
                  </Link>
                </Button>
              </div>
            )}
            
            {/* Mobile navigation */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col h-full">
                  <div className="flex-1 py-6">
                    <div className="mb-8 flex items-center">
                      <Link href="/">
                        <h2 className="text-2xl font-bold text-primary">ModForum</h2>
                      </Link>
                    </div>
                    
                    {/* Mobile search */}
                    <div className="mb-4">
                      <SearchBar />
                    </div>
                    
                    <nav className="flex flex-col space-y-2">
                      {navigationItems.map((item) => (
                        <SheetClose key={item.href} asChild>
                          <Button
                            variant={location === item.href ? "secondary" : "ghost"}
                            className="justify-start"
                            asChild
                          >
                            <Link href={item.href}>
                              <span className="flex items-center gap-3">
                                {item.icon}
                                <span>{item.name}</span>
                              </span>
                            </Link>
                          </Button>
                        </SheetClose>
                      ))}
                      
                      {user ? (
                        <>
                          <SheetClose asChild>
                            <Button variant="ghost" className="justify-start" asChild>
                              <Link href="/profile">
                                <User className="mr-3 h-5 w-5" />
                                <span>Profile</span>
                              </Link>
                            </Button>
                          </SheetClose>
                          <SheetClose asChild>
                            <Button variant="ghost" className="justify-start" asChild>
                              <Link href="/membership">
                                <Crown className="mr-3 h-5 w-5" />
                                <span>Membership</span>
                                {user.plan !== 'free' && (
                                  <Badge variant="outline" className="ml-auto capitalize">{user.plan}</Badge>
                                )}
                              </Link>
                            </Button>
                          </SheetClose>
                        </>
                      ) : (
                        <SheetClose asChild>
                          <Button variant="ghost" className="justify-start" onClick={() => setShowGuestInfo(true)}>
                            <HelpCircle className="mr-3 h-5 w-5" />
                            <span>Guest Info</span>
                          </Button>
                        </SheetClose>
                      )}
                    </nav>
                  </div>
                  
                  {user ? (
                    <div className="border-t pt-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={user.avatar || ""} alt={user.username} />
                          <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.username}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        className="w-full"
                        onClick={handleLogout}
                        disabled={logoutMutation.isPending}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="border-t pt-6 flex flex-col gap-2">
                      <SheetClose asChild>
                        <Button asChild>
                          <Link href="/auth">
                            <CircleUser className="mr-2 h-4 w-4" />
                            <span>Login</span>
                          </Link>
                        </Button>
                      </SheetClose>
                      <SheetClose asChild>
                        <Button variant="outline" asChild>
                          <Link href="/auth?signup=true">
                            <UserPlus className="mr-2 h-4 w-4" />
                            <span>Register</span>
                          </Link>
                        </Button>
                      </SheetClose>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1 py-4">
        {children}
      </main>

      <footer className="border-t py-6 md:py-0">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0 md:h-16">
            <div className="text-sm text-gray-500">
              © {new Date().getFullYear()} ModForum. All rights reserved.
            </div>
            <div className="flex space-x-4">
              <Button variant="link" size="sm" asChild>
                <Link href="/terms">Terms</Link>
              </Button>
              <Button variant="link" size="sm" asChild>
                <Link href="/privacy">Privacy</Link>
              </Button>
              <Button variant="link" size="sm" asChild>
                <Link href="/contact">Contact</Link>
              </Button>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Cookie consent banner */}
      {!cookieConsent && (
        <div className="fixed bottom-0 w-full bg-primary-foreground border-t z-50 py-3">
          <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-sm">
              <p>We use cookies to enhance your browsing experience and analyze site traffic.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={acceptCookies}>
                Accept All
              </Button>
              <Button variant="link" size="sm" asChild>
                <Link href="/privacy">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}