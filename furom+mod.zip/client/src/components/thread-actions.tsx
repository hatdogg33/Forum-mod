import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Trash, MoreVertical, Lock, Pin, Edit, Flag } from "lucide-react";

interface ThreadActionsProps {
  threadId: number;
  threadOwnerId: number;
  isPinned: boolean;
  isLocked: boolean;
}

export function ThreadActions({ threadId, threadOwnerId, isPinned, isLocked }: ThreadActionsProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  const isOwner = user?.id === threadOwnerId;
  const isAdmin = user?.role === 'admin';
  const canModerate = isOwner || isAdmin;
  
  // Delete thread mutation
  const deleteThreadMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/threads/${threadId}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to delete thread");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Thread deleted",
        description: "The thread has been successfully deleted",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/threads/recent"] });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Toggle pin status mutation
  const togglePinMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/threads/${threadId}/pin`, { 
        isPinned: !isPinned 
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to update pin status");
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: data.isPinned ? "Thread pinned" : "Thread unpinned",
        description: data.isPinned 
          ? "The thread has been pinned to the top" 
          : "The thread has been unpinned",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/threads/${threadId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Toggle lock status mutation
  const toggleLockMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/threads/${threadId}/lock`, { 
        isLocked: !isLocked 
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to update lock status");
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: data.isLocked ? "Thread locked" : "Thread unlocked",
        description: data.isLocked 
          ? "The thread has been locked from further replies" 
          : "The thread has been unlocked for replies",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/threads/${threadId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDelete = () => {
    deleteThreadMutation.mutate();
    setShowDeleteDialog(false);
  };
  
  if (!canModerate) {
    return null;
  }
  
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
            <span className="sr-only">Thread actions</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Thread Actions</DropdownMenuLabel>
          
          {isOwner && (
            <>
              <DropdownMenuItem asChild>
                <Button variant="ghost" className="w-full justify-start cursor-pointer" asChild>
                  <a href={`/threads/${threadId}/edit`}>
                    <Edit className="mr-2 h-4 w-4" />
                    <span>Edit Thread</span>
                  </a>
                </Button>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            </>
          )}
          
          {isAdmin && (
            <>
              <DropdownMenuItem onClick={() => togglePinMutation.mutate()}>
                <Pin className="mr-2 h-4 w-4" />
                <span>{isPinned ? "Unpin Thread" : "Pin Thread"}</span>
              </DropdownMenuItem>
              
              <DropdownMenuItem onClick={() => toggleLockMutation.mutate()}>
                <Lock className="mr-2 h-4 w-4" />
                <span>{isLocked ? "Unlock Thread" : "Lock Thread"}</span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
            </>
          )}
          
          <DropdownMenuItem onClick={() => setShowDeleteDialog(true)} className="text-red-600 focus:text-red-600">
            <Trash className="mr-2 h-4 w-4" />
            <span>Delete Thread</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will delete the thread and all its posts. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 focus:ring-red-600"
            >
              {deleteThreadMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}