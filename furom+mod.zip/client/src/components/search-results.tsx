import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Package, FolderOpen } from "lucide-react";
import { format } from "date-fns";

export interface SearchResult {
  id: number;
  type: "thread" | "mod" | "category" | "user";
  title: string;
  excerpt: string;
  url: string;
  updatedAt: string;
}

interface SearchResultsProps {
  results: SearchResult[];
  onResultClick?: () => void;
}

export function SearchResults({ results, onResultClick }: SearchResultsProps) {
  if (results.length === 0) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        No results found
      </div>
    );
  }

  return (
    <div className="max-h-[400px] overflow-y-auto p-2">
      {results.map((result) => (
        <Card 
          key={`${result.type}-${result.id}`} 
          className="mb-2 hover:bg-accent/50 transition-colors cursor-pointer"
        >
          <CardContent className="p-3">
            <Link href={result.url} onClick={onResultClick}>
              <div className="flex items-start gap-3">
                <div className="mt-1 flex-shrink-0">
                  {result.type === "thread" && (
                    <FileText className="h-5 w-5 text-blue-500" />
                  )}
                  {result.type === "mod" && (
                    <Package className="h-5 w-5 text-green-500" />
                  )}
                  {result.type === "category" && (
                    <FolderOpen className="h-5 w-5 text-amber-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-medium truncate">{result.title}</h3>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {format(new Date(result.updatedAt), "MMM d, yyyy")}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{result.excerpt}</p>
                  <div className="mt-1 text-xs">
                    <span className="inline-flex items-center rounded-full bg-accent/50 px-2 py-0.5 text-xs font-medium capitalize">
                      {result.type}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}