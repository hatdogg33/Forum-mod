import { Request, Response, NextFunction } from 'express';
import { db } from './db';
import { sql } from 'drizzle-orm';

interface RateLimitInfo {
  ip: string;
  path: string;
  count: number;
  resetAt: Date;
}

// In-memory store for rate limiting
const rateLimitStore = new Map<string, RateLimitInfo>();

/**
 * Rate limiting middleware to prevent brute force attacks
 * @param maxAttempts Maximum number of attempts allowed in the window
 * @param windowMs Time window in milliseconds
 * @param message Custom error message
 */
export function rateLimiter(maxAttempts: number = 5, windowMs: number = 15 * 60 * 1000, message: string = 'Too many requests, please try again later.') {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const path = req.path;
    const key = `${ip}:${path}`;
    
    const now = new Date();
    const resetAt = new Date(now.getTime() + windowMs);
    
    // Check if this IP + path combination is already in the store
    if (rateLimitStore.has(key)) {
      const limitInfo = rateLimitStore.get(key)!;
      
      // If the reset time has passed, reset the count
      if (now > limitInfo.resetAt) {
        limitInfo.count = 1;
        limitInfo.resetAt = resetAt;
      } else {
        // Increment the count
        limitInfo.count++;
        
        // If the count exceeds the maximum, block the request
        if (limitInfo.count > maxAttempts) {
          // Calculate the time remaining in seconds
          const timeRemaining = Math.ceil((limitInfo.resetAt.getTime() - now.getTime()) / 1000);
          
          // Log the blocked attempt
          console.warn(`Rate limit exceeded for ${ip} on ${path}. Blocking request.`);
          
          // Set the appropriate headers
          res.setHeader('Retry-After', timeRemaining.toString());
          
          // Record the failed attempt for security monitoring
          logSecurityEvent(ip, path, 'rate_limit_exceeded', req.method);
          
          return res.status(429).json({ 
            message, 
            retryAfter: timeRemaining,
            success: false
          });
        }
      }
    } else {
      // First request from this IP for this path
      rateLimitStore.set(key, {
        ip,
        path,
        count: 1,
        resetAt
      });
    }
    
    next();
  };
}

/**
 * Log security events to the database for monitoring
 */
async function logSecurityEvent(ip: string, path: string, eventType: string, method: string) {
  try {
    await db.execute(sql`
      INSERT INTO security_logs (ip_address, path, event_type, method, created_at)
      VALUES (${ip}, ${path}, ${eventType}, ${method}, NOW())
    `);
  } catch (error) {
    console.error('Failed to log security event:', error);
  }
}

/**
 * Get all active security events for an IP
 */
export async function getSecurityEvents(ip: string, timeWindowMs: number = 24 * 60 * 60 * 1000) {
  const cutoff = new Date(Date.now() - timeWindowMs);
  
  try {
    const results = await db.execute(sql`
      SELECT * FROM security_logs
      WHERE ip_address = ${ip}
      AND created_at > ${cutoff}
      ORDER BY created_at DESC
    `);
    
    return results;
  } catch (error) {
    console.error('Failed to retrieve security events:', error);
    return [];
  }
}

/**
 * Clear rate limit for a specific IP and path
 */
export function clearRateLimit(ip: string, path: string) {
  const key = `${ip}:${path}`;
  rateLimitStore.delete(key);
}

/**
 * Get rate limit info for a specific IP and path
 */
export function getRateLimitInfo(ip: string, path: string): RateLimitInfo | undefined {
  const key = `${ip}:${path}`;
  return rateLimitStore.get(key);
}