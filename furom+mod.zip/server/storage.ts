import { users, type User, type InsertUser, categories, type Category, type InsertCategory, threads, type Thread, type InsertThread, posts, type Post, type InsertPost, likes, type Like, type InsertLike, mods, type Mod, type InsertMod, campaigns, type Campaign, type InsertCampaign, metrics, type Metrics, type InsertMetrics, services, type Service, type InsertService, achievements, type Achievement, type InsertAchievement, userAchievements, type UserAchievement, type InsertUserAchievement, MembershipPlan, AchievementType } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lt, or, sql, ilike } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  sessionStore: session.Store;
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPostCount(userId: number, increment: number): Promise<User | undefined>;
  updateUserMembership(userId: number, plan: MembershipPlan, planExpiresAt: Date): Promise<User | undefined>;
  updatePaypalCustomerId(userId: number, paypalCustomerId: string): Promise<User | undefined>;
  updateUserPaypalInfo(userId: number, paypalInfo: { paypalCustomerId: string, paypalSubscriptionId: string }): Promise<User | undefined>;
  updateBinanceUserId(userId: number, binanceUserId: string): Promise<User | undefined>;
  
  // Forum Category methods
  getAllCategories(): Promise<Category[]>;
  getActiveCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  
  // Thread methods
  getThread(id: number): Promise<Thread | undefined>;
  getThreadsByCategoryId(categoryId: number): Promise<Thread[]>;
  getRecentThreads(limit?: number): Promise<Thread[]>;
  createThread(thread: InsertThread): Promise<Thread>;
  updateThread(id: number, thread: Partial<InsertThread>): Promise<Thread | undefined>;
  incrementThreadViewCount(id: number): Promise<Thread | undefined>;
  
  // Post methods
  getPost(id: number): Promise<Post | undefined>;
  getPostsByThreadId(threadId: number): Promise<Post[]>;
  getPostsByUserId(userId: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, content: string): Promise<Post | undefined>;
  
  // Like methods
  getLike(postId: number, userId: number): Promise<Like | undefined>;
  getLikesByPostId(postId: number): Promise<Like[]>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(postId: number, userId: number): Promise<boolean>;
  
  // Mod methods
  getMod(id: number): Promise<Mod | undefined>;
  getAllMods(): Promise<Mod[]>;
  getModsByGame(game: string): Promise<Mod[]>;
  getModsByUserId(userId: number): Promise<Mod[]>;
  createMod(mod: InsertMod): Promise<Mod>;
  updateMod(id: number, mod: Partial<InsertMod>): Promise<Mod | undefined>;
  incrementModDownloadCount(id: number): Promise<Mod | undefined>;
  
  // Search methods
  searchUsers(query: string): Promise<User[]>;
  searchThreads(query: string): Promise<Thread[]>;
  searchMods(query: string): Promise<Mod[]>;
  searchCategories(query: string): Promise<Category[]>;
  
  // Achievement methods
  getAchievement(id: number): Promise<Achievement | undefined>;
  getAllAchievements(): Promise<Achievement[]>;
  getAchievementsByType(type: AchievementType): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  updateAchievement(id: number, achievement: Partial<InsertAchievement>): Promise<Achievement | undefined>;

  // User Achievement methods
  getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  getUserAchievementProgress(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement | undefined>;
  markUserAchievementAsSeen(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  checkAndGrantAchievements(userId: number): Promise<Achievement[]>;
  
  // Campaign methods (legacy)
  getCampaign(id: number): Promise<Campaign | undefined>;
  getCampaignsByUserId(userId: number): Promise<Campaign[]>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaignProgress(id: number, progress: number): Promise<Campaign | undefined>;
  updateCampaignStatus(id: number, status: string): Promise<Campaign | undefined>;
  
  // Metrics methods (legacy)
  getMetricsByUserId(userId: number): Promise<Metrics | undefined>;
  getMetricsHistoryByUserId(userId: number): Promise<Metrics[]>;
  createMetrics(metrics: InsertMetrics): Promise<Metrics>;
  updateMetrics(id: number, metrics: Partial<InsertMetrics>): Promise<Metrics | undefined>;
  
  // Service methods (legacy)
  getAllServices(): Promise<Service[]>;
  getServicesByType(type: string): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    
    // Initialize default data
    this.initializeDefaultData();
  }
  
  private async initializeDefaultData() {
    try {
      // Check if we need to initialize achievements
      const achievementsCount = await db.select({ count: sql<number>`count(*)` })
        .from(achievements)
        .then(result => Number(result[0].count));
        
      if (achievementsCount === 0) {
        await this.initializeAchievements();
      }
      
      // Check if we need to initialize services
      const servicesCount = await db.select({ count: sql<number>`count(*)` })
        .from(services)
        .then(result => Number(result[0].count));
        
      if (servicesCount === 0) {
        await this.initializeServices();
      }
      
      // Check if we need to initialize forum categories
      const categoriesCount = await db.select({ count: sql<number>`count(*)` })
        .from(categories)
        .then(result => Number(result[0].count));
        
      if (categoriesCount === 0) {
        await this.initializeForumCategories();
      }
    } catch (error) {
      console.error("Error initializing default data:", error);
    }
  }
  
  private async initializeForumCategories() {
    const defaultCategories: InsertCategory[] = [
      {
        name: "General Discussion",
        description: "General discussion about modding and gaming",
        slug: "general-discussion",
        isActive: true,
        order: 1
      },
      {
        name: "Mod Releases",
        description: "Share your mod releases with the community",
        slug: "mod-releases",
        isActive: true,
        order: 2
      },
      {
        name: "Mod Requests",
        description: "Request mods for your favorite games",
        slug: "mod-requests",
        isActive: true,
        order: 3
      },
      {
        name: "Modding Help",
        description: "Get help with creating or installing mods",
        slug: "modding-help",
        isActive: true,
        order: 4
      },
      {
        name: "Game-Specific Discussion",
        description: "Discuss specific games and their modding communities",
        slug: "game-specific",
        isActive: true,
        order: 5
      }
    ];
    
    for (const category of defaultCategories) {
      await db.insert(categories).values(category);
    }
  }
  
  private async initializeServices() {
    const watchHoursService: InsertService = {
      name: "Watch Hours",
      description: "Boost your YouTube watch hours",
      type: "watch-hours",
      basePrice: 29.99,
      features: ["Increase watch time", "Boost ranking", "Improve visibility"]
    };
    
    const subscribersService: InsertService = {
      name: "Subscribers",
      description: "Grow your YouTube subscribers",
      type: "subscribers",
      basePrice: 39.99,
      features: ["Organic growth", "Active subscribers", "Channel credibility"]
    };
    
    const likesService: InsertService = {
      name: "Video Likes",
      description: "Increase engagement with more likes",
      type: "likes",
      basePrice: 19.99,
      features: ["Improve engagement", "Better algorithm ranking", "Social proof"]
    };
    
    await db.insert(services).values(watchHoursService);
    await db.insert(services).values(subscribersService);
    await db.insert(services).values(likesService);
  }
  
  private async initializeAchievements() {
    const defaultAchievements: InsertAchievement[] = [
      {
        name: "First Post",
        description: "Create your first forum post",
        type: "first_post",
        badgeUrl: "/badges/first-post.svg",
        thresholdValue: 1
      },
      {
        name: "First Thread",
        description: "Create your first forum thread",
        type: "first_thread",
        badgeUrl: "/badges/first-thread.svg",
        thresholdValue: 1
      },
      {
        name: "First Mod",
        description: "Upload your first mod",
        type: "first_mod",
        badgeUrl: "/badges/first-mod.svg",
        thresholdValue: 1
      },
      {
        name: "Popular Modder",
        description: "Get 100 downloads on your mods",
        type: "mod_download",
        badgeUrl: "/badges/popular-modder.svg",
        thresholdValue: 100
      }
    ];
    
    for (const achievement of defaultAchievements) {
      await db.insert(achievements).values(achievement);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserPostCount(userId: number, increment: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const [updatedUser] = await db
      .update(users)
      .set({ postsCount: user.postsCount + increment })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserMembership(userId: number, plan: MembershipPlan, planExpiresAt: Date): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ plan, planExpiresAt })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updatePaypalCustomerId(userId: number, paypalCustomerId: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ paypalCustomerId })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserPaypalInfo(userId: number, paypalInfo: { paypalCustomerId: string, paypalSubscriptionId: string }): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(paypalInfo)
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateBinanceUserId(userId: number, binanceUserId: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ binanceUserId })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }
  
  // Search methods
  async searchUsers(query: string): Promise<User[]> {
    // Safely escape and parameterize the query
    const searchPattern = `%${query.replace(/[%_\\]/g, '\\$&')}%`;
    const results = await db
      .select()
      .from(users)
      .where(
        or(
          ilike(users.username, searchPattern),
          ilike(users.email, searchPattern)
        )
      )
      .limit(20);
    
    return results;
  }
  
  async searchThreads(query: string): Promise<Thread[]> {
    // Safely escape and parameterize the query
    const searchPattern = `%${query.replace(/[%_\\]/g, '\\$&')}%`;
    const results = await db
      .select()
      .from(threads)
      .where(
        and(
          or(
            ilike(threads.title, searchPattern),
            ilike(threads.content, searchPattern)
          ),
          eq(threads.isDeleted, false)
        )
      )
      .orderBy(desc(threads.lastActivityAt))
      .limit(20);
    
    return results;
  }
  
  async searchMods(query: string): Promise<Mod[]> {
    // Safely escape and parameterize the query
    const searchPattern = `%${query.replace(/[%_\\]/g, '\\$&')}%`;
    const results = await db
      .select()
      .from(mods)
      .where(
        or(
          ilike(mods.name, searchPattern),
          ilike(mods.description, searchPattern),
          ilike(mods.game, searchPattern)
        )
      )
      .orderBy(desc(mods.updatedAt))
      .limit(20);
    
    return results;
  }
  
  async searchCategories(query: string): Promise<Category[]> {
    // Safely escape and parameterize the query
    const searchPattern = `%${query.replace(/[%_\\]/g, '\\$&')}%`;
    const results = await db
      .select()
      .from(categories)
      .where(
        and(
          or(
            ilike(categories.name, searchPattern),
            ilike(categories.description, searchPattern)
          ),
          eq(categories.isActive, true)
        )
      )
      .orderBy(categories.order)
      .limit(20);
    
    return results;
  }

  // Forum Category methods
  async getAllCategories(): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .orderBy(categories.order);
  }

  async getActiveCategories(): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(categories.order);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id));
    return result[0];
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.slug, slug));
    return result[0];
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    
    return newCategory;
  }

  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    
    return updatedCategory;
  }

  // Thread methods
  async getThread(id: number): Promise<Thread | undefined> {
    const result = await db
      .select()
      .from(threads)
      .where(and(
        eq(threads.id, id),
        eq(threads.isDeleted, false)
      ));
    return result[0];
  }

  async getThreadsByCategoryId(categoryId: number): Promise<Thread[]> {
    return await db
      .select()
      .from(threads)
      .where(and(
        eq(threads.categoryId, categoryId),
        eq(threads.isDeleted, false)
      ))
      .orderBy(desc(threads.isPinned), desc(threads.lastActivityAt));
  }

  async getRecentThreads(limit: number = 10): Promise<Thread[]> {
    return await db
      .select()
      .from(threads)
      .where(eq(threads.isDeleted, false))
      .orderBy(desc(threads.lastActivityAt))
      .limit(limit);
  }
  
  async getThreadsByUserId(userId: number): Promise<Thread[]> {
    return await db
      .select()
      .from(threads)
      .where(and(
        eq(threads.userId, userId),
        eq(threads.isDeleted, false)
      ))
      .orderBy(desc(threads.lastActivityAt));
  }

  async createThread(thread: InsertThread): Promise<Thread> {
    const [newThread] = await db
      .insert(threads)
      .values(thread)
      .returning();
    
    return newThread;
  }

  async updateThread(id: number, thread: Partial<InsertThread>): Promise<Thread | undefined> {
    const [updatedThread] = await db
      .update(threads)
      .set(thread)
      .where(eq(threads.id, id))
      .returning();
    
    return updatedThread;
  }

  async incrementThreadViewCount(id: number): Promise<Thread | undefined> {
    const thread = await this.getThread(id);
    if (!thread) return undefined;
    
    const [updatedThread] = await db
      .update(threads)
      .set({ viewCount: thread.viewCount + 1 })
      .where(eq(threads.id, id))
      .returning();
    
    return updatedThread;
  }

  async softDeleteThread(id: number): Promise<Thread | undefined> {
    const [deletedThread] = await db
      .update(threads)
      .set({ isDeleted: true })
      .where(eq(threads.id, id))
      .returning();
    
    return deletedThread;
  }

  // Post methods
  async getPost(id: number): Promise<Post | undefined> {
    const result = await db.select().from(posts).where(eq(posts.id, id));
    return result[0];
  }

  async getPostsByThreadId(threadId: number): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.threadId, threadId))
      .orderBy(posts.createdAt);
  }

  async getPostsByUserId(userId: number): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
  }

  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db
      .insert(posts)
      .values(post)
      .returning();
    
    // Increment the user's post count
    await this.updateUserPostCount(post.userId, 1);
    
    // Update the thread's last activity time
    await db
      .update(threads)
      .set({ lastActivityAt: new Date() })
      .where(eq(threads.id, post.threadId));
    
    return newPost;
  }

  async updatePost(id: number, content: string): Promise<Post | undefined> {
    const [updatedPost] = await db
      .update(posts)
      .set({ 
        content, 
        isEdited: true,
        editedAt: new Date() 
      })
      .where(eq(posts.id, id))
      .returning();
    
    return updatedPost;
  }

  // Like methods
  async getLike(postId: number, userId: number): Promise<Like | undefined> {
    const result = await db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
    
    return result[0];
  }

  async getLikesByPostId(postId: number): Promise<Like[]> {
    return await db
      .select()
      .from(likes)
      .where(eq(likes.postId, postId));
  }

  async createLike(like: InsertLike): Promise<Like> {
    // Check if like already exists
    const existingLike = await this.getLike(like.postId, like.userId);
    if (existingLike) {
      return existingLike;
    }
    
    const [newLike] = await db
      .insert(likes)
      .values(like)
      .returning();
    
    return newLike;
  }

  async deleteLike(postId: number, userId: number): Promise<boolean> {
    // First check if like exists
    const existingLike = await this.getLike(postId, userId);
    if (!existingLike) {
      return false;
    }
    
    await db
      .delete(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
    
    return true;
  }

  // Mod methods
  async getMod(id: number): Promise<Mod | undefined> {
    const result = await db.select().from(mods).where(eq(mods.id, id));
    return result[0];
  }

  async getAllMods(): Promise<Mod[]> {
    return await db
      .select()
      .from(mods)
      .orderBy(desc(mods.createdAt));
  }

  async getModsByGame(game: string): Promise<Mod[]> {
    return await db
      .select()
      .from(mods)
      .where(eq(mods.game, game))
      .orderBy(desc(mods.createdAt));
  }

  async getModsByUserId(userId: number): Promise<Mod[]> {
    return await db
      .select()
      .from(mods)
      .where(eq(mods.userId, userId))
      .orderBy(desc(mods.createdAt));
  }

  async createMod(mod: InsertMod): Promise<Mod> {
    const [newMod] = await db
      .insert(mods)
      .values(mod)
      .returning();
    
    return newMod;
  }

  async updateMod(id: number, mod: Partial<InsertMod>): Promise<Mod | undefined> {
    const [updatedMod] = await db
      .update(mods)
      .set(mod)
      .where(eq(mods.id, id))
      .returning();
    
    return updatedMod;
  }

  async incrementModDownloadCount(id: number): Promise<Mod | undefined> {
    const mod = await this.getMod(id);
    if (!mod) return undefined;
    
    const [updatedMod] = await db
      .update(mods)
      .set({ downloadCount: mod.downloadCount + 1 })
      .where(eq(mods.id, id))
      .returning();
    
    return updatedMod;
  }

  // Achievement methods
  async getAchievement(id: number): Promise<Achievement | undefined> {
    const result = await db.select().from(achievements).where(eq(achievements.id, id));
    return result[0];
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return await db.select().from(achievements);
  }

  async getAchievementsByType(type: AchievementType): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.type, type));
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    
    return newAchievement;
  }

  async updateAchievement(id: number, achievement: Partial<InsertAchievement>): Promise<Achievement | undefined> {
    const [updatedAchievement] = await db
      .update(achievements)
      .set(achievement)
      .where(eq(achievements.id, id))
      .returning();
    
    return updatedAchievement;
  }

  // User Achievement methods
  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const results = await db
      .select({
        userAchievement: userAchievements,
        achievement: achievements
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId));
    
    return results.map(({ userAchievement, achievement }) => ({
      ...userAchievement,
      achievement
    }));
  }

  async getUserAchievementProgress(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    const result = await db
      .select()
      .from(userAchievements)
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ));
    
    return result[0];
  }

  async createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const [newUserAchievement] = await db
      .insert(userAchievements)
      .values(userAchievement)
      .returning();
    
    return newUserAchievement;
  }

  async updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement | undefined> {
    const userAchievement = await this.getUserAchievementProgress(userId, achievementId);
    
    if (!userAchievement) {
      // Create new record if it doesn't exist
      return await this.createUserAchievement({
        userId,
        achievementId,
        progress,
        isNew: true
      });
    }
    
    // Get the achievement to check required progress
    const achievement = await this.getAchievement(achievementId);
    if (!achievement) return undefined;
    
    // Update the progress
    const achievementCompleted = progress >= achievement.thresholdValue;
    
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set({ 
        progress,
        // If just completed, set unlockedAt to now
        unlockedAt: achievementCompleted && progress > userAchievement.progress ? new Date() : userAchievement.unlockedAt
      })
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ))
      .returning();
    
    return updatedUserAchievement;
  }

  async markUserAchievementAsSeen(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set({ isNew: false })
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ))
      .returning();
    
    return updatedUserAchievement;
  }

  async checkAndGrantAchievements(userId: number): Promise<Achievement[]> {
    const newlyCompletedAchievements: Achievement[] = [];
    const allAchievements = await this.getAllAchievements();
    
    // First Post Achievement
    const firstPostAchievement = allAchievements.find(a => a.name === "First Post");
    if (firstPostAchievement) {
      const userPosts = await this.getPostsByUserId(userId);
      if (userPosts.length > 0) {
        const existingProgress = await this.getUserAchievementProgress(userId, firstPostAchievement.id);
        // Check if the achievement is already unlocked
        if (!existingProgress || !existingProgress.unlockedAt) {
          const updatedProgress = await this.updateUserAchievementProgress(userId, firstPostAchievement.id, 1);
          // If the achievement was just unlocked
          if (updatedProgress?.unlockedAt && (!existingProgress || !existingProgress.unlockedAt)) {
            newlyCompletedAchievements.push(firstPostAchievement);
          }
        }
      }
    }
    
    // First Thread Achievement
    const firstThreadAchievement = allAchievements.find(a => a.name === "First Thread");
    if (firstThreadAchievement) {
      const userThreads = await db
        .select()
        .from(threads)
        .where(eq(threads.userId, userId));
      
      if (userThreads.length > 0) {
        const existingProgress = await this.getUserAchievementProgress(userId, firstThreadAchievement.id);
        // Check if the achievement is already unlocked
        if (!existingProgress || !existingProgress.unlockedAt) {
          const updatedProgress = await this.updateUserAchievementProgress(userId, firstThreadAchievement.id, 1);
          // If the achievement was just unlocked
          if (updatedProgress?.unlockedAt && (!existingProgress || !existingProgress.unlockedAt)) {
            newlyCompletedAchievements.push(firstThreadAchievement);
          }
        }
      }
    }
    
    // First Mod Achievement
    const firstModAchievement = allAchievements.find(a => a.name === "First Mod");
    if (firstModAchievement) {
      const userMods = await this.getModsByUserId(userId);
      if (userMods.length > 0) {
        const existingProgress = await this.getUserAchievementProgress(userId, firstModAchievement.id);
        // Check if the achievement is already unlocked
        if (!existingProgress || !existingProgress.unlockedAt) {
          const updatedProgress = await this.updateUserAchievementProgress(userId, firstModAchievement.id, 1);
          // If the achievement was just unlocked
          if (updatedProgress?.unlockedAt && (!existingProgress || !existingProgress.unlockedAt)) {
            newlyCompletedAchievements.push(firstModAchievement);
          }
        }
      }
    }
    
    // Popular Modder Achievement
    const popularModderAchievement = allAchievements.find(a => a.name === "Popular Modder");
    if (popularModderAchievement) {
      const userMods = await this.getModsByUserId(userId);
      const totalDownloads = userMods.reduce((total, mod) => total + mod.downloadCount, 0);
      
      if (totalDownloads > 0) {
        const existingProgress = await this.getUserAchievementProgress(userId, popularModderAchievement.id);
        const currentProgress = existingProgress?.progress || 0;
        
        if (totalDownloads > currentProgress) {
          const updatedProgress = await this.updateUserAchievementProgress(userId, popularModderAchievement.id, totalDownloads);
          
          // Check if the achievement was just unlocked
          const justUnlocked = updatedProgress?.unlockedAt && 
                              (!existingProgress || !existingProgress.unlockedAt);
                              
          if (justUnlocked) {
            newlyCompletedAchievements.push(popularModderAchievement);
          }
        }
      }
    }
    
    return newlyCompletedAchievements;
  }

  // Campaign methods (legacy)
  async getCampaign(id: number): Promise<Campaign | undefined> {
    const result = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return result[0];
  }

  async getCampaignsByUserId(userId: number): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.userId, userId))
      .orderBy(desc(campaigns.createdAt));
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db
      .insert(campaigns)
      .values(campaign)
      .returning();
    
    return newCampaign;
  }

  async updateCampaignProgress(id: number, progress: number): Promise<Campaign | undefined> {
    const campaign = await this.getCampaign(id);
    if (!campaign) return undefined;
    
    // Ensure progress doesn't exceed target
    const newProgress = Math.min(progress, campaign.target);
    
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ 
        progress: newProgress,
        status: newProgress >= campaign.target ? "completed" : campaign.status 
      })
      .where(eq(campaigns.id, id))
      .returning();
    
    // Create a metrics history entry if it's a real progress update
    if (newProgress > campaign.progress) {
      // Get current metrics or create new
      let currentMetrics = await this.getMetricsByUserId(campaign.userId);
      if (!currentMetrics) {
        currentMetrics = await this.createMetrics({
          userId: campaign.userId,
          watchHours: 0,
          subscribers: 0,
          likes: 0,
          activeCampaigns: 0
        });
      }
      
      // Update metrics based on campaign type
      const metricsUpdate: Partial<InsertMetrics> = {};
      const progressDiff = newProgress - campaign.progress;
      
      if (campaign.type === "watch-hours") {
        metricsUpdate.watchHours = currentMetrics.watchHours + progressDiff;
      } else if (campaign.type === "subscribers") {
        metricsUpdate.subscribers = currentMetrics.subscribers + progressDiff;
      } else if (campaign.type === "likes") {
        metricsUpdate.likes = currentMetrics.likes + progressDiff;
      }
      
      // Update metrics
      const updatedMetrics = await this.updateMetrics(currentMetrics.id, metricsUpdate);
      
      // Create history entry by inserting a new metrics entry
      await db.insert(metrics).values({
        userId: campaign.userId,
        watchHours: updatedMetrics?.watchHours ?? currentMetrics.watchHours,
        subscribers: updatedMetrics?.subscribers ?? currentMetrics.subscribers,
        likes: updatedMetrics?.likes ?? currentMetrics.likes,
        activeCampaigns: updatedMetrics?.activeCampaigns ?? currentMetrics.activeCampaigns,
        date: new Date() // Use current date for the historical entry
      });
    }
    
    return updatedCampaign;
  }

  async updateCampaignStatus(id: number, status: string): Promise<Campaign | undefined> {
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ status })
      .where(eq(campaigns.id, id))
      .returning();
    
    return updatedCampaign;
  }

  // Metrics methods (legacy)
  async getMetricsByUserId(userId: number): Promise<Metrics | undefined> {
    const result = await db
      .select()
      .from(metrics)
      .where(eq(metrics.userId, userId))
      .orderBy(desc(metrics.date))
      .limit(1);
    
    return result[0];
  }

  async getMetricsHistoryByUserId(userId: number): Promise<Metrics[]> {
    return await db
      .select()
      .from(metrics)
      .where(eq(metrics.userId, userId))
      .orderBy(metrics.date);
  }

  async createMetrics(metricsData: InsertMetrics): Promise<Metrics> {
    const [newMetrics] = await db
      .insert(metrics)
      .values({
        ...metricsData,
        date: new Date() // Always add current date
      })
      .returning();
    
    return newMetrics;
  }

  async updateMetrics(id: number, partialMetrics: Partial<InsertMetrics>): Promise<Metrics | undefined> {
    const [updatedMetrics] = await db
      .update(metrics)
      .set({
        ...partialMetrics,
        date: new Date() // Update date instead of updatedAt
      })
      .where(eq(metrics.id, id))
      .returning();
    
    return updatedMetrics;
  }

  // Service methods (legacy)
  async getAllServices(): Promise<Service[]> {
    return await db
      .select()
      .from(services);
  }

  async getServicesByType(type: string): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(eq(services.type, type));
  }

  async getService(id: number): Promise<Service | undefined> {
    const result = await db.select().from(services).where(eq(services.id, id));
    return result[0];
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db
      .insert(services)
      .values(service)
      .returning();
    
    return newService;
  }
}

export const storage = new DatabaseStorage();