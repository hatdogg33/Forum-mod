import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCampaignSchema, 
  insertCategorySchema, 
  insertThreadSchema, 
  insertPostSchema, 
  insertLikeSchema, 
  insertModSchema,
  insertAchievementSchema,
  insertUserAchievementSchema,
  MembershipPlan,
  Thread,
  Mod,
  Category
} from "@shared/schema";
import { membershipRankSufficient } from "@shared/utils";
import { ZodError } from "zod";
import { setupAuth } from "./auth";
import paypal from "@paypal/checkout-server-sdk";
import { db } from "./db";
import { sql } from "drizzle-orm";

// PayPal client setup
let paypalClient: any = null;

// Check if PayPal credentials are available
if (process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET) {
  // Set up the PayPal client
  const environment = process.env.NODE_ENV === "production"
    ? new paypal.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET)
    : new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET);
  
  paypalClient = new paypal.core.PayPalHttpClient(environment);
}

export function registerRoutes(app: Express): Server {
  // Set up authentication with Passport
  setupAuth(app);
  
  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };
  
  // Search functionality
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query || query.length < 2) {
        return res.status(400).json({ message: "Search query must be at least 2 characters" });
      }
      
      // Get all resources that match the query
      const [threads, mods, categories] = await Promise.all([
        storage.searchThreads(query),
        storage.searchMods(query),
        storage.searchCategories(query),
      ]);
      
      // Format the results
      const results = [
        ...threads.map((thread: Thread) => ({
          id: thread.id,
          type: "thread" as const,
          title: thread.title,
          excerpt: thread.content.substring(0, 120) + (thread.content.length > 120 ? "..." : ""),
          url: `/threads/${thread.id}`,
          updatedAt: thread.lastActivityAt?.toISOString() || thread.createdAt.toISOString(),
        })),
        ...mods.map((mod: Mod) => ({
          id: mod.id,
          type: "mod" as const,
          title: mod.name,
          excerpt: mod.description.substring(0, 120) + (mod.description.length > 120 ? "..." : ""),
          url: `/mods/${mod.id}`,
          updatedAt: mod.updatedAt.toISOString(),
        })),
        ...categories.map((category: Category) => ({
          id: category.id,
          type: "category" as const,
          title: category.name,
          excerpt: category.description.substring(0, 120) + (category.description.length > 120 ? "..." : ""),
          url: `/categories/${category.slug}`,
          updatedAt: category.createdAt.toISOString(), // Use createdAt since categories don't have updatedAt
        })),
      ];
      
      // Sort results by most recent
      results.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      
      res.json(results);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "Error performing search" });
    }
  });

  // Campaigns routes
  app.get("/api/campaigns", requireAuth, async (req: any, res) => {
    try {
      const campaigns = await storage.getCampaignsByUserId(req.user.id);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/campaigns", requireAuth, async (req: any, res) => {
    try {
      const campaignData = insertCampaignSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const campaign = await storage.createCampaign(campaignData);
      res.status(201).json(campaign);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/campaigns/:id/progress", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { progress } = req.body;
      
      if (typeof progress !== "number" || progress < 0) {
        return res.status(400).json({ message: "Invalid progress value" });
      }
      
      const campaign = await storage.getCampaign(Number(id));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      if (campaign.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized to update this campaign" });
      }
      
      const updatedCampaign = await storage.updateCampaignProgress(Number(id), progress);
      res.json(updatedCampaign);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/campaigns/:id/status", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!["active", "paused", "completed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const campaign = await storage.getCampaign(Number(id));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      if (campaign.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized to update this campaign" });
      }
      
      const updatedCampaign = await storage.updateCampaignStatus(Number(id), status);
      res.json(updatedCampaign);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Metrics routes
  app.get("/api/metrics", requireAuth, async (req: any, res) => {
    try {
      const metrics = await storage.getMetricsByUserId(req.session.userId);
      if (!metrics) {
        return res.status(404).json({ message: "Metrics not found" });
      }
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/metrics/history", requireAuth, async (req: any, res) => {
    try {
      const history = await storage.getMetricsHistoryByUserId(req.session.userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Services routes
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/services/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const services = await storage.getServicesByType(type);
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Simulate campaign progress for demo purposes
  app.post("/api/simulate/progress", requireAuth, async (req: any, res) => {
    try {
      const { campaignId, amount = 5 } = req.body;
      
      const campaign = await storage.getCampaign(Number(campaignId));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      if (campaign.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized to update this campaign" });
      }
      
      const newProgress = Math.min(campaign.progress + amount, campaign.target);
      const updatedCampaign = await storage.updateCampaignProgress(Number(campaignId), newProgress);
      
      res.json(updatedCampaign);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ===========================================
  // ADMIN ROUTES
  // ===========================================
  
  // Admin middleware
  const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Check if the user is an admin
    const user = await storage.getUser(req.user!.id);
    if (!user || user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden: Admin access required" });
    }
    
    next();
  };

  // Security logs endpoint for admin dashboard
  app.get("/api/admin/security-logs", requireAuth, requireAdmin, async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;
      
      // Build the query with potential filters
      let query = sql`
        SELECT * FROM security_logs
        WHERE 1=1
      `;
      
      // Add filters if provided
      if (req.query.ip) {
        query = sql`${query} AND ip_address LIKE ${`%${req.query.ip}%`}`;
      }
      
      if (req.query.event) {
        query = sql`${query} AND event_type LIKE ${`%${req.query.event}%`}`;
      }
      
      if (req.query.userId) {
        query = sql`${query} AND user_id = ${parseInt(req.query.userId as string)}`;
      }
      
      if (req.query.path) {
        query = sql`${query} AND path LIKE ${`%${req.query.path}%`}`;
      }
      
      // Add ordering and pagination
      query = sql`
        ${query} 
        ORDER BY created_at DESC
        LIMIT ${limit} OFFSET ${offset}
      `;
      
      const logs = await db.execute(query);
      
      // Convert DB field names to camelCase for frontend
      const formattedLogs = logs.rows.map((log: any) => ({
        id: log.id,
        ipAddress: log.ip_address,
        path: log.path,
        eventType: log.event_type,
        method: log.method,
        userId: log.user_id,
        details: log.details,
        createdAt: log.created_at
      }));
      
      res.json(formattedLogs);
    } catch (error) {
      console.error("Error fetching security logs:", error);
      res.status(500).json({ message: "Error fetching security logs" });
    }
  });
  
  // Get security statistics for admin dashboard
  app.get("/api/admin/security-stats", requireAuth, requireAdmin, async (req, res) => {
    try {
      // Get the timeframe from query params, default to last 24 hours
      const hours = parseInt(req.query.hours as string) || 24;
      const since = new Date();
      since.setHours(since.getHours() - hours);
      
      // Get total count of security events
      const totalEvents = await db.execute(sql`
        SELECT COUNT(*) as count FROM security_logs
        WHERE created_at > ${since}
      `);
      
      // Get failed login attempts
      const failedLogins = await db.execute(sql`
        SELECT COUNT(*) as count FROM security_logs
        WHERE event_type = 'login_failed'
        AND created_at > ${since}
      `);
      
      // Get successful logins
      const successfulLogins = await db.execute(sql`
        SELECT COUNT(*) as count FROM security_logs
        WHERE event_type = 'login_successful'
        AND created_at > ${since}
      `);
      
      // Get top IP addresses with failed login attempts
      const topFailedIPs = await db.execute(sql`
        SELECT ip_address, COUNT(*) as count
        FROM security_logs
        WHERE event_type = 'login_failed'
        AND created_at > ${since}
        GROUP BY ip_address
        ORDER BY count DESC
        LIMIT 5
      `);
      
      // Format the response
      const stats = {
        totalEvents: parseInt(totalEvents.rows[0].count),
        failedLogins: parseInt(failedLogins.rows[0].count),
        successfulLogins: parseInt(successfulLogins.rows[0].count),
        topFailedIPs: topFailedIPs.rows.map((row: any) => ({
          ipAddress: row.ip_address,
          count: parseInt(row.count)
        })),
        loginSuccessRate: successfulLogins.rows[0].count > 0 
          ? Math.round((parseInt(successfulLogins.rows[0].count) / 
             (parseInt(successfulLogins.rows[0].count) + parseInt(failedLogins.rows[0].count))) * 100)
          : 0
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching security statistics:", error);
      res.status(500).json({ message: "Error fetching security statistics" });
    }
  });
  
  // ===========================================
  // FORUM ROUTES
  // ===========================================

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getActiveCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/all", requireAuth, async (req: any, res) => {
    try {
      // Check if admin (only admins can see inactive categories)
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const category = await storage.getCategory(Number(id));
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      if (!category.isActive) {
        // If category is inactive, only allow admins to view it
        if (!req.session?.userId) {
          return res.status(404).json({ message: "Category not found" });
        }
        
        const user = await storage.getUser(req.session.userId);
        if (!user || user.role !== "admin") {
          return res.status(404).json({ message: "Category not found" });
        }
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/slug/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const category = await storage.getCategoryBySlug(slug);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      if (!category.isActive) {
        // If category is inactive, only allow admins to view it
        if (!req.session?.userId) {
          return res.status(404).json({ message: "Category not found" });
        }
        
        const user = await storage.getUser(req.session.userId);
        if (!user || user.role !== "admin") {
          return res.status(404).json({ message: "Category not found" });
        }
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/categories", requireAuth, async (req: any, res) => {
    try {
      // Only admins can create categories
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to create categories" });
      }
      
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/categories/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Only admins can update categories
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update categories" });
      }
      
      const category = await storage.getCategory(Number(id));
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const updateData = insertCategorySchema.partial().parse(req.body);
      const updatedCategory = await storage.updateCategory(Number(id), updateData);
      
      res.json(updatedCategory);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Thread routes
  app.get("/api/threads/recent", async (req, res) => {
    try {
      const limit = req.query.limit ? Number(req.query.limit) : undefined;
      const threads = await storage.getRecentThreads(limit);
      res.json(threads);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/:categoryId/threads", async (req, res) => {
    try {
      const { categoryId } = req.params;
      
      const category = await storage.getCategory(Number(categoryId));
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      if (!category.isActive) {
        // If category is inactive, only allow admins to view its threads
        if (!req.session?.userId) {
          return res.status(404).json({ message: "Category not found" });
        }
        
        const user = await storage.getUser(req.session.userId);
        if (!user || user.role !== "admin") {
          return res.status(404).json({ message: "Category not found" });
        }
      }
      
      const threads = await storage.getThreadsByCategoryId(Number(categoryId));
      res.json(threads);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/threads/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const thread = await storage.getThread(Number(id));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      // Check if thread's category is active
      const category = await storage.getCategory(thread.categoryId);
      if (!category || !category.isActive) {
        // If category is inactive, only allow admins to view its threads
        if (!req.session?.userId) {
          return res.status(404).json({ message: "Thread not found" });
        }
        
        const user = await storage.getUser(req.session.userId);
        if (!user || user.role !== "admin") {
          return res.status(404).json({ message: "Thread not found" });
        }
      }
      
      // Increment view count
      await storage.incrementThreadViewCount(Number(id));
      
      res.json(thread);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/threads", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      const threadData = insertThreadSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      // Check if category exists and is active
      const category = await storage.getCategory(threadData.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      if (!category.isActive && user.role !== "admin") {
        return res.status(403).json({ message: "Cannot create thread in inactive category" });
      }
      
      // Only admins can pin or lock threads during creation
      if (user.role !== "admin") {
        threadData.isPinned = false;
        threadData.isLocked = false;
      }
      
      const thread = await storage.createThread(threadData);
      res.status(201).json(thread);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/threads/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const thread = await storage.getThread(Number(id));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Check permissions: only thread creator or admin can update thread
      if (thread.userId !== req.session.userId && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this thread" });
      }
      
      // Regular users can only update content and title
      let updateData;
      if (user.role === "admin") {
        updateData = insertThreadSchema.partial().parse(req.body);
      } else {
        // Regular users can only update title and content
        updateData = insertThreadSchema.pick({
          title: true,
          content: true
        }).partial().parse(req.body);
      }
      
      const updatedThread = await storage.updateThread(Number(id), updateData);
      res.json(updatedThread);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Soft delete a thread
  app.delete("/api/threads/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const thread = await storage.getThread(Number(id));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Check permissions: only thread creator or admin can delete thread
      if (thread.userId !== req.session.userId && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this thread" });
      }
      
      const deletedThread = await storage.softDeleteThread(Number(id));
      res.json({ 
        success: true, 
        message: "Thread deleted successfully",
        thread: deletedThread
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Toggle thread pin status (admin only)
  app.patch("/api/threads/:id/pin", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const thread = await storage.getThread(Number(id));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Only admins can pin/unpin threads
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only administrators can pin or unpin threads" });
      }
      
      const isPinned = req.body.isPinned;
      const updatedThread = await storage.updateThread(Number(id), { 
        isPinned: isPinned 
      });
      
      res.json(updatedThread);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Toggle thread lock status (admin only)
  app.patch("/api/threads/:id/lock", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const thread = await storage.getThread(Number(id));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Only admins can lock/unlock threads
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only administrators can lock or unlock threads" });
      }
      
      const isLocked = req.body.isLocked;
      const updatedThread = await storage.updateThread(Number(id), { 
        isLocked: isLocked 
      });
      
      res.json(updatedThread);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Post routes
  app.get("/api/threads/:threadId/posts", async (req, res) => {
    try {
      const { threadId } = req.params;
      const thread = await storage.getThread(Number(threadId));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      // Check if thread's category is active
      const category = await storage.getCategory(thread.categoryId);
      if (!category || !category.isActive) {
        // If category is inactive, only allow admins to view its threads and posts
        if (!req.session?.userId) {
          return res.status(404).json({ message: "Thread not found" });
        }
        
        const user = await storage.getUser(req.session.userId);
        if (!user || user.role !== "admin") {
          return res.status(404).json({ message: "Thread not found" });
        }
      }
      
      const posts = await storage.getPostsByThreadId(Number(threadId));
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/threads/:threadId/posts", requireAuth, async (req: any, res) => {
    try {
      const { threadId } = req.params;
      const thread = await storage.getThread(Number(threadId));
      
      if (!thread) {
        return res.status(404).json({ message: "Thread not found" });
      }
      
      // Check if thread is locked
      if (thread.isLocked) {
        const user = await storage.getUser(req.session.userId);
        // Only admin can post in locked threads
        if (!user || user.role !== "admin") {
          return res.status(403).json({ message: "Thread is locked" });
        }
      }
      
      // Check if thread's category is active
      const category = await storage.getCategory(thread.categoryId);
      if (!category || !category.isActive) {
        const user = await storage.getUser(req.session.userId);
        // Only admin can post in inactive categories
        if (!user || user.role !== "admin") {
          return res.status(403).json({ message: "Cannot post in inactive category" });
        }
      }
      
      const postData = insertPostSchema.parse({
        ...req.body,
        threadId: Number(threadId),
        userId: req.session.userId
      });
      
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/posts/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const post = await storage.getPost(Number(id));
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check permissions: only post creator or admin can update post
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      if (post.userId !== req.session.userId && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this post" });
      }
      
      const { content } = req.body;
      if (!content || typeof content !== "string" || content.trim() === "") {
        return res.status(400).json({ message: "Content is required" });
      }
      
      const updatedPost = await storage.updatePost(Number(id), content);
      res.json(updatedPost);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Like routes
  app.get("/api/posts/:postId/likes", async (req, res) => {
    try {
      const { postId } = req.params;
      const likes = await storage.getLikesByPostId(Number(postId));
      res.json(likes);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/posts/:postId/likes", requireAuth, async (req: any, res) => {
    try {
      const { postId } = req.params;
      const post = await storage.getPost(Number(postId));
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const likeData = insertLikeSchema.parse({
        postId: Number(postId),
        userId: req.session.userId
      });
      
      const like = await storage.createLike(likeData);
      res.status(201).json(like);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/posts/:postId/likes", requireAuth, async (req: any, res) => {
    try {
      const { postId } = req.params;
      const success = await storage.deleteLike(Number(postId), req.session.userId);
      
      if (!success) {
        return res.status(404).json({ message: "Like not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Mod routes
  app.get("/api/mods", async (req, res) => {
    try {
      const mods = await storage.getAllMods();
      res.json(mods);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/mods/game/:game", async (req, res) => {
    try {
      const { game } = req.params;
      const mods = await storage.getModsByGame(game);
      res.json(mods);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/mods/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const mod = await storage.getMod(Number(id));
      
      if (!mod) {
        return res.status(404).json({ message: "Mod not found" });
      }
      
      res.json(mod);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/mods", requireAuth, async (req: any, res) => {
    try {
      const modData = insertModSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const mod = await storage.createMod(modData);
      res.status(201).json(mod);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/mods/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const mod = await storage.getMod(Number(id));
      
      if (!mod) {
        return res.status(404).json({ message: "Mod not found" });
      }
      
      // Only mod creator or admin can update
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      if (mod.userId !== req.session.userId && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this mod" });
      }
      
      const updateData = insertModSchema.partial().parse(req.body);
      const updatedMod = await storage.updateMod(Number(id), updateData);
      
      res.json(updatedMod);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/mods/:id/download", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const mod = await storage.getMod(Number(id));
      
      if (!mod) {
        return res.status(404).json({ message: "Mod not found" });
      }
      
      if (!mod.downloadUrl) {
        return res.status(400).json({ message: "Mod does not have a download URL" });
      }
      
      // Check if mod is premium and if user has required membership
      if (mod.isPremium && mod.requiredMembershipPlan) {
        const user = await storage.getUser(req.user.id);
        if (!user) {
          return res.status(401).json({ message: "Authentication required" });
        }
        
        // Check if the user's plan is sufficient for this mod using the shared utility
        if (!membershipRankSufficient(user.plan, mod.requiredMembershipPlan)) {
          return res.status(403).json({ 
            message: `This mod requires a ${mod.requiredMembershipPlan} membership or higher` 
          });
        }
      }
      
      // Increment download count
      await storage.incrementModDownloadCount(Number(id));
      
      // Return the download URL
      res.json({ downloadUrl: mod.downloadUrl });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ===========================================
  // ACHIEVEMENT ROUTES
  // ===========================================

  // Get all achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get achievements by type
  app.get("/api/achievements/type/:type", async (req, res) => {
    try {
      const { type } = req.params;
      // Cast the type parameter to AchievementType after validation
      if (!["post_count", "thread_count", "like_received", "mod_upload", "mod_download", 
            "veteran", "first_post", "first_thread", "first_mod", "helpful_answer", 
            "community_builder"].includes(type)) {
        return res.status(400).json({ message: "Invalid achievement type" });
      }
      
      const achievements = await storage.getAchievementsByType(type as any);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get a single achievement
  app.get("/api/achievements/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const achievement = await storage.getAchievement(Number(id));
      
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      res.json(achievement);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Create a new achievement (admin only)
  app.post("/api/achievements", requireAuth, async (req: any, res) => {
    try {
      // Only admins can create achievements
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to create achievements" });
      }
      
      const achievementData = insertAchievementSchema.parse(req.body);
      const achievement = await storage.createAchievement(achievementData);
      
      res.status(201).json(achievement);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update an achievement (admin only)
  app.patch("/api/achievements/:id", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Only admins can update achievements
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update achievements" });
      }
      
      const achievement = await storage.getAchievement(Number(id));
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      const updateData = insertAchievementSchema.partial().parse(req.body);
      const updatedAchievement = await storage.updateAchievement(Number(id), updateData);
      
      res.json(updatedAchievement);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get user achievements
  app.get("/api/user/achievements", requireAuth, async (req: any, res) => {
    try {
      const userAchievements = await storage.getUserAchievements(req.user.id);
      res.json(userAchievements);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Mark user achievement as seen
  app.patch("/api/user/achievements/:id/seen", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      const achievement = await storage.getAchievement(Number(id));
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      const updatedUserAchievement = await storage.markUserAchievementAsSeen(req.user.id, Number(id));
      
      if (!updatedUserAchievement) {
        return res.status(404).json({ message: "User achievement not found" });
      }
      
      res.json(updatedUserAchievement);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Check for new achievements for the current user
  app.post("/api/user/achievements/check", requireAuth, async (req: any, res) => {
    try {
      const newAchievements = await storage.checkAndGrantAchievements(req.user.id);
      res.json(newAchievements);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ===========================================
  // MEMBERSHIP & PAYMENT ROUTES (PAYPAL/BINANCE)
  // ===========================================

  // Since PayPal handles client-side checkout, we don't need a create-subscription endpoint
  // but we'll keep it as a simple response for compatibility
  app.post("/api/create-subscription", requireAuth, async (req: any, res) => {
    try {
      const { planId, amount } = req.body;
      if (!planId || !amount) {
        return res.status(400).json({ message: "Missing required parameters: planId and amount" });
      }

      // Just return success as PayPal handles payment on the client
      res.json({ 
        success: true,
        message: "Ready for PayPal checkout"
      });
    } catch (error: any) {
      console.error("PayPal setup error:", error.message);
      res.status(500).json({ 
        message: "Error setting up payment",
        error: error.message 
      });
    }
  });

  // Handle successful PayPal payments and upgrade membership
  app.post("/api/payment-success", requireAuth, async (req: any, res) => {
    try {
      const { paymentId, orderId, planId, paymentMethod = "paypal" } = req.body;
      if (!paymentId || !planId) {
        return res.status(400).json({ message: "Missing required payment information" });
      }

      // Verify the plan is valid
      if (!["basic", "premium", "pro"].includes(planId)) {
        return res.status(400).json({ message: "Invalid plan ID" });
      }

      // Handle PayPal payments
      if (paymentMethod === "paypal") {
        if (!paypalClient) {
          return res.status(503).json({ message: "PayPal processing is not configured. Please set up PayPal credentials." });
        }

        // If we have an orderId, we can verify with PayPal (optional)
        if (orderId) {
          try {
            const request = new paypal.orders.OrdersGetRequest(orderId);
            const order = await paypalClient.execute(request);
            
            // Check that the order is completed
            if (order.result.status !== "COMPLETED") {
              return res.status(400).json({ 
                message: "Payment not completed", 
                status: order.result.status 
              });
            }
            
            // Store PayPal customer info if available
            if (order.result.payer && order.result.payer.payer_id) {
              await storage.updatePaypalCustomerId(req.user.id, order.result.payer.payer_id);
            }
          } catch (verifyError: any) {
            console.error("PayPal verification error:", verifyError);
            // Continue anyway as PayPal's client-side confirmation is typically sufficient
          }
        }
      }

      // Set expiration date (1 month from now)
      const planExpiresAt = new Date();
      planExpiresAt.setMonth(planExpiresAt.getMonth() + 1);

      // Update user's membership plan
      const user = await storage.updateUserMembership(req.user.id, planId as MembershipPlan, planExpiresAt);

      res.json({ 
        success: true, 
        message: "Membership upgraded successfully",
        user 
      });
    } catch (error: any) {
      console.error("Payment processing error:", error.message);
      res.status(500).json({ 
        message: "Error processing payment",
        error: error.message 
      });
    }
  });

  // Handle Binance Pay payments
  app.post("/api/binance-payment", requireAuth, async (req: any, res) => {
    try {
      const { binanceUserId, planId } = req.body;
      
      if (!binanceUserId || !planId) {
        return res.status(400).json({ message: "Missing required payment information" });
      }

      // Verify the plan is valid
      if (!["basic", "premium", "pro"].includes(planId)) {
        return res.status(400).json({ message: "Invalid plan ID" });
      }

      // Update the user's Binance ID
      await storage.updateBinanceUserId(req.user.id, binanceUserId);

      // Set expiration date (1 month from now)
      const planExpiresAt = new Date();
      planExpiresAt.setMonth(planExpiresAt.getMonth() + 1);

      // Update user's membership plan
      const user = await storage.updateUserMembership(req.user.id, planId as MembershipPlan, planExpiresAt);

      res.json({ 
        success: true, 
        message: "Binance payment processed successfully",
        user 
      });
    } catch (error: any) {
      console.error("Binance payment error:", error.message);
      res.status(500).json({ 
        message: "Error processing Binance payment",
        error: error.message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
