import { pgTable, text, serial, integer, boolean, timestamp, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const membershipPlans = ["free", "basic", "premium", "pro"] as const;
export type MembershipPlan = typeof membershipPlans[number];

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  plan: text("plan", { enum: membershipPlans }).default("free").notNull(),
  planExpiresAt: timestamp("plan_expires_at"),
  avatar: text("avatar"),
  role: text("role").default("user").notNull(),
  postsCount: integer("posts_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  paypalCustomerId: text("paypal_customer_id"),
  paypalSubscriptionId: text("paypal_subscription_id"),
  binanceUserId: text("binance_user_id"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  avatar: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Forum categories for organizing discussion threads
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  slug: text("slug").notNull().unique(),
  order: integer("order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  description: true, 
  slug: true,
  order: true,
  isActive: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Discussion threads within categories
export const threads = pgTable("threads", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false).notNull(),
  isLocked: boolean("is_locked").default(false).notNull(),
  isDeleted: boolean("is_deleted").default(false).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  lastActivityAt: timestamp("last_activity_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertThreadSchema = createInsertSchema(threads).pick({
  categoryId: true,
  userId: true,
  title: true,
  content: true,
  isPinned: true,
  isLocked: true,
});

export type InsertThread = z.infer<typeof insertThreadSchema>;
export type Thread = typeof threads.$inferSelect;

// Posts within threads (replies)
export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  threadId: integer("thread_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  isEdited: boolean("is_edited").default(false).notNull(),
  editedAt: timestamp("edited_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPostSchema = createInsertSchema(posts).pick({
  threadId: true,
  userId: true,
  content: true,
});

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

// Likes for posts
export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertLikeSchema = createInsertSchema(likes).pick({
  postId: true,
  userId: true,
});

export type InsertLike = z.infer<typeof insertLikeSchema>;
export type Like = typeof likes.$inferSelect;

// Game mods that users can discuss
export const mods = pgTable("mods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  game: text("game").notNull(),
  description: text("description").notNull(),
  version: text("version").notNull(),
  userId: integer("user_id").notNull(),
  downloadUrl: text("download_url"),
  imageUrl: text("image_url"),
  downloadCount: integer("download_count").default(0).notNull(),
  fileSize: integer("file_size"), // File size in bytes
  requirements: text("requirements"), // System requirements
  installationInstructions: text("installation_instructions"), // Installation instructions
  tags: text("tags").array(), // Tags for categorization
  features: text("features").array(), // List of features this mod provides
  isPremium: boolean("is_premium").default(false).notNull(), // Whether this mod is premium content
  requiredMembershipPlan: text("required_membership_plan", { enum: membershipPlans }), // Required membership plan to download
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertModSchema = createInsertSchema(mods).pick({
  name: true,
  game: true,
  description: true,
  version: true,
  userId: true,
  downloadUrl: true,
  imageUrl: true,
  fileSize: true,
  requirements: true,
  installationInstructions: true,
  tags: true,
  features: true,
  isPremium: true,
  requiredMembershipPlan: true,
});

export type InsertMod = z.infer<typeof insertModSchema>;
export type Mod = typeof mods.$inferSelect;

// We'll keep these tables for backward compatibility
export const campaignTypes = ["watch-hours", "subscribers", "likes"] as const;

export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  target: integer("target").notNull(),
  progress: integer("progress").default(0).notNull(),
  status: text("status").default("active").notNull(),
  channelUrl: text("channel_url").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCampaignSchema = createInsertSchema(campaigns).pick({
  name: true,
  userId: true,
  type: true,
  target: true,
  channelUrl: true,
});

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  watchHours: integer("watch_hours").default(0).notNull(),
  subscribers: integer("subscribers").default(0).notNull(),
  likes: integer("likes").default(0).notNull(),
  activeCampaigns: integer("active_campaigns").default(0).notNull(),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertMetricsSchema = createInsertSchema(metrics).pick({
  userId: true,
  watchHours: true,
  subscribers: true,
  likes: true,
  activeCampaigns: true,
  date: true,
});

export type InsertMetrics = z.infer<typeof insertMetricsSchema>;
export type Metrics = typeof metrics.$inferSelect;

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  description: text("description").notNull(),
  features: text("features").array().notNull(),
  basePrice: integer("base_price").notNull(),
});

export const insertServiceSchema = createInsertSchema(services).pick({
  name: true,
  type: true,
  description: true,
  features: true,
  basePrice: true,
});

export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;

// Achievement types
export const achievementTypes = [
  "post_count",
  "thread_count",
  "like_received",
  "mod_upload",
  "mod_download",
  "veteran",
  "first_post",
  "first_thread",
  "first_mod",
  "helpful_answer",
  "community_builder"
] as const;

export type AchievementType = typeof achievementTypes[number];

// Achievement schema
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type", { enum: achievementTypes }).notNull(),
  badgeUrl: text("badge_url").notNull().default("/badges/default.svg"),
  thresholdValue: integer("threshold_value").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  type: true,
  badgeUrl: true,
  thresholdValue: true,
});

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// User Achievement schema for tracking which users have which achievements
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
  progress: integer("progress").notNull().default(0),
  isNew: boolean("is_new").notNull().default(true),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementId: true,
  progress: true,
  isNew: true,
});

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

// Security logs for monitoring
export const securityLogs = pgTable("security_logs", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  path: text("path").notNull(),
  eventType: text("event_type").notNull(),
  method: text("method").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  userId: integer("user_id").references(() => users.id),
  details: text("details"),
});

export const insertSecurityLogSchema = createInsertSchema(securityLogs).pick({
  ipAddress: true,
  path: true,
  eventType: true,
  method: true,
  userId: true,
  details: true,
});

export type InsertSecurityLog = z.infer<typeof insertSecurityLogSchema>;
export type SecurityLog = typeof securityLogs.$inferSelect;
