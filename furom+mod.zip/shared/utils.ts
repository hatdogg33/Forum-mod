import { MembershipPlan } from "./schema";

/**
 * Checks if a user's membership plan meets or exceeds the required plan
 * Used by both client and server for consistent plan comparison logic
 * 
 * @param userPlan The user's current membership plan
 * @param requiredPlan The membership plan required for access
 * @returns boolean indicating if the user's plan is sufficient
 */
export function membershipRankSufficient(
  userPlan: string | MembershipPlan, 
  requiredPlan: string | MembershipPlan
): boolean {
  const planRanks: Record<string, number> = {
    'free': 0,
    'basic': 1,
    'premium': 2,
    'pro': 3
  };
  
  return (planRanks[userPlan] ?? 0) >= (planRanks[requiredPlan] ?? 0);
}