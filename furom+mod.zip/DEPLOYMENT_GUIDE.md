# ModForum Deployment Guide for Hostinger

This guide explains how to deploy the ModForum application on Hostinger hosting services.

## Prerequisites

- A Hostinger account with a hosting plan that supports Node.js applications
- Domain name (can be purchased through Hostinger)
- PostgreSQL database (can be set up on Hostinger or use an external service)
- FTP client like FileZilla or direct file upload through Hostinger's control panel

## Step 1: Build the Application

Before deploying, build your application:

```bash
# Install dependencies if not already installed
npm install

# Build the production version
npm run build
```

This will create optimized production files in the `dist` directory.

## Step 2: Set Up PostgreSQL Database

1. Log in to your Hostinger control panel
2. Navigate to the Databases section
3. Create a new PostgreSQL database and note down:
   - Database name
   - Username
   - Password
   - Host/Server address
   - Port

## Step 3: Configure Environment Variables

Create a `.env` file in the root directory with the following variables:

```
DATABASE_URL=postgresql://username:password@host:port/database_name
VITE_PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
SESSION_SECRET=a_secure_random_string
```

Replace the values with your actual credentials.

## Step 4: Deploy to Hostinger

### Using Hostinger's Git Deployment (Recommended)

1. Log in to your Hostinger control panel
2. Navigate to Website > Git
3. Set up a new Git repository
4. Push your code to the Hostinger Git repository:

```bash
git remote add hostinger git@hostinger.com:your-username/your-repo.git
git push hostinger main
```

### Using FTP (Alternative)

1. Log in to your Hostinger control panel
2. Get your FTP credentials
3. Use an FTP client like FileZilla to connect to your server
4. Upload your application files (including the built files in `dist`)

## Step 5: Configure Node.js Environment

1. Log in to your Hostinger control panel
2. Navigate to Website > Node.js
3. Create a new Node.js application
4. Configure the following:
   - Entry point: `server/index.js`
   - Node.js version: 20.x or latest LTS
   - Enable the option to run the application as a service

## Step 6: Set Up Domain and SSL

1. Log in to your Hostinger control panel
2. Navigate to Domains
3. Associate your domain with your hosting account
4. Enable SSL certificate for your domain

## Step 7: Start Your Application

1. Log in to your Hostinger control panel
2. Navigate to Website > Node.js
3. Start your Node.js application
4. Verify that your application is running by visiting your domain

## Troubleshooting

If you encounter issues with your deployment:

1. Check the application logs in the Hostinger control panel
2. Verify that your environment variables are correctly set
3. Make sure your database connection is properly configured
4. Ensure that your Node.js version is compatible with your application

## Maintenance and Updates

To update your application:

1. Make changes to your code locally
2. Build the application
3. Push changes to your Hostinger Git repository or upload via FTP
4. Restart your Node.js application from the Hostinger control panel

## Backup

Regularly backup your database and application files:

1. Use Hostinger's backup features from the control panel
2. Export your PostgreSQL database regularly
3. Keep a local copy of your application code

For additional support, contact Hostinger's customer support or reference their documentation.